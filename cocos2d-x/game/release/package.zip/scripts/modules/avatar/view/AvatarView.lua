require "scripts/modules/avatar/view/AvatarWindow"

--具体逻辑
super_class.AvatarView(AvatarWindow)

function AvatarView:__init( )
 	print("AvatarView")
 	self.data = { ["count"] = 1}
end 

--local m_module = nil --属于哪个模块，用来让Module层响应各种操作
--function AvatarView:setModule( m )
 --   m_module = m
--    self.m_module = m
--end

----------event----

function AvatarView:registerTouchHandler( )
	print("AvatarView:registerTouchHandler")
	local function onTidy(...)
	    print("tidy avatar data")
	    self.data["count"] = self.data["count"] + 1
	    self.module:RequestAvatarData(self.data)
    end
	--self.tidyBtn:setTouchClickFun(onTidy)
	--self.tidyBtn:registerControlEventHandler(onTidy, CCControlEventTouchDown)
end

function AvatarView:update(data)
    self.label:setString("data.name" .. " " .. data.count )
end