require "scripts/UI/component/Window"
require "scripts/UI/ComponentUtil"

super_class.AvatarWindow(Window)

function AvatarWindow:__init(...)
	print("AvatarWindow:__init")
	self.id = win_id_map.AVATAR
	self:initWindow()
end

--override
--[[function AvatarWindow:initBackground()
	if self.config.bgName == nil then
		return
	end

	self.bg = ComponentUtil:CreateScale9Sprite(self.config.bgName, CCSize(600,500), CCRect(50,30,238,398))
	self.view:addChild(self.bg.view, 0)
end--]]

function AvatarWindow:initLeftView()
	self._leftView = CCNode:create()
	self._leftView:setAnchorPoint(CCPoint(0, 0))
	self.view:addChild(self._leftView, 1)
end

function AvatarWindow:initRightView()
	self._rightView = CCNode:create()
	self._rightView:setAnchorPoint(CCPoint(0, 0))
	self.view:addChild(self._rightView, 1)
	--self._rightView:setPosition(-100, 0)
end

function AvatarWindow:initUIComponent()
    print("AvatarWindow initUIComponent")
    --self:setWindowSize(CCSize(600, 500))

    --local width = self.view:getContentSize().width
    --local height = self.view:getContentSize().height

    --self.label = CCLabelTTF:create("", "Arial", 24)
  	--self.label:setString("hello module")
  	--self.label:setPosition(10, -50)
  	--self.view:addChild(self.label)

  	--self.tidyBtn = ComponentUtil:CreateSimpleButton("simpleButton1")
	--self.tidyBtn:setPosition(10, 50)
	

	--self.tidyBtn = ComponentUtil:CreateButton("人物", "simpleButton1")
	--self.tidyBtn:setPosition(10, 50)
	--self.view:addChild(self.tidyBtn)

	self._fontName = "Consolas"

	--------------左边元素----------------
	self:initLeftView()

	require "scripts/utils/LayoutRect"
	self._avatarBg = ComponentUtil:CreateScale9Sprite("background1", CCSize(self:getFrameSize().width/2,self:getFrameSize().height - 20), CCRect(50,30,238,398))
	self._avatarBg:setAnchorPoint(CCPoint(0.5, 0.5))
	self._avatarBg:setPosition(self._avatarBg.view:getContentSize().width / 2, self._avatarBg.view:getContentSize().height / 2)
	self._leftView:addChild(self._avatarBg.view, 1)

	self._charBg1 = CCSprite:create("images/characterInfo/char_bg1.png")
	self._charBg1:setAnchorPoint(CCPoint(0.5, 0.5))
	self._charBg1:setPosition(self._avatarBg.view:getContentSize().width / 2, self._avatarBg.view:getContentSize().height / 2)
	self._leftView:addChild(self._charBg1, 3)

	self._charBg2 = CCSprite:create("images/characterInfo/char_bg2.png")
	self._charBg2:setAnchorPoint(CCPoint(0.5, 0.5))
	self._charBg2:setPosition(self._avatarBg.view:getContentSize().width / 2 + 82 + 35, self._avatarBg.view:getContentSize().height / 2)
	self._leftView:addChild(self._charBg2, 3)

	self._charBg3 = CCSprite:create("images/characterInfo/char_bg3.png")
	self._charBg3:setAnchorPoint(CCPoint(0.5, 0.5))
	self._charBg3:setPosition(self._avatarBg.view:getContentSize().width / 2, self._avatarBg.view:getContentSize().height / 2 - 150)
	--local rect = LayoutRect()
	--local x = rect:center().x
	--local y = rect:center().y
	self._leftView:addChild(self._charBg3, 2)

	self._charBg4 = CCSprite:create("images/characterInfo/char_bg2.png")
	self._charBg4:setAnchorPoint(CCPoint(0.5, 0.5))
	self._charBg4:setPosition(self._avatarBg.view:getContentSize().width / 2 - 82 - 35, self._avatarBg.view:getContentSize().height / 2)
	self._charBg4:setScale(-1)
	self._leftView:addChild(self._charBg4, 3)

	--------------右边元素----------------
	self:initRightView()

	self._avatarInfoBg = ComponentUtil:CreateScale9Sprite("background1", CCSize(self.bg.view:getContentSize().width/2 - 10,self.bg.view:getContentSize().height - 20), CCRect(50,30,238,398))
	self._avatarInfoBg:setAnchorPoint(CCPoint(1, 0))
	self._avatarInfoBg:setPosition(self.bg.view:getContentSize().width, 0)
	self._rightView:addChild(self._avatarInfoBg.view, 1)

	local rect = LayoutRect()
	local x = rect:center().x + self._avatarBg.view:getContentSize().width / 2 - 100
	local y = rect:center().y + 180
	self._levelLabel = ComponentUtil:CreateLabelTTF("Lv.99", self._fontName, 28, Color3B(255, 255, 255), CCSize(100, 20))
	self._levelLabel:setPosition(x, y)
	self._rightView:addChild(self._levelLabel.view, 2)

	self._charName = ComponentUtil:CreateLabelTTF("德玛尼亚", self._fontName, 28, Color3B(255, 255, 255), CCSize(100, 20))
	x = rect:center().x + self._avatarBg.view:getContentSize().width / 2 + 100
	self._charName:setPosition(x, y)
	self._rightView:addChild(self._charName.view, 2)

	self._hpLabel = ComponentUtil:CreateLabelTTF("生命值：99999", self._fontName, 25, Color3B(255, 255, 255), CCSize(150, 30))
	x = rect:center().x + self._avatarBg.view:getContentSize().width / 2
	y = rect:center().y + 50
	self._hpLabel:setPosition(x, y)
	self._rightView:addChild(self._hpLabel.view, 2)

	self._attackLabel = ComponentUtil:CreateLabelTTF("攻击力：99999", self._fontName, 25, Color3B(255, 255, 255), CCSize(150, 30))
	y = rect:center().y + 20
	self._attackLabel:setPosition(x, y)
	self._rightView:addChild(self._attackLabel.view, 2)

	self._defenseLabel = ComponentUtil:CreateLabelTTF("防御力：99999", self._fontName, 25, Color3B(255, 255, 255), CCSize(150, 30))
	y = rect:center().y - 10
	self._defenseLabel:setPosition(x, y)
	self._rightView:addChild(self._defenseLabel.view, 2)

end

local function onTidy(...)
	print("tidy bag data")
end