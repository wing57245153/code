require "scripts/core/BasicModule"
require "scripts/modules/avatar/view/AvatarView"
require "scripts/core/AppEvent" 
require "scripts/config/module_config"

super_class.AvatarModule(BasicModule)

function AvatarModule:__init( )
	print("AvatarModule", self.messenger)
	self.name = module_config.AVATAR_MODULE
end 

local m_avatarView = nil;

function AvatarModule:InitModule()
	self:registerEvent()

	m_avatarView = AvatarView();
	m_avatarView:setModule( self );
	self.m_parent:addChild(m_avatarView.view);
end

function AvatarModule:registerEvent()
    print("registerEvent")
    self.messenger:add_listener(DATA_UPDATE_EVENT, DATA_AVATAR__EVENT, self.updateData)
    self.messenger:add_listener("M10", "00", self.updateData)
end

function AvatarModule:destroy()
	BasicModule:destroy()
    print("destroy")
    m_avatarView:depose()
end

------------------ module ----> view

function AvatarModule.updateData(data)
	print("update data")
    m_avatarView:update(data)
end


---------------view --- > module
--请求数据
function AvatarModule:RequestAvatarData( data )
	-- body
	--local avatarData = self.dataPool:getAvatarData()
	--avatarData:write( data ) -- 写数据到服务器，服务器返回数据

	local m10 = self.dataPool:getM10()
	m10.M1000:write( data )
end