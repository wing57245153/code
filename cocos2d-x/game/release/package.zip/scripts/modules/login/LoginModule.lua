require "scripts/core/BasicModule"
require "scripts/core/AppEvent" 
require "scripts/config/module_config"
require "scripts/modules/login/view/LoginView"

super_class.LoginModule(BasicModule)

function LoginModule:__init( )
	self.name = module_config.LoginModule
end 

local m_loginView = nil;
function LoginModule:InitModule()
	self:registerEvent()
    print("login... InitModule")
	m_loginView = LoginView();
	m_loginView:setModule( self );
	m_loginView:initUIComponent()
	self.m_parent:addChild(m_loginView.view);
end

function LoginModule:registerEvent()
	local function ReceiveLoginResult( data )
	    print("ReceiveLoginResult...." , data.Result)
	    if data.Result == 1001 then --登录成功
	    	game_config.AccId = data.AccId
            self:LoginSuccess()
        else
        	print("login fail...")
	    end

    end

    local function ReceiveRoleList( data )
    	print("role list")
    end

    local function ReceiveCreateRoleResult(data)
    	print("ReceiveCreateRoleResult", data.Result)
    end
    self.messenger:add_listener(NET_EVENT_M01, NET_EVENT_M0100, ReceiveLoginResult)
end

function LoginModule:RemoveEvent()
	self.messenger:remove_listener(NET_EVENT_M01, NET_EVENT_M0100, ReceiveLoginResult)
end

function LoginModule:destroy()
	self:RemoveEvent()
	m_loginView:depose()
	self.m_parent:removeChild(m_loginView.view, true);
	BasicModule:destroy()
    m_loginView = nil
end

---请求登录
function LoginModule:RequreLogin( data )
	local m01 = self.dataPool:getM01()
	m01.M0100:write( data )
end

----------------------
function LoginModule:SingleLogin( ... )
	self:LoginSuccess()
end

----登录成功处理
function LoginModule:LoginSuccess()
    --self.messenger:dispatchEvent(GAME_EVENT, GAME_ENTER_EVENT, "login_success")
	--self.messenger:dispatchEvent(MODULE_EVENT, MODULE_DESTROY_WINDOW, "LoginModule")
	--self:destroy()
	--打开角色选择列表
	--self.messenger:dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, module_config.ROLELIST_MODULE)

	require "scripts/GameStateManager"
	GameStateManager:set_state("choose") ---打开角色选择列表 离开登陆界面
end