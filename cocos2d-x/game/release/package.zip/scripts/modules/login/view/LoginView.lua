require "scripts/modules/login/view/LoginWindow"
require "scripts/core/game_config"

--具体逻辑
super_class.LoginView(LoginWindow)

function LoginView:__init( )
end 

function LoginWindow:setModule( m)
    self.module = m
end

----------event----

function LoginView:registerTouchHandler( )
	local function onLogin(...)
	    print("login")
	    data = {}
	    --data["AccId"] = tonumber(self.IDEdit:getText())
	    data["AccName"] = tostring("<<" .. self.accNameEdit:getText() .. ">>") ---二进制数据
	    data["ID"] = 1245775111
	    if data["AccName"]~= nil then
	    	game_config.AccName = data["AccName"]
	        self.module:RequreLogin(data)
	    end

	    print(data["AccName"], data["ID"])
    end

    local function onSingleLogin()
    	self.module:SingleLogin()
    end
	--self.tidyBtn:setTouchClickFun(onTidy)
	self.loginBtn:registerControlEventHandler(onLogin, CCControlEventTouchDown)
	self.singleLoginBtn:registerControlEventHandler(onSingleLogin, CCControlEventTouchDown)
end

function LoginView:update(data)
    
end