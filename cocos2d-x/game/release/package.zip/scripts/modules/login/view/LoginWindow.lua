require "scripts/UI/component/UserBase"
require "scripts/UI/ComponentUtil"

super_class.LoginWindow()

function LoginWindow:__init(...)
	print("AvatarWindow:__init")
	self.id = win_id_map.LOGIN
	--self:initWindow()
	self.view = CCNode:create()
	self.view:setAnchorPoint(CCPoint(0,0))
end

function LoginWindow:registerTouchHandler( )

end

function LoginWindow:depose()
    self.view:removeChild(self.label, true)
    self.view:removeChild(self.accNameEdit, true)
    self.view:removeChild(self.labelID, true)
    self.view:removeChild(self.IDEdit, true)
    self.view:removeChild(self.loginBtn, true)
    self.view:removeChild(self.singleLoginBtn, true)
end

function LoginWindow:initUIComponent()
    print("AvatarWindow initUIComponent")
    --local win_size = CCDirector:getInstance():getWinSize()
	--self.view:setPosition(win_size.width - 85, win_size.height - 85)
    local editBoxSize = CCSize(200, 30)

    self.label = CCLabelTTF:create("", "Arial", 24)
  	self.label:setString("账号：")
  	self.label:setAnchorPoint(CCPoint(0,0))
  	self.label:setPosition(0, 0)
  	self.view:addChild(self.label)

  	self.accNameEdit = CCEditBox:create(editBoxSize, CCScale9Sprite:create("ui/edit/green_edit.png"))
  	self.accNameEdit:setAnchorPoint(CCPoint(0,0))
  	self.accNameEdit:setPosition(CCPoint(60, 0))
  	self.view:addChild(self.accNameEdit)

  	self.labelID = CCLabelTTF:create("", "Arial", 24)
  	self.labelID:setString("ID：")
  	self.labelID:setAnchorPoint(CCPoint(0,0))
  	self.labelID:setPosition(0, -40)
  	--self.view:addChild(self.labelID)

  	self.IDEdit = CCEditBox:create(editBoxSize, CCScale9Sprite:create("ui/edit/green_edit.png"))
  	self.IDEdit:setAnchorPoint(CCPoint(0,0))
  	self.IDEdit:setPosition(CCPoint(60, -40))
  	--self.view:addChild(self.IDEdit)
	

	self.loginBtn = ComponentUtil:CreateButton("登录", "simpleButton1")
	self.loginBtn:setAnchorPoint(CCPoint(0,0))
	self.loginBtn:setPosition(0, 50)
	self.view:addChild(self.loginBtn)

	self.singleLoginBtn = ComponentUtil:CreateButton("单机登录", "simpleButton1")
	self.singleLoginBtn:setAnchorPoint(CCPoint(0,0))
	self.singleLoginBtn:setPosition(100, 50)
	self.view:addChild(self.singleLoginBtn)
	
    self:registerTouchHandler()
end

--_minimap = LoginWindow()