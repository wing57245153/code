require "scripts/UI/component/UserBase"


---------------------------------------------------------------
------ 纯视图，只布局界面
---------------------------------------------------------------

super_class.MiniMapView(UserBase)

function MiniMapView:initUIComponent()
	self._bgSprite = CCSprite:create("images/userminimap/user_minimap_bg.png")
	self.view:setAnchorPoint(CCPoint(1, 1))
	self._bgSprite:setAnchorPoint(CCPoint(1, 1))
	self.view:addChild(self._bgSprite, 1)
	self._bgSprite:setPosition(0, 0)
	self:setPosition()

	self._mapSprite = CCSprite:create("images/userminimap/user_minimap_default_map.png")
	self._mapSprite:setAnchorPoint(CCPoint(1, 1))
	self.view:addChild(self._mapSprite, 2)
	self._mapSprite:setPosition(-3.5, 0)
end

function MiniMapView:setPosition()
	local rect = LayoutRect(CCPoint(0, 0))
	p = rect:rightTop()
	self.view:setPosition(p.x - 5, p.y - 5)
end

_minimap = MiniMapView()