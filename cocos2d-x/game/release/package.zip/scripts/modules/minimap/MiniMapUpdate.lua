-----------------------------------------------------------
---------- 更新MiniMapView的逻辑
-----------------------------------------------------------

super_class.MiniMapUpdate(MiniMapView)

function MiniMapUpdate:__init( ... )
	
end