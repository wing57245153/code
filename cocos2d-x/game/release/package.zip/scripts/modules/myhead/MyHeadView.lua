require "scripts/UI/component/UserBase"


---------------------------------------------------------------
------ 纯视图，只布局界面
---------------------------------------------------------------

super_class.MyHeadView(UserBase)

function MyHeadView:initUIComponent()
	self._bgSprite = CCSprite:create("images/userhead/user_my_head_bg.png")
	self.view:setAnchorPoint(CCPoint(0, 1))
	self._bgSprite:setAnchorPoint(CCPoint(0, 1))
	self.view:addChild(self._bgSprite, 1)
	self._bgSprite:setPosition(0, 0)

	self._avatarBg = CCSprite:create("images/userhead/user_my_head_avatar_bg.png")
	self._avatarBg:setAnchorPoint(CCPoint(0, 1))
	self.view:addChild(self._avatarBg, 2)
	self._avatarBg:setPosition(15, -5)

	self._hpProgressBar = ComponentUtil:CreateProgressBar("progressbar1")
	--self.view:addChild(self._hpProgressBar.view, 2)
	self._hpProgressBar:setPosition(60, 28)
	self._hpProgressBar:setMinimumValue(0)
	self._hpProgressBar:setMaximumValue(1)
	self._hpProgressBar:setValue(0.5)

	self._avatar = CCSprite:create("images/userhead/user_my_head_avatar_default.png")
	self._avatar:setAnchorPoint(CCPoint(0, 1))
	self.view:addChild(self._avatar, 3)
	self._avatar:setPosition(15, -5)

	self:setPosition()
end

function MyHeadView:setPosition()
	require "scripts/utils/LayoutRect"
	local rect = LayoutRect(CCPoint(0, 0))
	p = rect:leftTop()
	self.view:setPosition(p.x + 10, p.y - 10)
end

function  MyHeadView:updateHP(hp)
	-- body
end

_myHead = MyHeadView()
