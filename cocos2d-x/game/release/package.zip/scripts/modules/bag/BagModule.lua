require "scripts/core/BasicModule"
require "scripts/modules/bag/view/BagView"
require "scripts/core/AppEvent" 
require "scripts/config/module_config"

super_class.BagModule(BasicModule)

function BagModule:__init( )
	print("BagModule", self.messenger)
	self.name = module_config.BAG_MODULE
end 

local m_BagView = nil;

function BagModule:InitModule()
	self:registerEvent()

	m_BagView = BagView();
	m_BagView:setModule(self);
	self.m_parent:addChild(m_BagView.view);
end

function BagModule:registerEvent()
    print("registerEvent")
    self.messenger:add_listener(DATA_UPDATE_EVENT, DATA_AVATAR__EVENT, self.updateData)
end

function BagModule:destroy()
	BasicModule:destroy()
    print("destroy")
    m_BagView:depose()
end

function BagModule.updateData(data)
    print("updateData", data)
end