require "scripts/modules/bag/view/BagWindow"

--具体逻辑
super_class.BagView(BagWindow)

function BagView:__init( )
 	print("BagView")
end 

function BagView:update(data)
    print("update", self.label)
    self.label:setString(data)
end