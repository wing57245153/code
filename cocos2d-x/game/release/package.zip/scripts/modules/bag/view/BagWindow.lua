require "scripts/UI/component/Window"
require "scripts/UI/ComponentUtil"
require "scripts/config/win_config"

---------------------------------------------------------
------------------   背包  ------------------------------
------------------   2013/09/03  ------------------------
-- 只布局UI组件，在BagView刷新界面
---------------------------------------------------------

super_class.BagWindow(Window)

function BagWindow:__init(...)
	self.id = win_id_map.BAG
	self:initWindow()
end


local tidyBtn = nil
local function onTidy(...)
	print("tidy bag data")
end

function BagWindow:initUIComponent()
	--print("init Bag:initUIComponent")
	--tidyBtn = ComponentUtil:CreateSimpleButton("closeButton")
	--tidyBtn:setPosition(10, 50)
	--tidyBtn:setTouchClickFun(onTidy)
	--self.view:addChild(tidyBtn.view)
end