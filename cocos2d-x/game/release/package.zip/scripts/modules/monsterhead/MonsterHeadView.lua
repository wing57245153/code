require "scripts/UI/component/UserBase"


---------------------------------------------------------------
------ 纯视图，只布局界面
---------------------------------------------------------------

super_class.MonsterHeadView(UserBase)

function MonsterHeadView:initUIComponent()
	--[[local win_size = CCDirector:getInstance():getWinSize()
	self.view:setPosition(win_size.width / 2, win_size.height - 60)

	self.hpBarSprite = CCSprite:create("images/userhead/user_monster_head_hp_bar.png")
	self.view:addChild(self.hpBarSprite, 1)
	self.hpBarSprite:setPosition(0, 0)

	self.avatarSprite = CCSprite:create("images/userhead/user_monster_head_avatar.png")
	self.view:addChild(self.avatarSprite, 2)
	self.avatarSprite:setPosition(150, -30)]]
	self._bgSprite = CCSprite:create("images/userhead/user_monster_head_bg.png")
	self.view:setAnchorPoint(CCPoint(0.5, 1))
	self._bgSprite:setAnchorPoint(CCPoint(0.5, 1))
	self.view:addChild(self._bgSprite, 1)
	self._bgSprite:setPosition(0, 0)

	self._avatarBg = CCSprite:create("images/userhead/user_monster_head_avatar_bg.png")
	self._avatarBg:setAnchorPoint(CCPoint(0, 1))
	self.view:addChild(self._avatarBg, 2)
	self._avatarBg:setPosition(70, -10)

	self._avatar = CCSprite:create("images/userhead/user_monster_head_avatar_default.png")
	self._avatar:setAnchorPoint(CCPoint(0, 1))
	self.view:addChild(self._avatar, 3)
	self._avatar:setPosition(76, -12)

	self:setPosition()
end

function MonsterHeadView:setPosition()
	require "scripts/utils/LayoutRect"
	local rect = LayoutRect(CCPoint(0, 0))
	p = rect:top()
	self.view:setPosition(p.x + 10, p.y - 15)
end

function  MonsterHeadView:updateHP(hp)
	-- body
end

_monsterHead = MonsterHeadView()
