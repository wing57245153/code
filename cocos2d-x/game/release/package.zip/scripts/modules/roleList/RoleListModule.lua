-------角色选择列表 创建角色
require "scripts/core/BasicModule"
require "scripts/core/AppEvent" 
require "scripts/config/module_config"
require "scripts/modules/roleList/view/RoleListView"

super_class.RoleListModule(BasicModule)

function RoleListModule:__init( )
	self.name = module_config.ROLELIST_MODULE
end 

local m_roleListView = nil;
function RoleListModule:InitModule()
	self:registerEvent()
	m_roleListView = RoleListView();
	m_roleListView:setModule( self );
	m_roleListView:initUIComponent()
	self.m_parent:addChild(m_roleListView.view);

	self:InitRequest()
end

----初始化请求
function RoleListModule:InitRequest( ... )
	self:RequestRoleList()
end

function RoleListModule:registerEvent()

	local function ReceiveRoleList( data ) --接受到角色列表
		self:ReceiveRoleList( data )
	end

	local function ReceiveCreateRoleResult( data ) ---创建角色结果
        self:ReceiveCreateRoleResult(data)
	end

    self.messenger:add_listener(NET_EVENT_M01, NET_EVENT_M0101, ReceiveRoleList)
    self.messenger:add_listener(NET_EVENT_M01, NET_EVENT_M0102, ReceiveCreateRoleResult)
end

function RoleListModule:destroy()
	
	self.messenger:remove_listener(NET_EVENT_M01, NET_EVENT_M0101, ReceiveRoleList)
    self.messenger:remove_listener(NET_EVENT_M01, NET_EVENT_M0102, ReceiveCreateRoleResult)
    m_roleListView:depose()
    
    self.m_parent:removeChild(m_roleListView.view, true);
    m_roleListView = nil
    BasicModule:destroy()
end

-------------请求角色列表 c -> s------
function RoleListModule:RequestRoleList( ... )
	local m01 = self.dataPool:getM01()
	m01.M0101:write( data )
end

------请求创建角色-----
function RoleListModule:RequestCreateRole( data )
	local m01 = self.dataPool:getM01()
	m01.M0102:write( data )
end

------------s - > c
----------获取角色列表----
function RoleListModule:ReceiveRoleList( data )
	-- body
	print("ReceiveRoleList...")
	if data.RoleList == nil then
		return
	end
	for k,v in pairs(data.RoleList) do
		print(k,v.RoleId, v.RoleName, v.RoleCareer, v.RoleSex, v.RoleLv)
	end
end
----接受创建角色结果
function RoleListModule:ReceiveCreateRoleResult( data )
	if data.Result == 1201 then ----创建角色成功
		print("role create success")
		print("RoleId", data.RoleId)
		print("RoleName", data.RoleName)
		print("RoleCareer", data.RoleCareer)
		print("RoleSex", data.RoleSex)

		----直接进入游戏
        local enterdata = {}
        enterdata.RoleId = data.RoleId
		local m01 = self.dataPool:getM01()
	    m01.M0103:write( enterdata )
	else
		print("create role fail...", data.Result)
	end
end

---------------------------
function RoleListModule:EnterGame()
	self.messenger:dispatchEvent(GAME_EVENT, GAME_ENTER_EVENT, "enter_game")
	self:destroy()
	--self.messenger:dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "AvatarModule")
end