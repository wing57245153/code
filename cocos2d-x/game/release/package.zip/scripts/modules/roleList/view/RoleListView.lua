require "scripts/modules/roleList/view/RoleListUI"
require "scripts/core/game_config"

--具体逻辑
super_class.RoleListView(RoleListUI)

function RoleListView:__init( )
end 

function RoleListView:setModule( m)
    self.module = m
end

----------event----

function RoleListView:registerTouchHandler( )

	local function onEnterGame()
		self.module:EnterGame()
		--self.module:RequestRoleList()
	end
	local function onCreateRole()
		local roleInfo = {}
		roleInfo["RoleId"] = game_config.AccId
        roleInfo["RoleName"] = tostring(self.roleNameEdit:getText())
        roleInfo["RoleCareer"] = 1
        roleInfo["RoleSex"] = 1
		self.module:RequestCreateRole(roleInfo)
	end
    self.enterGameBtn:registerControlEventHandler(onEnterGame, CCControlEventTouchDown)
    self.createRoleBtn:registerControlEventHandler(onCreateRole, CCControlEventTouchDown)
end