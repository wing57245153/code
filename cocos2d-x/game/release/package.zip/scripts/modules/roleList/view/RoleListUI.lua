
super_class.RoleListUI()
function RoleListUI:__init(...)
	self.view = CCNode:create()
	self.view:setAnchorPoint(CCPoint(0,0))
end

function RoleListUI:registerTouchHandler( )

end

function RoleListUI:depose()
	self.view:removeChild(self.enterGameBtn, true)
	self.view:removeChild(self.createRoleBtn, true)
end

function RoleListUI:initUIComponent()
    local editBoxSize = CCSize(200, 30)
	self.label = CCLabelTTF:create("", "Arial", 24)
  	self.label:setString("角色名:")
  	self.label:setAnchorPoint(CCPoint(0,0))
  	self.label:setPosition(0, 100)
  	self.view:addChild(self.label)

  	self.roleNameEdit = CCEditBox:create(editBoxSize, CCScale9Sprite:create("ui/edit/green_edit.png"))
  	self.roleNameEdit:setAnchorPoint(CCPoint(0,0))
  	self.roleNameEdit:setPosition(CCPoint(100, 100))
  	self.view:addChild(self.roleNameEdit)

	self.enterGameBtn = ComponentUtil:CreateButton("进入游戏", "simpleButton1")
	self.enterGameBtn:setAnchorPoint(CCPoint(0,0))
	self.enterGameBtn:setPosition(0, 50)
	self.view:addChild(self.enterGameBtn)

	self.createRoleBtn = ComponentUtil:CreateButton("创建角色", "simpleButton1")
	self.createRoleBtn:setAnchorPoint(CCPoint(0,0))
	self.createRoleBtn:setPosition(100, 50)
	self.view:addChild(self.createRoleBtn)

    self:registerTouchHandler()
end