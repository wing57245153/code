-- UIManager.lua
-- created by aXing on  2012-11-15
-- 这是一个UI的管理器
-- 用于管理UI的创建，消亡，显示，隐藏等

super_class.UIManager()

-----------------------------------------------------------------------------------
-- 以下是ui深度排序index
-- 定义域(1, +)
-----------------------------------------------------------------------------------
local Z_JOYSTICK			= 1				-- 摇杆深度低于ui层
local Z_HYPERLINK			= 2 			-- 超连接
local Z_DROP_ITEM_AREA 		= 100 			-- 丢弃道具深度
local Z_ACTIVE_WINDOW 		= 300 			-- 活动窗口
local Z_DIALOG_END 			= 400 			-- 对话框最低深度
local Z_DIALOG_START		= 500 			-- 对话框开始深度
local Z_RIGHT_CLICK_MENU	= 600 			-- 右键菜单
local Z_SCREEN_NOTIC		= 650			-- 跑马灯
local Z_TOOLTIP				= 700 			-- Tooltips

-- UI窗口出现范围(LEFT, RIGHT, ALL)
local WINDOW_APPEAR_LEFT	= 1 			-- 该面板出现在屏幕左边
local WINDOW_APPEAR_RIGHT	= 2 			-- 该面板出现在屏幕右边
local WINDOW_APPEAR_ALL		= 3 			-- 该面板是覆盖全画面
local WINDOW_DIALOG 		= 4 			-- 以dialog的方式出现在中间
local WINDOW_DIALOG_MODAL	= 5 			-- 模态dialog方式出现在中间

-- UI关闭方式
local CLOSE_HIDE			= 1 			-- 窗口关闭只隐藏
local CLOSE_DESTORY			= 2 			-- 窗口关闭销毁

local _current_left_window	= nil 			-- 出现在屏幕左边的界面的名字
local _current_right_window	= nil 			-- 出现在屏幕右边的界面的名字
local _current_all_window 	= nil 			-- 出现在全屏幕的界面的名字

local _ui_windows = {}						-- 记录已创建窗口
local _ui_windows_shown = {}				-- 记录正在显示的窗口
local _ui_dialogs_shown = {}				-- 记录正在显示的dialog


-- UI根节点
local _ui_root = nil

local _ui_dict = {}

local function _init()

	_ui_dict = {
	-- --UI层最底层的空白win
	-- base_win = {class = UIBackGroundWin, texture = "", x = 100, y = 100, z = 0, width = 100, height = 100},

	--以下业务层win的Z深度值必须大于等于1
	-- 登陆框
	login = {class = LoginWin, texture = "", x = 0, y = 0, z = Z_ACTIVE_WINDOW, width = 800, height = 480, close_type = CLOSE_DESTORY},		
	
}
end

--生成一个拖拽图标
function UIManager:create_drag_item(icon,point_x,point_y)
	require "scripts/UI/component/DragItem"
	if  self.drag_item ~= nil then
		UIManager:destory_drag_item();
	end
	self.drag_item = DragItem(48,48);
	self.drag_item.view:setEnableHitTest(false);  
	self.drag_item:set_icon_texture(icon);
	self.drag_item:setAnchor(0.5,0.5);
	self.drag_item:setPosition(point_x,point_y);
	_ui_root:addChild(self.drag_item.view,999);

	-- 动画效果
	local scale_act = CCScaleBy:actionWithDuration(.1, 1.6);
	-- local f_scale_act = CCScaleBy:actionWithDuration(.1, 1/1.6);
	-- local seq_act = CCSequence:actionOneTwo(scale_act, f_scale_act);
	self.drag_item.view:runAction(scale_act);

	--托管
	self.drag_item_id = _ui_root:addTouchMoveSprite(self.drag_item.view,self.drag_item.view);

end

--销毁拖拽图标
function UIManager:destory_drag_item( )
	if self.drag_item_id ~= nil then 
		_ui_root:removeTouchMoveSprite(self.drag_item_id);
		self.drag_item_id = nil;
		self.drag_item.view:removeFromParentAndCleanup(true);
		self.drag_item = nil;
	end
	
end

-- 根据关闭状态删除窗口
local function close_window( name )
	if name == nil then
		return 
	end
	local old_window = _ui_dict[name]
	if old_window and old_window.close_type == CLOSE_DESTORY then
		UIManager:destroy_window( name )
	else
		UIManager:hide_window( name )
	end
end

-- 将窗口置中
local function bring_window_center( window )
	local winSize = CCDirector:getInstance():getWinSize();
	local posx	= (winSize.width  - window:get_width() ) / 2.0
	local posy 	= (winSize.height - window:get_height()) / 2.0
	window:setPosition(posx, posy)
end

-- 将窗口置前
local function bring_window_front( window, z_order )
	_ui_root:removeChild(window.view, false)
	_ui_root:addChild(window.view, z_order)
end

-- UI管理器初始化
function UIManager:init( root )

	if _ui_root ~= nil then
		print("UI manager has been initialized!")
		return
	end

	_ui_root = root:getUINode()

    local function ui_main_msg_fun(eventType,x,y)
		if eventType == CCTOUCHBEGAN then 
			return true
		elseif eventType == CCTOUCHENDED then
            return true
		end
	end
	_ui_root:registerScriptTouchHandler(ui_main_msg_fun, false, 0, false)

	-- UI最底层的空地层
	local base_win = UIBackGroundWin:create("");
	_ui_root:addDragPanel(base_win.view);
	--引用减少1
	base_win.view:release()
	UnRegisterWindow(base_win)

	-- 初始化摇杆
	require "scripts/joystick/JoystickManager"
	JoystickManager:init(_ui_root, Z_JOYSTICK)			
	JoystickManager:set_visible(true)

	_init()
end

-- 创建窗口
-- 会申请内存，但不会渲染
function UIManager:create_window( window_name )	
	
	local window_info = _ui_dict[window_name]
	
	if window_info == nil then
		print(window_name .. " has not been registed!")
		return nil
	end

	local has_window = _ui_windows[window_name]
	if has_window ~= nil then
		print(window_name .. " has been created!")
		return has_window
	end
	print("UIManager:create_window", window_name)
	local new_window = window_info.class(window_name, window_info.texture, 
		window_info.x, window_info.y, window_info.width, window_info.height)
	_ui_windows[window_name] = new_window

	return new_window

end

-- 销毁窗口
function UIManager:destroy_window( window_name )
	local has_window = _ui_windows[window_name]
	if has_window == nil then
		print(window_name .. " has not been created!")
		return false
	end

	_ui_windows[window_name] = nil

	if _ui_windows_shown[window_name] ~= nil then
		_ui_windows_shown[window_name] = nil
		_ui_dialogs_shown[window_name] = nil
		_ui_root:removeChild(has_window.view, true)
	end	
    
	if _current_left_window == window_name then
		_current_left_window = nil
	end

	if _current_right_window == window_name then
		_current_right_window = nil
	end

	if _current_all_window == window_name then
		_current_all_window = nil
	end

	has_window:destroy()
	--CCTextureCache:getInstance():removeUnusedTextures();
	return true
end

-- 显示窗口
-- 可以直接调用，如果没创建，会自动创建
--	is_touch_other_close 是否点击其他地方关闭窗口
function UIManager:show_window( window_name ,is_touch_other_close)
	--print("UIManager:show_window( window_name ,is_touch_other_close)",window_name ,is_touch_other_close)
	local window_info = _ui_dict[window_name]
	if window_info == nil then
		print(window_name .. " has not been registed!")
		return nil
	end

	local window = UIManager:find_window(window_name)

	if window == nil then
		window = UIManager:create_window(window_name)
		if window == nil then
			return nil
		end
	end
	-----------add by hjh  2013-4-3
	-----------
	if window ~= nil then
		window.view:resumeChildAction()
	end
	-- 加上一个背景panel，当点击到窗口外面时会自动关掉窗口
	if ( is_touch_other_close ) then
		PopupView(_ui_root,window_name);
	end

	-- 要区分出现方式
	if window_info.appear_type ~= nil then
		-- 左界面
		if window_info.appear_type == WINDOW_APPEAR_LEFT then
			close_window(_current_all_window)
			_current_all_window = nil
			close_window(_current_left_window)
			_current_left_window = window_name
			window:setPosition(-window_info.width, 50)
		-- 右界面
		elseif window_info.appear_type == WINDOW_APPEAR_RIGHT then
			close_window(_current_all_window)
			_current_all_window = nil
			close_window(_current_right_window)
			_current_right_window = window_name
			window:setPosition(800, 50)
		-- 全界面
		elseif window_info.appear_type == WINDOW_APPEAR_ALL then
			close_window(_current_left_window)
			_current_left_window = nil
			close_window(_current_right_window)
			_current_right_window = nil
			close_window(_current_all_window)
			_current_all_window = window_name
			window:setPosition(19, 39)
		-- 对话框(非模态)
		elseif window_info.appear_type == WINDOW_DIALOG then
			_ui_dialogs_shown[window_name] = window
			local function dialog_click(  )
				bring_window_front(window, Z_DIALOG_START)
			end
			window:setTouchBeganFun(dialog_click)
			bring_window_center(window)
		-- 对话框(模态)
		elseif window_info.appear_type == WINDOW_DIALOG_MODAL then
			bring_window_center(window)
		end
	end

	
	if _ui_windows_shown[window_name] == nil then
		--_ui_root:addChild(window.view, window_info.z, window_name)
		_ui_root:addChild(window.view, window_info.z)
		_ui_windows_shown[window_name] = window

		window:active(true)
	end

	-- move effect
	if window_info.appear_type == WINDOW_APPEAR_LEFT then
		if window then
			window:move(window_info.x, window_info.y, WINDOW_APPEAR_LEFT);
		end
	elseif window_info.appear_type == WINDOW_APPEAR_RIGHT then
		if window then
			window:move(window_info.x, window_info.y, WINDOW_APPEAR_RIGHT);
		end
	end
	return window
end

-- 隐藏窗口
-- 只是取消渲染，不会删除窗口
function UIManager:hide_window( window_name )
	local window = UIManager:find_window(window_name)

	if window ~= nil then
		window:active(false)
		_ui_root:removeChild(window.view, true)
		_ui_windows_shown[window_name] = nil
		_ui_dialogs_shown[window_name] = nil
	end

	-- 判断popupview是否存在，存在就删除掉
	local popupview = _ui_root:getChildByTag(PopupView.TAG);
	if ( popupview ) then
		_ui_root:removeChild( popupview ,true);
	end

	if _current_left_window == window_name then
		_current_left_window = nil
	end

	if _current_right_window == window_name then
		_current_right_window = nil
	end

	if _current_all_window == window_name then
		_current_all_window = nil
	end

end

-- 开关窗口(仅调用show和hide)
function UIManager:toggle_window( window_name )
	if _ui_windows_shown[window_name] == nil then
		UIManager:show_window(window_name)
	else
		UIManager:hide_window(window_name)
	end
end

-- 找到窗口
function UIManager:find_window( window_name )
	return _ui_windows[window_name]
end

-- 找到显示的窗口
function UIManager:find_visible_window( window_name )
	return _ui_windows_shown[window_name]
end

---找到主消息窗口
function UIManager:get_main_panel()
	return _ui_root
end

-- 检测某一窗口当前状态
function UIManager:get_win_status(window_name)
	if (_ui_windows_shown[window_name] ~= nil) then
		return true;
	else 
		return false;
	end
end

-- 获取某一窗口当前对象指针
function UIManager:get_win_obj(window_name)
	return _ui_windows[window_name];
end
-- 小窗口坐标参数
-- direction: 0->left
function UIManager:small_win_param(direction)
	local win_param = {x=400, y=48, width=389, height=429};
	if (direction == 0) then
		win_param.x = 5;
	end
	return win_param;
end

-- 隐藏全部窗口
function UIManager:hide_all_window(  )
	for window_name, window in pairs(_ui_windows_shown) do
		UIManager:hide_window(window_name)
	end
end

--
function UIManager:close_all_window()
	if _current_left_window ~= nil then
		close_window(_current_left_window)
	end
	if _current_right_window ~= nil then
		close_window(_current_right_window)
	end
	if _current_all_window ~= nil then
		close_window(_current_all_window)
	end
end

-- 退出删除全部窗口
function UIManager:OnQuit(  )
	for window_name, window in pairs(_ui_windows) do
		window:destroy()
	end

	SceneLoadingWin:destroy_instance()
end