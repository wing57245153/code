--super_class.JoyStick()
JoyStick = {}



function JoyStick:init()    --单例初始化方法
	self.jsLayer = CCLayer:create();

	LayerManager:get_layer_joystick():addChild(self.jsLayer, 1)
	local rect = LayoutRect(CCPoint(0, 0))
	orpoint = rect:leftBottom()

	self:initWithCenter(orpoint.x + 80, orpoint.y + 80, 80)
	self._isMoving = false
	function tick()
		self:updatePos()
	end	
	CCDirector:getInstance():getScheduler():scheduleScriptFunc(tick, 0, false) 
end

function JoyStick:isMoving()
	return self._isMoving
end

function JoyStick:updatePos()
	
	local x, y = self.jsSprite:getPosition()
	local cur_point = CCPoint(self.currentPoint.x, self.currentPoint.y)
	local p = CCPoint.__add(CCPoint(x, y), CCPoint.__mul(CCPoint.__sub(cur_point, CCPoint(x, y)),0.5))
	self.jsSprite:setPosition(p.x, p.y)
end

function JoyStick:initWithCenter(posx, posy, aRadius)
	self.radius = aRadius
	self.centerPoint = CCPoint(aRadius, aRadius)
	self.currentPoint = CCPoint(aRadius, aRadius)	
	self.jsSprite = CCSprite:create(ResConfig.JOYSTICK_SP)
	self.bgSprite = CCSprite:create(ResConfig.JOYSTICK_BG)
	self.jsLayer:setPosition(CCPoint(posx, posy))
	--self.jsLayer:setSize(aRadius * 2.0, aRadius * 2.0)	
	self.jsSprite:retain()
	self.bgSprite:retain()
	self.jsSprite:setPosition(CCPoint(aRadius, aRadius))
	self.bgSprite:setPosition(CCPoint(aRadius, aRadius))
	self.jsLayer:addChild(self.bgSprite)
	self.jsLayer:addChild(self.jsSprite)


	local function onTouchMoved(x, y)	
		local layerPointX, layerPointY = self.jsLayer:getPosition()
		local touchPoint = 	CCPoint.__sub(CCPoint(x, y), CCPoint(layerPointX, layerPointY))
		self.currentPoint = touchPoint
		local dist = touchPoint:getDistance(self.centerPoint)

		if (dist > self.radius) then
			local tmpp = CCPoint.__sub(touchPoint, self.centerPoint):normalize()
			self.currentPoint = CCPoint.__add(self.centerPoint, CCPoint.__mul(tmpp, self.radius))
		end

		return true
	end   

	local function onTouchBegan(x, y)
		self._isMoving = true
		--有效范围判断
		local layerPointX, layerPointY = self.jsLayer:getPosition()
		--print("touch=", x, y, layerPointX, layerPointY)
		if x < layerPointY or y < layerPointY then
			return false
		end

		if (y > layerPointY + aRadius * 2) or ( x > layerPointX + aRadius * 2) then
			return false
		end

		local touchPoint = CCPoint.__sub(CCPoint(x, y), CCPoint(layerPointX, layerPointY))
		self.currentPoint.x = touchPoint.x;
		self.currentPoint.y = touchPoint.y;
		--onTouchMoved(x, y)
		return true
	end	
	  
	local function onTouchEnded(x, y)
		self._isMoving	= false
		self.currentPoint = CCPoint(self.centerPoint.x, self.centerPoint.y)
		return true
	end 	


    local function onTouch(eventType, x, y)
	    x = x / GameScaleFactors.ui_x
	    y = y / GameScaleFactors.ui_x    	
    	--print("touch layer_world", eventType, x, y);
        if eventType == "began" then  
        	return onTouchBegan(x, y)
        elseif eventType == "moved" then
        	return onTouchMoved(x, y)
        elseif eventType == "ended" then
           	return onTouchEnded(x, y)
        end
    end

    self.jsLayer:registerScriptTouchHandler(onTouch)
    self.jsLayer:setSwallowsTouches(true)
    self.jsLayer:setTouchEnabled(true)
end

function JoyStick:getVelocity()
	return self.centerPoint:getDistance(self.currentPoint)
end

function JoyStick:getDirection()
	if (self.currentPoint:equals(self.centerPoint) == true) then
		return CCPoint(0, 0)
	end
	local dx = self.currentPoint.x - self.centerPoint.y;
	local dy = self.currentPoint.y - self.centerPoint.y;	
	return CCPoint(dx, dy)
	--return CCPoint.__sub(self.currentPoint, self.centerPoint):normalize()
end

JoyStick:init()
