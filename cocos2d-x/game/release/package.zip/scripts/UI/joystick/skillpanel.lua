SkillPanel = {}

function SkillPanel:init()    --单例初始化方法
	local win_size = CCDirector:getInstance():getWinSize()
	self.bground = CCMenu:create()
	LayerManager:get_layer_ui():addChild(self.bground, 1)
    
    --local orpoint = VisibleRect:rightBottom()
    --self.bground:setPosition(orpoint.x - 100, orpoint.y + 100)
	self.bground:setPosition(win_size.width / GameScaleFactors.ui_x - 100, 100)
	self:initAllBtn()
end

function SkillPanel:initAttackBtn()
    function ClickAtk(sender)
        RoleAction:doCommonAttack(GameWorld.player())
    end
    local atkbg = CCMenuItemImage:create("images/skill/attackbg.png", "images/skill/attackbg.png")
    self.bground:addChild(atkbg)
    atkbg:registerScriptTapHandler(ClickAtk)  
    atkbg:setPosition(0, 0)

    local atkbg1 = CCMenuItemImage:create("images/skill/skillfg2.png", "images/skill/skillfg2.png")
    self.bground:addChild(atkbg1)
    atkbg1:registerScriptTapHandler(ClickAtk)  
    atkbg1:setPosition(0, 0)

    self.atkbtn = CCMenuItemImage:create("images/skill/attack.png", "images/skill/attack.png")
    self.atkbtn:registerScriptTapHandler(ClickAtk)  
    self.bground:addChild(self.atkbtn)
    self.atkbtn:setPosition(0, 0)
end

function SkillPanel:initSkillBtn(btnimg, posx, posy, clickfun)


    local fg = CCMenuItemImage:create("images/skill/skillfg1.png", "images/skill/skillfg1.png")
    if clickfun ~= nil then
        fg:registerScriptTapHandler(clickfun)  
    end  
    self.bground:addChild(fg)
    fg:setPosition(posx, posy)

    local bg = CCMenuItemImage:create("images/skill/skillbg1.png", "images/skill/skillbg1.png")
    if clickfun ~= nil then
        bg:registerScriptTapHandler(clickfun)    
    end
    self.bground:addChild(bg)
    bg:setPosition(posx, posy)   

    local skillbtn = CCMenuItemImage:create(btnimg, btnimg)
    if clickfun ~= nil then
        skillbtn:registerScriptTapHandler(clickfun)
    end    
    self.bground:addChild(skillbtn)
    skillbtn:setPosition(posx, posy)       
end

function SkillPanel:initPowBtn(posx, posy)
    local fg = CCMenuItemImage:create("images/skill/skillfg1.png", "images/skill/skillfg1.png")
    fg:registerScriptTapHandler(clickfun)    
    self.bground:addChild(fg)
    fg:setPosition(posx, posy)

    local bg = CCMenuItemImage:create("images/skill/skillbg1.png", "images/skill/skillbg1.png")
    bg:registerScriptTapHandler(clickfun)    
    self.bground:addChild(bg)
    bg:setPosition(posx, posy)  

    local btn = CCMenuItemImage:create("images/skill/burst.png", "images/skill/burst.png")
    self.bground:addChild(btn)
    btn:setPosition(posx, posy)


end

function SkillPanel:initAllBtn()

    self:initAttackBtn()
	function ClickSkill2(sender)
		--print("function ClickSkill")
        RoleAction:doFanAttack(GameWorld.player())       
	end

    function ClickSkill3(sender)
        RoleAction:doCrashAttack(GameWorld.player()) 
    end

    function ClickSkill1(sender)
        GameWorld.camera():scale(9)
        --RoleAction:doRoll(GameWorld.player())
    end
    self:initSkillBtn("images/skill/skill1.png", -135, -30, ClickSkill1)
    self:initSkillBtn("images/skill/skill2.png", -115, 55, ClickSkill2)
    self:initSkillBtn("images/skill/skill3.png", -55, 115, ClickSkill3)
    self:initSkillBtn("images/skill/skill4.png", 30, 135, ClickSkill2)
    self:initSkillBtn("images/skill/burst.png", 30, 250, nil)
   --self:initPowBtn(30, 250)

    --[[self.skillbtn1 = CCMenuItemImage:create("images/skill/skillbtn.png", "images/skill/skillbtn.png")
    self.skillbtn1:registerScriptTapHandler(ClickSkill1) 	
    self.bground:addChild(self.skillbtn1)
    self.skillbtn1:setPosition(-135, -30)

    self.skillbtn2 = CCMenuItemImage:create("images/skill/skillbtn.png", "images/skill/skillbtn.png")
    self.skillbtn2:registerScriptTapHandler(ClickSkill2) 	
    self.bground:addChild(self.skillbtn2)
    self.skillbtn2:setPosition(-115, 55)

    self.skillbtn3 = CCMenuItemImage:create("images/skill/skillbtn.png", "images/skill/skillbtn.png")
    self.skillbtn3:registerScriptTapHandler(ClickSkill3) 	
    self.bground:addChild(self.skillbtn3)
    self.skillbtn3:setPosition(-55, 115)

    self.skillbtn4 = CCMenuItemImage:create("images/skill/skillbtn.png", "images/skill/skillbtn.png")
    --self.skillbtn4:registerScriptTapHandler(ClickSkill2) 	
    self.bground:addChild(self.skillbtn4) 
    self.skillbtn4:setPosition(30, 135)    ]]   
end

SkillPanel:init() 