-- InitUI.lua
-- created by aXing on 2013-3-26
-- 这里将会将全部的UI统一加载，以便掌握加载进度

-- 控件基类
--require "scripts/UI/component/BaseComponent"
--require "scripts/UI/component/Window"

--require "scripts/UI/component/Button"
--require "scripts/UI/component/Scale9Sprite"

-- 最后require UIManager
-- ★这两句句一定要放最后
--require "scripts/UI/ComponenetUtil"
require "scripts/UI/UIManager"
