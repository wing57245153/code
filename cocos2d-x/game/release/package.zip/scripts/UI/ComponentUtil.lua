--------------------------------------------------------
-------- 组件工具 ------------
--------------------------------------------------------

require "scripts/config/ResConfig"
require "scripts/UI/component/SimpleButton"
require "scripts/UI/component/ExtScale9Sprite"
require "scripts/UI/component/ExtLabelTTF"
require "scripts/UI/component/ProgressBar"
require "scripts/UI/component/PageTurning"

ComponentUtil = { }

-- 创建简单按钮(CCMenu + CCMenuItemImage实现，不实用)
function ComponentUtil:CreateSimpleButton(type)
	local normal = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_NORMAL)
    local selected = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_SELECED)
    local disabled = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_DISABLED)
    local button = SimpleButton:create(normal, selected, disabled)
    return button
end

-- 创建按钮 CCControlButton
function ComponentUtil:CreateButton(label, type, btnSize, font, fontSize, fontColor)
	local normalSkinFilePath = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_NORMAL)
    local selectedSkinFilePath = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_SELECED)
    local disabledSkinFilePath = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_DISABLED)
    local highLightedSkinFilePath = ResConfig:GetButtonSkinResPath(type, ResConfig.BUTTON_SKIN_HIGHLIGHTED)

    local normalSkin = CCScale9Sprite:create(normalSkinFilePath)
    local selectedSkin = CCScale9Sprite:create(selectedSkinFilePath)
    local disabledSkin = CCScale9Sprite:create(disabledSkinFilePath)
    local highLightedSkin = CCScale9Sprite:create(highLightedSkinFilePath)

    btnSize = btnSize or normalSkin:getContentSize()
    normalSkin:setPreferredSize(btnSize)
    selectedSkin:setPreferredSize(btnSize)
    disabledSkin:setPreferredSize(btnSize)
    highLightedSkin:setPreferredSize(btnSize)

    local pTitleButton = nil
    if nil ~= label then
    	font = font or "Marker Felt"
    	fontSize = fontSize or 20
    	fontColor = fontColor or Color3B(159, 168, 176)
    	pTitleButton = CCLabelTTF:create(label, font, fontSize)
    	pTitleButton:setColor(fontColor)
    end

    local pButton = nil
    if nil == pTitleButton then
        pButton = CCControlButton:create(normalSkin)
    else
        --pTitleButton:setPosition(CCPoint(10,10))
        pButton = CCControlButton:create(pTitleButton, normalSkin)
        --pButton:setLabelAnchorPoint(CCPoint(0.5, 0.5))
    end
    pButton:setBackgroundSpriteForState(selectedSkin, CCControlStateNormal)
    pButton:setBackgroundSpriteForState(disabledSkin, CCControlStateSelected)
    pButton:setBackgroundSpriteForState(highLightedSkin, CCControlStateHighlighted)
    local point = pButton:getLabelAnchorPoint()
    --print("CCControlButton AnchorPoint x=",point.x, "y=",point.y)
    --pButton:setTitleColorForState(Color3B(255,255,255), CCControlStateHighlighted)
   -- pButton:setMargins(20, 10)
    pButton:setPreferredSize(btnSize)
    return pButton
end


-- 创建九宫格位图
function ComponentUtil:CreateScale9Sprite(resName, size, rect)
	local name = ResConfig:GetBackgroundSkinResPath(resName)
    local scale9 = ExtScale9Sprite:create(name, size, rect)
    return scale9
end


-- 创建静态文本
function ComponentUtil:CreateLabelTTF(content, fontName, fontSize, color, dimensions)
	if (dimensions == nil) then
		dimensions = CCSize(100, 20)
	end
	if (color == nil) then
		color = Color3B(255, 255, 255)
	end

    fontName = fontName or "Marker Felt"
    fontSize = fontSize or 16

    local labelTTF = ExtLabelTTF:create(content, fontName, fontSize, color, dimensions)
    return labelTTF
end

-- 创建进度条
function ComponentUtil:CreateProgressBar(type)
	local track = ResConfig:GetProgressBarSkinResPath(type, ResConfig.PROGRESSBAR_SKIN_TRACK)
    local progress = ResConfig:GetProgressBarSkinResPath(type, ResConfig.PROGRESSBAR_SKIN_PROGRESS)
    local thumb = ResConfig:GetProgressBarSkinResPath(type, ResConfig.PROGRESSBAR_SKIN_THUMB)
    local progressBar = ProgressBar:create(track, progress, thumb)
    return progressBar
end

-- 创建翻页控件
function ComponentUtil:CreatePageTurning(currentPage, preparativePage, totalPageNum)
    local pageTurning = PageTurning:create(currentPage, preparativePage, totalPageNum)
    return pageTurning
end
