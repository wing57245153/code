------------------------------------------------
------ 
------ Liu 2013/09/05
------------------------------------------------

super_class.UserBase(BaseComponent)

function UserBase:__init()
	self.id = nil  -- 模块id
	self.bg = nil  -- 模块底图
	self.module = nil
	self:initUIContainer()
	self:initUIComponent()
	self:registerTouchHandler()
	LayerManager:get_layer_user():addChild(self.view, 1)
end

function UserBase:initUIContainer()
	self.view = CCNode:create()
end

function UserBase:initUIComponent()
	
end

function UserBase:isInit()
	return self.view ~= nil
end

function UserBase:setModule(module)
	self.module = module
	print("Window:setModule", module)
end

function UserBase:depose()
	if self:isInit() then
		self:unregisterTouchHandler()
		self.view:removeAllChildrenWithCleanup(true)
		self.view:removeFromParentAndCleanup(true)
	end
end

function UserBase:registerTouchHandler()
	print("UserBase:registerTouchHandler")
end

function UserBase:unregisterTouchHandler()
	print("UserBase:unregisterTouchHandler")
end