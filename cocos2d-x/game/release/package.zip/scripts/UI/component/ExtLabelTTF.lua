require "scripts/config/numeric_config"

--------------------------------------------
-------- 静态文本 ----------------------------
--------------------------------------------

super_class.ExtLabelTTF()

-- 创建文本
function ExtLabelTTF:create(content, fontName, fontSize, color, dimensions)
	local labelTTF = CCLabelTTF:create(content, fontName, fontSize)
	labelTTF:setColor(color)

	local ccBlack = Color3B(0, 0, 0)
	local stroke = self:createStroke(labelTTF, 1, ccBlack)

	local labelTTFObj = ExtLabelTTF()
	labelTTFObj.view = CCNode:create()
	labelTTFObj.view:addChild(stroke)
	labelTTFObj.view:addChild(labelTTF)
	return labelTTFObj
end

function ExtLabelTTF:createStroke(label, size, color)
	local x = label:getTexture():getContentSize().width + size * 2
	local y = label:getTexture():getContentSize().height + size * 2
	local renderTexture = CCRenderTexture:create(x, y)
	local originalPosX = label:getPositionX()
	local originalPosY = label:getPositionY()
	local originalColor = label:getColor()
	label:setColor(color)
	local originalBlend = label:getBlendFunc()
	local newOriginalBlend = BlendFunc()
	newOriginalBlend.src = numeric_config.GL_SRC_ALPHA
	newOriginalBlend.dst = numeric_config.GL_ONE
	label:setBlendFunc(newOriginalBlend)
	local center = CCPoint(x / 2 + size, y / 2 + size)
	renderTexture:begin()
	for i = 0, 360, 15 do
		local _x = center.x + math.sin(numeric_config:degrees_to_radians(i)) * size
		local _y = center.y + math.cos(numeric_config:degrees_to_radians(i)) * size
		label:setPosition(CCPoint(_x, _y))
		label:visit()
	end
	renderTexture:endToLua()
	label:setPosition(CCPoint(originalPosX, originalPosY))
	label:setColor(originalColor)
	label:setBlendFunc(originalBlend)
	local rtX = originalPosX - size
	local rtY = originalPosY - size

	renderTexture:setPosition(CCPoint(rtX, rtY))
	return renderTexture
end

function ExtLabelTTF:__init()
	self.view = nil
end

function ExtLabelTTF:setPosition(x, y)
	if self.view ~= nil then
		self.view:setPosition(x, y)
	end
end
