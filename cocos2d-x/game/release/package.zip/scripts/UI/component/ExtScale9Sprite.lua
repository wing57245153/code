require "scripts/UI/component/AbstractBase"

--------------------------------------------
-------- 九宫格 ----------------------------
--------------------------------------------

super_class.ExtScale9Sprite(AbstractNode)

-- 创建九宫格
-- bitmapName 资源路径
-- size 目标大小
-- rect 缩放控制矩形 
function ExtScale9Sprite:create(bitmapName, size, rect)
	local scale9Bm = CCScale9Sprite:create(bitmapName, self:GetOriginalRect(), rect)
	local scale9Obj = ExtScale9Sprite()
	scale9Obj.view = scale9Bm
	scale9Obj:setContentSize(size)
	--scale9Obj:registerScriptTapHandler()
	return scale9Obj
end

function ExtScale9Sprite:__init()
	self.view = nil
end

-- CCSize(100,100)
function ExtScale9Sprite:setContentSize(size)
	if self.view ~= nil then
		self.view:setContentSize(size)
	end
end

function ExtScale9Sprite:GetOriginalRect()
	return CCRect(0,0,338,458)
end

