
---------通用控件
---------
----------------------------------------------------------------------
----------------------------------------------------------------------
---------
---------AbstractBasePanel类
super_class.AbstractNode()
---------
---------
function AbstractNode:__init()
	-- self.father_panel = fatherPanel
	self.view = nil
	--self.createItemList = {}
	-------
	-------touch begin info
	self.touch_begin_return = true
	self.touch_begin_fun = nil
	-------
	-------touch end info
	self.touch_end_return = true
	self.touch_end_fun = nil
	-------
	-------touch move info
	self.touch_move_return = true
	self.touch_move_fun = nil
	-------
	-------touch cancel info
	self.touch_cancel_return = true
	self.touch_cancel_fun = nil
	-------
	-------touch double click info
	self.touch_double_click_return = true
	self.touch_double_click_fun = nil
	-------

	self.touch_click_return = true
	self.touch_click_fun = nil
end
---------
---------
function AbstractNode:create()
	 return AbstractNode()
end
---------
---------
---------设置TOUCH_BEGAN函数
function AbstractNode:setTouchBeganFun(userFunction)
	self.touch_begin_fun = userFunction
end
---------
---------设置TOUCH_BEGIN返回值
function AbstractNode:setTouchBeganReturnValue(returnValue)
	self.touch_begin_return = returnValue
end
---------
---------设置TOUCH_MOVED函数
function AbstractNode:setTouchMovedFun(userFunction)
	print("AbstractNode:setTouchMovedFun", userFunction)
	self.touch_move_fun = userFunction
end
---------
---------设置TOUCH_MOVED返回值
function AbstractNode:setTouchMovedReturnValue(returnValue)
	self.touch_move_return = returnValue
end
---------
---------设置TOUCH_ENDED函数
function AbstractNode:setTouchEndedFun(userFunction)
	self.touch_end_fun = userFunction
end
---------
---------设置TOUCH_ENDED返回值
function AbstractNode:setTouchEndedReturnValue(returnValue)
	self.touch_end_return = returnValue
end
---------
---------设置TOUCH_CANCEL函数
function AbstractNode:setTouchCancelFun(userFunction)
	self.touch_cancel_fun = userFunction
end
---------
---------设置TOUCH_CANCEL返回值
function AbstractNode:setTouchCancelReturnValue(returnValue)
	self.touch_cancel_return = returnValue
end
---------
---------设置TOUCH_CLICK函数
function AbstractNode:setTouchClickFun(userFunction)
	print("setTouchClickFun=", userFunction)
	self.touch_click_fun = userFunction
end
---------
---------设置TOUCH_CLICK返回值
function AbstractNode:setTouchClickReturnValue(returnValue)
	self.touch_click_return = returnValue
end
---------设置TOUCH_DOUBLE_CLICK函数
function AbstractNode:setTouchDoubleClickFun(userFunction)
	self.touch_double_click_fun = userFunction
end
---------
---------设置TOUCH_DOUBLE_CLICK返回值
function AbstractNode:setTouchDoubleClickReturnValue(returnValue)
	self.touch_double_click_return = returnValue
end
---------
---------
function AbstractNode:setPosition(x, y)
	if self.view ~= nil then
		self.view:setPosition(x, y)
	end
end
---------
---------
function AbstractNode:getPosition()
	if self.view ~= nil then
		return self.view:getPositionS()
	end
end
---------
---------设置锚点
function AbstractNode:setAnchorPoint(pos)
	if self.view ~= nil then
		self.view:setAnchorPoint(pos)
	end
end
---------
----------------------------------------------------------------------
---------抽像BasePanel类消息注册方法
function AbstractNode:registerScriptTapHandler()
	if self.view ~= nil then
		local function baseScriptTouchHandler(eventType, x, y)
			local args = {x=x, y=y}
			-------
			if eventType == nil then
				print("eventType == nil")
				return 
			end

			-------
			if eventType == EVENT_TOUCH_BEGAN then
				if self.touch_begin_fun ~= nil then
					self:touch_begin_fun(args)
				end
				return self.touch_begin_return
			elseif eventType == EVENT_TOUCH_MOVED then
				if self.touch_move_fun ~= nil then
					self:touch_move_fun(args)
				end
				return self.touch_move_return
			elseif eventType == EVENT_TOUCH_ENDED then
				if self.touch_end_fun ~= nil then
					self:touch_end_fun(args)
				end
				return self.touch_end_return
			elseif eventType == EVENT_TOUCH_CANCELLED then
				if self.touch_cancel_fun ~= nil then
					self:touch_cancel_fun(args)
				end
				return self.touch_cancel_return
			end
		end
		-------
		print("self.view:registerScriptTapHandler++++++++++++++++")
		self.view:registerScriptTouchHandler(baseScriptTouchHandler)
	end
end
-- ---------

---------
----------------------------------------------------------------------
----------------------------------------------------------------------