-- Window.lua
-- created by aXing on 2013-4-20
-- 窗口基类，不可穿透的窗口控件

require "scripts/core/Layer"
require "scripts/UI/ComponentUtil"
require "scripts/config/win_config"


super_class.Window(BaseComponent)

function Window:__init(...)
	self:setAttributesNil()
end

function Window:setAttributesNil()
	self.id = nil  --窗口的唯一标识
	self.bg = nil  --窗口视图背景
	self.view = nil  --窗口视图容器
	self.parent = nil --窗口视图父容器
	self.config = nil --窗口配置信息
	self.closeBtn = nil --关闭按钮
	self.titleLabel = nil --窗口标题
	self.module = nil
	--self.buttonContainer = nil --按钮容器 CCMenu
end

function Window:initWindow(...)
	self:initWindowContainer()  --窗口content容器
	self:initConfigData()  --窗口的配置信息
	self:initBackground()  --添加窗口背景图
	self:initCloseButton()  --添加关闭按钮
	self:initWindowTitle()  --窗口标题
	self:initUIComponent()  --窗口界面组件
	self:registerTouchHandler()  --注册事件处理函数
end

function Window:initConfigData()
	local config = win_config:getWinConfig(self.id)
	self.config = {}
	self.config.closeBtnName = config[1]
	self.config.modal = config[2]
	self.config.bgName = config[3]
	self.config.title = config[4]
	self.config.transition = config[5]
	self.config.autoRelease = config[6]
	--print("init Window:initConfigData Window ID =", self.id)
end

-- 窗口content容器
function Window:initWindowContainer()
	self.view = CCNode:create()
	self.view:setAnchorPoint(CCPoint(0, 0))
end

function Window:initBackground()
	if nil == self.config.bgName then
		return
	end

	self.bg = ComponentUtil:CreateScale9Sprite(self.config.bgName, self:getFrameSize(), CCRect(50,30,238,398))
	self.bg.view:setAnchorPoint(CCPoint(0, 0))
	self.view:addChild(self.bg.view, 0)
end

function Window:getFrameSize()
	require "scripts/core/Layer"
	return CCSize(GameScreenFactors.standard_width, GameScreenFactors.standard_height)
end


function Window:initCloseButton()
	if nil == self.config.closeBtnName then
		return
	end

    local function onCloseWindow(sender)
    	if self.config.autoRelease then
    		print("depose window")
    		self.module:destroyWindow()
    	else
    		print("depose window")
    		self.module:hideWindow()
    	end
    end

	self.closeBtn = ComponentUtil:CreateButton(nil, self.config.closeBtnName)
	self.closeBtn:registerControlEventHandler(onCloseWindow, CCControlEventTouchDown)
	self.closeBtn:setAnchorPoint(CCPoint(1, 1))
	self.view:addChild(self.closeBtn)
	self:setCloseBtnPosition()
end

function Window:setCloseBtnPosition()
	if self.closeBtn ~= nil then
		require "scripts/utils/LayoutRect"
		local rect = LayoutRect()
		local x = rect:rightTop().x - 16
		local y = rect:rightTop().y - 10
		self.closeBtn:setPosition(CCPoint(x, y))
	end
end

-- 窗口标题
function Window:initWindowTitle()
	if nil == self.config.title then
		return
	end

	self.titleLabel = ComponentUtil:CreateLabelTTF(self.config.title)
	self.view:addChild(self.titleLabel.view)
	self:setWindowTitlePositon()
end

function Window:setWindowTitlePositon()
	if self.titleLabel ~= nil then
		require "scripts/utils/LayoutRect"
		local rect = LayoutRect()
		local x = rect:top().x
		local y = rect:top().y - 23
		self.titleLabel.view:setPosition(CCPoint(x, y))
	end
end

function Window:initUIComponent()
	--print("init Window:initUIComponent")
end

function Window:getParent(_parent)
	local _default = LayerManager:get_layer_ui()
	return _parent or _default
end

-- 窗口是否已经初始化
function Window:isInit()
	return nil ~= self.view
end

function Window:autoRelease()
	return self.config.autoRelease
end

-- 窗口是否可视
function Window:isVisible()
	return self.view and self.view:isVisible()
end

function Window:setVisible(visible)
	if self:isInit() then
		self.view:setVisible(visible)
	end
end

function Window:setModule(module)
	self.module = module
	print("Window:setModule", module)
end

-- 设置窗口大小
function Window:setWindowSize(size)
	if self:isInit() then
		self.view:setContentSize(size)
	end
end

-- 设置窗口位置
function Window:setPosition(_x, _y)
	self.view:setPosition(_x, _y)
end

function Window:setAnchorPoint(ccp)
	self.view:setAnchorPoint(ccp)
end

-- 打开窗口
function Window:open(_parent, ...)
	if self:isInit() then
		self:registerTouchHandler()
		self:setVisible(true)
		self.parent = self:getParent(_parent)
		self.parent:addChild(self.view)
		print("open window", self.id)
	end
end

-- 关闭窗口
function Window:close()
	if self:isInit() then
		if self:autoRelease() then
			self:depose()
		else
			self:unregisterTouchHandler()
			self:setVisible(false)
		end
		print("close window", self.id)
	end
end

-- 释放窗口资源
function Window:depose()
	if self:isInit() then
		self:unregisterTouchHandler()
		self.view:removeAllChildrenWithCleanup(true)
		self.view:removeFromParentAndCleanup(true)
		self:setAttributesNil()
		print("depose window", self.id)
	end
end



-- 窗口控件添加触摸事件处理函数, 具体窗口类覆盖此方法
function Window:registerTouchHandler()
	print("Window:registerTouchHandler")
end

function Window:unregisterTouchHandler()
	print("Window:unregisterTouchHandler")
end