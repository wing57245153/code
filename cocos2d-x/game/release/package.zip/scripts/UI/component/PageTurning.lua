require "scripts/UI/component/AbstractBase"

--------------------------------------------
-------- 翻页容器 --------------------------
--------------------------------------------

super_class.PageTurning(AbstractNode)

local TOUCH_SENSITIVITY = 20
local ScrollDirectionEnum = 
{
    SCROLLDIRECTION_LEFT 	= 0,
    SCROLLDIRECTION_RIGHT 	= 1,
    SCROLLDIRECTION_TOP     = 2,
    SCROLLDIRECTION_BOTTOM  = 3
}

function PageTurning:create(currentPage, preparativePage, totalPageNum)
	local pageTurningObj = PageTurning()
	pageTurningObj.view = currentPage
	pageTurningObj.view:setTouchEnabled(true)
	pageTurningObj._currentPageNum = 1
	pageTurningObj._totalPageNum = totalPageNum
	pageTurningObj._preparativePage = preparativePage
	pageTurningObj:setTouchBeganFun(self.touchBegan)
	pageTurningObj:setTouchMovedFun(self.touchMove)
	pageTurningObj:setTouchEndedFun(self.touchEnd)
	pageTurningObj:registerScriptTapHandler()
	return pageTurningObj
end

function PageTurning:__init()
	self.view = nil
	self._currentPageNum = 1
	self._totalPageNum = 1
	self._preparativePage = nil
	self._touchPointBegan = CCPoint(0, 0)
	self._scrollDirection = 0
	self._canTouchMove = false
end

function PageTurning:unregisterScriptTapHandler()
	if self.view ~= nil then
		self.view:unregisterScriptTapHandler()
	end
end

function PageTurning:touchBegan(argument)
	print ("TouchBegan: ", argument.x, argument.y)
	self._canTouchMove = true
	self._touchPointBegan.x = argument.x
	self._touchPointBegan.y = argument.y
end

function PageTurning:touchMove(argument)
	if (self._canTouchMove == false) then
		return
	end

	print ("TouchMove: ", argument.x, argument.y)
	local offset = argument.x - self._touchPointBegan.x
	print ("offset", offset)
	if (offset > TOUCH_SENSITIVITY or offset < -TOUCH_SENSITIVITY) then
		if (offset > 0) then
			self._scrollDirection = ScrollDirectionEnum.SCROLLDIRECTION_LEFT
		else
			self._scrollDirection = ScrollDirectionEnum.SCROLLDIRECTION_RIGHT
		end
		self:doMoveAction()
		self._canTouchMove = false
	end
end

function PageTurning:doMoveAction()
	-- body
end

function PageTurning:touchEnd(argument)
	print ("TouchEnd: ", argument.x, argument.y)
	self._canTouchMove = true
end

