--------------------------------------------
-------- 进度条 ----------------------------
--------------------------------------------

super_class.ProgressBar()


-- 进度条
function ProgressBar:create(track, progress, thumb)
	local controlSlider = CCControlSlider:create(track, progress, thumb)
	--local backgroundSprite = CCSprite:create(track)
	--local progressSprite = CCSprite:create(progress)
	--controlSlider:setBackgroundSprite(backgroundSprite)
	--controlSlider:setProgressSprite(progressSprite)
	--if (thumb ~= "") then
		--local thumbSprite = CCSprite:create(thumb)
		--controlSlider:setThumbSprite(thumbSprite)
	--end
	controlSlider:setMinimumValue(0)
	controlSlider:setMaximumValue(100)
	controlSlider:setValue(0)

	controlSlider:setTouchEnabled(false)

	local progressBarObj = ProgressBar()
	progressBarObj.view = controlSlider
	return progressBarObj
end


function ProgressBar:__init()
	self.view = nil
end

function ProgressBar:setPosition(x, y)
	if self.view ~= nil then
		self.view:setPosition(x, y)
	end
end

function ProgressBar:setMinimumValue(value)
	self.view:setMinimumValue(value)
end

function ProgressBar:setMaximumValue(value)
	self.view:setMaximumValue(value)
end

function ProgressBar:setValue(value)
	self.view:setValue(value)
end
