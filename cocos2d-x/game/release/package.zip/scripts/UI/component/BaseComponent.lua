-- BaseComponent.lua
-- created by aXing on 2013-4-20
-- 控件基类
-- 主要是封装一下基础控件的一些消息注册方法
-- 传统的cocos消息注册太繁琐，所以需要封装一下
-- 继承CCLayer

super_class.BaseComponent()

-- 所有控件的初始化函数
function BaseComponent:__init(  )
	self._click_event 			= nil	-- 单击事件
	self._double_click_event	= nil	-- 双击事件
end

function BaseComponent:regist_touch_event(  )
	if self.view ~= nil then
		local function onTouch(eventType, x, y)
            if eventType == "began" then   
                return onTouchBegan(x, y)
            elseif eventType == "moved" then
                return onTouchMoved(x, y)
            else
                return onTouchEnded(x, y)
            end
        end
		self.view:registerScriptTouchHandler(messageHandler)
		self.view:setTouchEnabled(true)
	end
end

function BaseComponent:set_touch_enabled( enable )
	if self.view ~= nil then
		self.view:setTouchEnabled(enable)
	end
end

function BaseComponent:set_click_event( fn )
	self._click_event = fn
end

function BaseComponent:set_double_click_event( fn )
	self._double_click_event = fn
end