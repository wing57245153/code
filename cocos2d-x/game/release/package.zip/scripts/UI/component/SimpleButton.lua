require "scripts/UI/component/AbstractBase"

-------------------------------------------------
-------- 简单按钮 --------
-------------------------------------------------
super_class.SimpleButton(AbstractNode)

function SimpleButton:create(normalSkinFileName, selectedSkinFileName, diabledSkinFileName)
	local buttonView = CCMenuItemImage:create(normalSkinFileName, selectedSkinFileName, diabledSkinFileName)
	local buttonObj = SimpleButton()
	buttonObj.view = buttonView
	buttonObj:registerScriptTapHandler()
	return buttonObj
end

function SimpleButton:__init()
	self.touch_click_return = false
end

function SimpleButton:getBody()
	return self.view
end

function SimpleButton:registerScriptTapHandler()
	if self.view ~= nil then
		local function baseScriptTouchHandler(eventType, x, y)
			--print("eventType =", eventType, "x =",x, "y =",y)
			if self.touch_click_fun ~= nil then
				self:touch_click_fun(args)
			end
			return self.touch_click_return
		end
		self.view:registerScriptTapHandler(baseScriptTouchHandler)
	end
end

function SimpleButton:unregisterScriptTapHandler()
	if self.view ~= nil then
		self.view.unregisterScriptTapHandler()
	end
end