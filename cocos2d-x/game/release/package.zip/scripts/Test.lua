require "scripts/data/AllData.lua"
require "scripts/modules/avatar/AvatarModule"
require "scripts/core/AppEvent" 
require "scripts/core/BasicModule" 
require "scripts/core/ModuleManager" 
require "scripts/core/DataManager"

require "scripts/utils/LayoutRect"
require "scripts/UI/joystick/joystick"
require "scripts/UI/joystick/skillpanel"
require "scripts/effect/PopDamage"
require "scripts/role/RoleAction"
require "scripts/modules/myhead/MyHeadView"
require "scripts/modules/monsterhead/MonsterHeadView"
require "scripts/modules/minimap/MiniMapView"
require "scripts/AI/AIFactory"

local ent;


function test_game()

	local cam = GameWorld.create_camera();
	GameWorld.camera(cam);
	
	local att = {};
	att.map_id = 2;
	att.model = "testxx";
	local entid = GameWorld.create_entity("PlayerAvatar", att);
	ent = GameWorld.entities()[entid];
	--for attname, attvalue in pairs(GameWorld.entities()) do
	--	print("entities----", attname, attvalue)
	--end
	ent:set_position(1100,1100);

	cam:set_target(ent);

	local t = timer()
	t:start(10,update)

	ModuleManager() --暂时测试地方
	--GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "AvatarModule")
	--GameWorld.gameBus():dispatchEvent(DATA_AVATAR__EVENT, DATA_AVATAR__EVENT, "data...hah")
	--local data = GameWorld.dataPool():getAvatarData()
	--data:read()
	GameWorld.gameSocket()

end

function update()

	--ent:set_position(ent:get_position().x+1,ent:get_position().y+1);

	--ent:move(math.random(0, 3000), math.random(0,3000));
end

test_game();