require "scripts/core/Layer"

local debugLabel = CCLabelTTF:create("", "Arial", 22)
LayerManager.layer_debug:addChild(debugLabel)

local debugStr = ""
function debugOutput(str)
	debugStr = "[debug]:" .. debugStr .. str .. "\n"
    debugLabel:setString( debugStr )
    
    local win_size = CCDirector:getInstance():getWinSize()
    local y = win_size.height - debugLabel:getContentSize().height
    debugLabel:setPosition(debugLabel:getContentSize().width / 2, y)
end