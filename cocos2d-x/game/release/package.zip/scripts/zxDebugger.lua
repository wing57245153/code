local _print = print


function xprint( ... )
	_print(...)
	local debug_table = {}
	local t = debug.getinfo(2,'Sl')

	debug_table[#debug_table + 1] = string.format('@%s:%s',tostring(t.short_src),tostring(t.currentline))
	_print(table.concat(debug_table))
	_print('-----------------------')
end

--print = xprint
function print_detail(prefix, message, level, func)
	local t = debug.getinfo(level,'Sln')
	
	if not t then return false end

	local debug_table = {}

	for k,v in pairs(t) do
	   if v and k == 'name' or k == 'currentline' or k =='short_src' then
		  	debug_table[#debug_table + 1] = string.format('%s=%s',tostring(k),tostring(v))
	   end
	end

	func(string.format('%s: {%s}',prefix,table.concat(debug_table,' ')))
	return true
end

function debug_c_callhook()

	local t = debug.getinfo(2,'S')
	if t and t.what == 'C' then
		print_detail('>','',3,_print)

		for level = 4, math.huge do
			if not print_detail('>','',level,_print) then break end
		end
		_print('--------------------------')
	end
end

function debug_hook(state)
	if state then
		debug.sethook(debug_c_callhook,'c')
	else
		debug.sethook(nil,'c')
	end
end