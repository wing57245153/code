
require "scripts/config/win_config"

module_config = {}

function module_config.createAvatarModule()
	print("createAvatarModule")
	require "scripts/modules/avatar/AvatarModule"
	local m = AvatarModule()
	return m
end

function module_config.createBagModule()
	print("createBagModule")
	require "scripts/modules/bag/BagModule"
	local m = BagModule()
	return m
end

function module_config.createMiniMapModule()
	print("createMiniMapModule")
	require "scripts/modules/minimap/MiniMapModule"
	local m = MiniMapModule()
	return m
end

function module_config:createLoginModule( ... )
	print("createLoginModule")
	require "scripts/modules/login/LoginModule"
	local m = LoginModule()
	return m
end

function module_config:createRoleListModule()
	print("createLoginModule")
	require "scripts/modules/roleList/RoleListModule"
	local m = RoleListModule()
	return m
end

------- 窗口模块
module_config.AVATAR_MODULE = "AvatarModule"
module_config.BAG_MODULE = "BagModule"
module_config.LOGIN_MODULE = "LoginModule"
module_config.ROLELIST_MODULE = "RoleListModule"

------- 
module_config.MINIMAP_MODULE = "MiniMapModule"



module_config[module_config.AVATAR_MODULE] = 
    {["name"] = module_config,AVATAR_MODULE, ["fun"] = module_config.createAvatarModule, ["id"] = win_config.AVATAR}

module_config[module_config.BAG_MODULE] = 
    {["name"] = module_config.BAG_MODULE, ["fun"] = module_config.createBagModule, ["id"] = win_config.BAG}

module_config[module_config.MINIMAP_MODULE] = 
    {["name"] = MINIMAP_MODULE, ["fun"] = module_config.createMiniMapModule, ["id"] = 20000}

module_config[module_config.LOGIN_MODULE] = 
    {["name"] = LOGIN_MODULE, ["fun"] = module_config.createLoginModule, ["id"] = 20001}

module_config[module_config.ROLELIST_MODULE] = 
    {["name"] = ROLELIST_MODULE, ["fun"] = module_config.createRoleListModule, ["id"] = 20001}

