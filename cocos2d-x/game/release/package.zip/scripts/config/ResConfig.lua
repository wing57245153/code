ResConfig = {}

--------Skin Button--------
ResConfig.BUTTON_RES_ROOT_PATH = "ui/button/"
ResConfig.BUTTON_SKIN_NORMAL = "normal.png"
ResConfig.BUTTON_SKIN_SELECED = "selected.png"
ResConfig.BUTTON_SKIN_DISABLED = "disabled.png"
ResConfig.BUTTON_SKIN_HIGHLIGHTED = "highlighted.png"

--------Skin Background--------
ResConfig.BACKGROUND_SKIN_ROOT_PATH = "ui/background/"

--------Skin ProgressBar--------
ResConfig.PROGRESSBAR_SKIN_ROOT_PATH = "ui/progressbar/"
ResConfig.PROGRESSBAR_SKIN_TRACK = "track.png"
ResConfig.PROGRESSBAR_SKIN_PROGRESS = "progress.png"
ResConfig.PROGRESSBAR_SKIN_THUMB = "thumb.png"


--------JoyStick---------------
ResConfig.JOYSTICK_SP = "images/joystick/js_sp.png"
ResConfig.JOYSTICK_BG = "images/joystick/js_bg.png"


--获取按钮资源路径
function ResConfig:GetButtonSkinResPath(type, resName)
	return self.BUTTON_RES_ROOT_PATH .. type .. "/" .. resName
end

function ResConfig:GetBackgroundSkinResPath(resName)
	return self.BACKGROUND_SKIN_ROOT_PATH .. resName .. ".png"
end

function ResConfig:GetProgressBarSkinResPath(type, resName)
	return self.PROGRESSBAR_SKIN_ROOT_PATH .. type .. "/" .. resName
end
