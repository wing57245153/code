﻿
action_config = {};

action_config.STATE_STAND = "stand";
action_config.STATE_WALK = "walk";
action_config.STATE_BEATTACKED = "beattacked";
action_config.STATE_DIE = "die";
action_config.STATE_SIT = "sit";
action_config.STATE_ATTACK = "attack";
action_config.STATE_ATTACK1 = "attack1";
action_config.STATE_ATTACK2 = "attack2";
action_config.STATE_ATTACK3 = "attack3";
action_config.STATE_ATTACK4 = "attack5";
action_config.STATE_ROLL = "roll";

--方向向量定义，用于索引信息          向下     右下     向右     右上    向上    左上      向左      左下
action_config.DIRETIONS =           {{0, -1}, {1, -1}, {1, 0}, {1,  1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}};

action_config.DIRETIONS_MAP = {
							[0] = {[-1] = 1, [1] = 5 };
							[1] = {[1] = 2, [0] = 3, [-1] = 4};
							[-1] ={[-1] = 6, [0] = 7, [1] = 8};
}

--方向对应的反向配置
action_config.REVERSES  = 			{  1,      1,     1,        1,       1,        -1,        -1,      -1} ;

--方向对应的动作后缀名
action_config.DIRETIONS_NAME =     {"down","rightup","right","rightdown","up","rightdown","right","rightup"};



--计算方向
function action_config.cal_direction(px1, py1, px2, py2)
	--local dtx = gameutils.x_pos_2_tile(px2) - gameutils.x_pos_2_tile(px1);
	--local dty = gameutils.y_pos_2_tile(py2) - gameutils.y_pos_2_tile(py1);
	local dtx = px2 - px1
	local dty = py2 - py1
	local result = action_config.get_direction_by_xy(dtx, dty);
	
	return result
end


function action_config.get_xy_by_direction(dir)
	local d =  {
					[1] = {0, -1},
					[2] = {1, 1},
					[3] = {1, 0},
					[4] = {1, -1},
					[5] = {0, 1},
					[6] = {-1, -1},
					[7] = {-1, 0},
					[8] = {-1, 1}
			   }
	local ret =  d[dir]
	if ret == nil then
		ret = d[1]
	end
	return ret[1], ret[2]
end

function action_config.get_direction_by_xy(x, y)

	local ang = math.atan2(y, x);
	local qpi = math.pi/8;
	local result = 1
	if ((ang > -5*qpi) and (ang < -3*qpi)) then result = 1  
	elseif ((ang > -3*qpi) and (ang < -qpi)) then result = 4 
	elseif ((ang > -qpi) and (ang < qpi)) then result = 3  
	elseif ((ang > qpi) and (ang < 3*qpi)) then result = 2 
	elseif ((ang > 3*qpi) and (ang < 5*qpi)) then result = 5  
	elseif ((ang > 5*qpi) and (ang < 7*qpi)) then result = 8  
	elseif ((ang > 7*qpi) or (ang < -7*qpi)) then result = 7  
	elseif ((ang > -7*qpi) and (ang < -5*qpi)) then result = 6 end; 

	--print(">>>>>>>>", x, y, ">>>>>>", ang, result, qpi, ((ang > -5*qpi) and (ang < -3*qpi)));
	return result;
end
--	local ma = math.max(math.abs(x), math.abs(y));
--	if (ma>0) then
--		x = math.ceil(x / ma);
--		y = math.ceil(y / ma);
--	end
	
--	if (x > 1) then x = 1 end;
--	if (x < -1) then x = -1 end;
--	if (y > 1) then y = 1 end;
--	if (y < -1) then y = -1 end;
	
--	local diridx = action_config.DIRETIONS_MAP[x][y]
--	if (diridx == nil) then diridx = -1 end;
--	return diridx;
--end

function action_config:get_action_by_state(state, dir)
	--print("----get_action_by_state", state, dir);
	return state.."_"..action_config.DIRETIONS_NAME[dir];
end