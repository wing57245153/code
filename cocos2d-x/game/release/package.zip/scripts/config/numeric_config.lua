
numeric_config = {}

numeric_config.GL_SRC_ALPHA 			= 0x0302
numeric_config.GL_ONE 					= 1

function numeric_config:degrees_to_radians(angle)
	return angle * 0.01745329252
end
