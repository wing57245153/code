win_id_map = 
{
	AVATAR = 10000,  -- 角色信息窗口id
	BAG = 10001,   -- 背包窗口id
	LOGIN = 100002
}

-- 窗口配置信息
win_config = { }

-- {关闭按钮资源名, 是否是模态窗口, 底图资源文件名(nil - 不需要底图), 窗口名字, 切换场景是否关闭窗口, 关闭窗口时是否释放资源}
win_config[win_id_map.BAG] = {"closeButton", true, "background1", "背包", true, true}
win_config[win_id_map.AVATAR] = {"closeButton", true, "background1", "角色信息", true, true}
win_config[win_id_map.LOGIN] = {"closeButton", true, "background1", "登录界面", true, true}

function win_config:getWinConfig(winId)
	return self[winId]
end