require "scripts/utils/ByteArray"
super_class.Socket()

function Socket:__init()
    

   --self.socket = WebSocket:create("ws://localhost:1818/")
   self.socket = WebSocket:create("ws://192.168.200.175:6668/")
   self.connected = false
   --self.socket = WebSocket:create("ws://echo.websocket.org")

    local function wsSendBinaryOpen(strData)
        print("Send Binary WS was opened.")
        self.connected = true
    end

    local function wsSendBinaryMessage(paramTable)
        if type(paramTable) ~= "table" then
            print("not table")
            return  --采用二进制数据流
        end
        local byteArray = ByteArray()
        byteArray:setData( paramTable )
        --print("byte" , byteArray:readByte())
        print("receive data...")
        byteArray:print()

        local head = byteArray:readByte()
        local subHead = byteArray:readByte()
        local message = GameWorld.dataPool():getMessageById(head, subHead)
        --local message = GameWorld.dataPool():getMessageById(10, 0)
        message:read( byteArray )
    end

    local function wsSendBinaryClose(strData)
        print("_wsiSendBinary websocket instance closed.")
        self.socket = nil
        self.connected = false
    end

    local function wsSendBinaryError(strData)
        print("sendBinary Error was fired")
        self.connected = false
    end


    if nil ~= self.socket then
        self.socket:registerScriptHandler(wsSendBinaryOpen,kWebSocketScriptHandlerOpen)
        self.socket:registerScriptHandler(wsSendBinaryMessage,kWebSocketScriptHandlerMessage)
        self.socket:registerScriptHandler(wsSendBinaryClose,kWebSocketScriptHandlerClose)
        self.socket:registerScriptHandler(wsSendBinaryError,kWebSocketScriptHandlerError)
    end

    --return layer
end

function Socket:sendData(byteArray)
    if self.connected ~= true then
        return
    end
    self.socket:sendString(byteArray:toString())
end

function Socket:send( )
    print("send data")
    local bytes = ByteArray()
    do
       -- return 
    end

   -- local s = 
    local len = 4097
    local i = 1

    local send = ""
    --local function senddata()
        while i < len do
            --send = send .. s
            i = i + 1  
            bytes:writeByte(1)   
        end
        
        print("send end")
        
    --end
    self.socket:sendString(bytes:toString()) --最多一次只能发送125个字节到服务器 分包发送了
   -- local t = timer() 
    --t:start(0, senddata)
end