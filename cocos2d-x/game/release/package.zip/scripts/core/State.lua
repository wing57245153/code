
-- 游戏当前各种常规状态维护模块
-- 如 游戏运行时间

States = {}

States.game_time = 0;

function States:init()
	local function tick( dt )
		States:tick(dt);
	end
	local Scheduler = CCDirector:getInstance():getScheduler()
	Scheduler:scheduleScriptFunc(tick, 0.01, false)
end

function States:tick(dt)
	States.game_time = States.game_time + dt
end

 

States:init()