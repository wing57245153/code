--全局事件定义

--模块事件
MODULE_EVENT = "module_event"; --一级事件
--打开窗口
MODULE_SHOW_WINDOW = "module_show_window";
--关闭窗口
MODULE_HIDE_WINDOW = "module_hide_window";
--销毁窗口
MODULE_DESTROY_WINDOW = "module_destroy_window";

--------------------
---游戏相关事件
GAME_EVENT = "game_event"
---进入游戏 登录成功
GAME_ENTER_EVENT = "game_enter_event"



------数据事件--------
----数据更新事件
DATA_UPDATE_EVENT = "data_update_event" --一级事件 多个共用

DATA_AVATAR__EVENT = "avatar_data_event" --二级事件


-------协议数据事件--主协议为主key，子协议为子key
NET_EVENT_M01 = "M01" -------------登陆模块
NET_EVENT_M0100 = "00" ---------- 登陆
NET_EVENT_M0101 = "01" -----获取角色列表
NET_EVENT_M0102 = "02" ---创建角色
NET_EVENT_M0103 = "03" ---- 进入游戏