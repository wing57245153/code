
-- 游戏基本场景对象
super_class.Space()

-- 场景管理器，用于切换玩家场景
SpaceManager = {};

-------------------------------Space定义-------------------------------------------------

local SPACE_RES_MAIN_PATH = "spaces/"

local win_size = CCDirector:getInstance():getWinSize();

function Space:__init(parent, setting)
	self.m_parent = parent;
	self.m_setting = setting;
	self.m_chunks = {};
	self.m_cur_cam_center = CCPoint(win_size.width/2,win_size.height/2);

	self:_init_space_sprite();
end

function Space:_init_space_sprite()
	if self.m_space_sprite then return end;
	self.m_space_sprite = CCLayer:create();
	self.m_parent:addChild(self.m_space_sprite);
	local cam = self.m_space_sprite:getCamera();
	--cam:setCenterXYZ(-1,-1,1);
	--self.m_space_sprite:setPosition(CCPoint(200,200));
    local fullPath = CCFileUtils:sharedFileUtils():fullPathForFilename("data/spaces/1000/1000.tmx");
    --print(fullPath, "fullPath")
    require "scripts/debug/DebugOutput"
    debugOutput(fullPath)
    local path = CCFileUtils:sharedFileUtils():getWritablePath()
    debugOutput(path)
    --
	self.m_tiledMap = CCTMXTiledMap:create(fullPath); --临时写死 android上无法读取到！
	self.m_space_sprite:addChild(self.m_tiledMap);

	self:setMapSize();
	self:setNPCConfig();
end

function Space:setMapSize()
	local mapSize = self.m_tiledMap:getMapSize();
    local width = mapSize.width;
    local height = mapSize.height;
    local tileSize = self.m_tiledMap:getTileSize();
    local tileWidth = tileSize.width;
    local tileHeight = tileSize.height;

    self.m_MapWidth = width * tileWidth;
    self.m_MapHeight = height * tileHeight;

    GameWorld.camera():set_min_max_xy(win_size.width/2,win_size.height/2,
			self.m_MapWidth-win_size.width/2, self.m_MapHeight-win_size.height/2);
end

function Space:setNPCConfig()
	local npcGroup = self.m_tiledMap:getObjectGroup("npc");
	if npcGroup == nil then return end;

    local att = {};
	att.map_id = 2;
	att.model = "testxy";
	att.ai = "advance";

    self.m_npcGroup = {};
    local i = 1;
    local npc = nil;
    local x = 0;
    local y = 0;
    local name = nil;
    local npcTable = nil;
	local objectList = npcGroup:getObjects();
    local len = objectList:count();
    local entid = nil;
    local ent = nil;
    for i=1,len do
    	npc = tolua.cast(objectList:objectAtIndex(i - 1), "CCDictionary");
       	x = npc:valueForKey("x"):doubleValue();
       	y = npc:valueForKey("y"):doubleValue();
       	name = npc:valueForKey("name"):getCString();
       	
       	npcTable = {};
       	npcTable.x = x;
       	npcTable.y = y;
       	npcTable.name = name;

       	self.m_npcGroup[name] = npcTable;

       	--entid = GameWorld.create_entity("Monster", att);
       	--ent = GameWorld.entities()[entid];
       	--ent:set_position(x, y);
    end

    --print("npc" .. self.m_npcGroup["101"].x)
end

function Space:update()
	if self.m_space_sprite == nil then return end;


	--win_size.width / 2, win_size.height / 2
	--local cam = self.m_space_sprite:getCamera();
	--if self.m_cur_cam_center.x > 0 then return end;
	--print("m_cur_cam_center:", self.m_cur_cam_center.x, self.m_cur_cam_center.y);
	--self.m_cur_cam_center.x = self.m_cur_cam_center.x + 1;
	--self.m_cur_cam_center.y = self.m_cur_cam_center.y + 1;

	-- if (self.testx == nil) then 
	-- 	self.testx = win_size.width/2;
	-- 	self.testy = win_size.height/2; 
	-- end

	local cam = GameWorld.camera();
	self.m_cur_cam_center.x = cam:get_view_position().x;
	self.m_cur_cam_center.y = cam:get_view_position().y;
	--self.m_cur_cam_center.x = self.m_cur_cam_center.x + 1;
	--self.m_cur_cam_center.y = self.m_cur_cam_center.y + 1;
	--local sx = -self.m_cur_cam_center.x + win_size.width/2;
	--local sy = -self.m_cur_cam_center.y + win_size.height/2;
	--self.m_space_sprite:setPosition(CCPoint(sx, sy));

	do        
        

        --print("width:" .. self.m_MapWidth .. " height:" .. self.m_MapHeight);
        --print(self.m_cur_cam_center.x .." " .. self.m_cur_cam_center.y);
        --local x = self.m_space_sprite:getPosition();
        --local y = self.m_titleMap:getPosition().y;
       -- print("map position:x:" .. x .. "y:");
        --print("m_space_sprite position:x:" .. self.m_space_sprite:getPosition().x .. "y:" .. self.m_space_sprite:getPosition().y);

        return 
    end

	local leftbottomx = self.m_cur_cam_center.x - win_size.width/2;		
	local leftbottomy = self.m_cur_cam_center.y - win_size.height/2;	

	local addi = 0;

	local startx = math.modf((leftbottomx - addi) / self.m_setting.chunkw);
	local endx = math.modf((leftbottomx + win_size.width + addi) / self.m_setting.chunkw);
	local starty = math.modf(self.m_setting.spacech - (leftbottomy - addi) / self.m_setting.chunkw);
	local endy = math.modf(self.m_setting.spacech - (leftbottomy + win_size.height + addi) / self.m_setting.chunkh);

	--print("-----------startx", leftbottomx, leftbottomy, startx, endx, starty, endy, win_size.width, win_size.height)
	--print("-----------startx2", self.m_cur_cam_center.x, self.m_cur_cam_center.y);
	--重新计算那些chunk在屏幕之内
	local newchunkpos = {};
	for nx=startx, endx+1 do 
		for ny=starty, endy-1, -1 do 
			if (nx >= 0 and ny >= 0 and nx < self.m_setting.spacecw 
				and ny < self.m_setting.spacech) then
				newchunkpos[nx * 1000 + ny] = true;
			end
		end 
	end 

	--删除不在屏幕中的chunk
	for oldxy in pairs(self.m_chunks) do
		if newchunkpos[oldxy]==nil then 
			--print("-----------oldxy", oldxy, self.m_chunks[oldxy]);
			local cobj = self.m_chunks[oldxy];
			self.m_space_sprite:removeChild(cobj, true);
			self.m_chunks[oldxy] = nil;
		end
	end

	for newxy in pairs(newchunkpos) do
		if self.m_chunks[newxy] == nil then
			local nx, ny = math.modf(newxy / 1000);
			local ny = newxy % 1000;
			local path = SPACE_RES_MAIN_PATH .. self.m_setting.resname .. "/" 
			path = path .. self.m_setting.resname .. "_" .. nx .. "_" .. ny .. "." .. self.m_setting.filetype;
			--print("-----------newxy", newxy, nx, ny)
			self.m_chunks[newxy] = CCSprite:create(path);
			self.m_space_sprite:addChild(self.m_chunks[newxy]);
			local pos = CCPoint((nx+0.5) * self.m_setting.chunkw, 
					(self.m_setting.spacech - ny - 0.5) * self.m_setting.chunkh);
			self.m_chunks[newxy]:setPosition(pos);
			break;
		end
	end
end

function Space:destroy()
	
	if self.m_tiledMap ~= nil then
		self.m_tiledMap:removeAllChildren();
	end

	if self.m_space_sprite == nil then return end;
	    self.m_space_sprite:removeChild(self.m_tiledMap);
	    self.m_parent:removeChild(self.m_space_sprite);
	    self.m_space_sprite = nil;
	    self.m_tiledMap = nil;
    end


-------------------------------SpaceManager定义-------------------------------------------------

--临时数据，测试用，以后是配置
local tempSpacesData = {};
tempSpacesData[1] = "space1";
tempSpacesData[2] = "zhucheng1";	

local tempSpace1Data = {
						resname="59700", --space对应资源路径
						width=3500,             --space实际宽度
						height=3500,            --space实际高度
						chunkw=256,             --单个chunk的宽 
						chunkh=256,             --单个chunk的高
						spacecw=13,              --space宽chunk个数
						spacech=13,              --space高chunk个数
						filetype="jpg",         --文件格式
						entities={}             --包含的场景实体数据
						};

local tempSpace2Data = {
						resname="zhucheng",     --space对应资源路径
						width=6241,             --space实际宽度
						height=6000,            --space实际高度
						chunkw=256,             --单个chunk的宽 
						chunkh=256,             --单个chunk的高
						spacecw=25,              --space宽chunk个数
						spacech=24,              --space高chunk个数
						filetype="jpg",         --文件格式
						entities={}             --包含的场景实体数据
						};
--end

local scheduler = CCDirector:getInstance():getScheduler()

function SpaceManager:init( root )    --单例初始化方法
	
	self.current_space = nil;         --current_space 相当于这个类的静态属性
	--local spacelayer = CCLayer:create()
	--root:addChild(spacelayer)
	--SpaceManager.root = scenelayer
	self.root = root;
	--self.root:addChild(CCSprite:create("space/dongxuedengdai/dongxuedengdai_0_4.jpg"))

	--self:set_space(2);
	local update = function( ... )
		if SpaceManager.current_space~=nil then 
			GameWorld.camera():update();  --暂时写在这里，应该有个总update核心模块
			LayerManager:update();
			SpaceManager.current_space:update();
			EntityManager:update();
		end
	end
	scheduler:scheduleScriptFunc(update, 0, false);
end



function SpaceManager:_update()
	
	if self.current_space~=nil then 
		self.current_space:update();

	end
end

function SpaceManager:set_space(spaceid)
	if self.current_space ~= nil then
		self.current_space:destroy();
		self.current_space = nil;	
	end

	local spacename = tempSpacesData[spaceid];
	--local setting = require("data/space/" + spacename);
	--上面一行才是正式的
	local setting = tempSpace2Data;
	self.current_space = Space(self.root, setting);
	print("set_space", self.current_space, isclass(Space, self.current_space))
	print("set_space2", self.current_space.__classname);

	local win_size = CCDirector:getInstance():getWinSize();
	--GameWorld.camera():set_min_max_xy(win_size.width/2,win_size.height/2,
	--		setting.width-win_size.width/2, setting.height-win_size.height/2);
    
	
	--self.current_space:update();
end

function SpaceManager:on_player_change_map(oldvalue)
	local c = GameWorld.player().map_id;
	self:set_space(GameWorld.player().map_id);
end