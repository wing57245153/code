--数据池 用来获取各种动态数据
require "scripts/utils/Utils"
super_class.DataPool()

function DataPool:InitMessage( )
	self.message = {}
	self["M01"] = self:getM01()
	self["M10"] = self:getM10()
end

function DataPool:__init()
	self:InitMessage()
end


function DataPool:getAvatarData()
    require "scripts/data/dynamic/avatar/AvatarData"
    if self.avatarData == nil then
        self.avatarData = AvatarData()
    end
    return self.avatarData
end

function DataPool:getM10( )
	require "scripts/net/M10"
	if self.M10 == nil then
        self.M10 = M10()
    end
    return self.M10
end

function DataPool:getM01( )
	require "scripts/net/M01"
	if self.M01 == nil then
        self.M01 = M01()
    end
    return self.M01
end

function DataPool:getMessageById( mainHead, subHead )
	if mainHead < 10 then
		mainHead = "0" .. mainHead
	end

	local mainMessage = self["M" .. mainHead]
	local key = nil
	if subHead < 10 then
		subHead = "0" .. subHead
	end
	key = "M" .. mainHead .. subHead
    local message = mainMessage[key]

    return message
end

----- 初始化玩家自身的属性数据列表 key--> val
function DataPool:getPlayerAttrList()
    return self.playerAttrList
end

function DataPool:setPlayerAttrList( data )
	--Utils:print_table_key_value(data)
	if self.playerAttrList == nil then
		self.playerAttrList = {}
	end

	for k,v in pairs(data) do
		self.playerAttrList[v["key"]] = v["val"]
	end
end