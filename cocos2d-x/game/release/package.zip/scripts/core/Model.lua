

--模型逻辑主体，非显示对象，用于衔接引擎与脚本逻辑的管理对象
super_class.Model()  

local MODEL_PATH = "models/"


--local ModelData = {          --暂时用的配置数据
--				[1]="testxx"
--}



-- local FrameData = {}   	     --暂时用的动画数据

-- local function get_animation(modelname, aniname)
-- 	if (!FameData[modelname} then
-- 		FameData[modelname]={};
-- 	end
-- 	if (!FameData[modelname][aniname}{
-- 		local textureDog = CCTextureCache:getInstance():addImage("dog.png")
--         local rect = CCRect(0, 0, frameWidth, frameHeight)
--         local frame0 = CCSpriteFrame:createWithTexture(textureDog, rect)
--         rect = CCRect(frameWidth, 0, frameWidth, frameHeight)
--         local frame1 = CCSpriteFrame:createWithTexture(textureDog, rect)
-- 	}
-- return

function Model:__init(modelname)
	self.m_model_name = modelname;
	self.m_real_sprite = CCSprite:create();--("model/testxx_1.png"); --真正的显示对象
	--self.m_real_sprite:setAnchorPoint(CCPoint(0,0));
	self.m_real_sprite:retain();
	self.m_real_sprite.isPaused = false
	self.m_animations = {};
	self.m_is_destroy = false;

	self.m_shadow_slot = nil;  --脚底阴影
	self:get_shadow_slot()
	self.m_main_model_slot = nil; --主体模型槽位
	self:get_main_model_slot();
	self.m_up_effect_slot = nil; --表层特效槽位
	self:get_up_effect_slot();

end

function Model:get_real_sprite()
	return self.m_real_sprite
end

function Model:remove_sprite()
	if (self.m_is_destroy) then return end;
	self.m_parent:removeChild(self.m_real_sprite, true);	
end

function Model:set_parent(parent)
	if (self.m_is_destroy) then return end;
	if (self.m_parent ~= nil) then
		self.m_parent:removeChild(self.m_real_sprite, true);
	end
	self.m_parent = parent;
	if (self.m_parent ~= nil) then
		self.m_parent:addChild(self.m_real_sprite);
	end
	--print("%%%%%%%%%%%%%%%set_parent", self.m_parent)
end

function Model:destroy()
	if self.m_shadow_slot ~= nil then
		self.m_real_sprite:removeChild(self.m_shadow_slot, true)
		self.m_shadow_slot = nil
	end

	if self.m_up_effect_slot ~= nil then
		self.m_real_sprite:removeChild(self.m_up_effect_slot, true)
		self.m_up_effect_slot = nil
	end	
	self:set_parent(nil);
	self.m_is_destroy = true;
	self.m_real_sprite:release();

end

function Model:set_position(x, y)
	if (self.m_is_destroy) then return end;
	self.m_real_sprite:setPosition(CCPoint(x, y));
end


function Model:get_shadow_slot()
	if (self.m_shadow_slot == nil)then
		self.m_shadow_slot = CCSprite:create("images/shadow.png")
		self.m_real_sprite:addChild(self.m_shadow_slot)
	end
	return self.m_shadow_slot;
end

function Model:get_main_model_slot()
	if (self.m_main_model_slot==nil)then
		self.m_main_model_slot = CCSprite:create();
		self.m_real_sprite:addChild(self.m_main_model_slot)
	end
	return self.m_main_model_slot;
end

function Model:get_up_effect_slot()
	if (self.m_up_effect_slot == nil)then
		--self.m_up_effect_slot = CCSprite:create("images/hongdian.jpg");
		self.m_up_effect_slot = GameWorld.effect("effect5")
    	self.m_up_effect_slot:set_parent(self.m_real_sprite);
	    self.m_up_effect_slot:set_position(0, 60)
	    self.m_up_effect_slot:set_scale(0.7)		
	    --self.m_up_effect_slot:play("playeffect", true)
		--self.m_real_sprite:addChild(self.m_up_effect_slot)
	end
	return self.m_up_effect_slot;
end

function Model:initModelRes(aniname)
 	local animframes = CCArray:create()
 	local modelpathname = MODEL_PATH .. self.m_model_name;
 	local anidata = require(modelpathname);
 	model_action_map = anidata.action_map
 	if (model_action_map==nil or model_action_map[aniname]==nil) then return end;
 	local curidx = 0;
 	local pngname;
 	local texture;
 	--数据结构 [文件名, 横向地址, 纵向地址, 子图片宽度,  子图片高度,  x方向偏移, y方向偏移]
 	for idx,fidx in ipairs(model_action_map[aniname]) do

 		if (anidata[fidx]==nil) then break end;
	    local sx = anidata[fidx][2];
	    local sy = anidata[fidx][3];
	    local sw = anidata[fidx][4];
	    local sh = anidata[fidx][5];
	    local offx = anidata[fidx][6] ;
	    local offy = anidata[fidx][7] ;
	    local rect = CCRect(sx, sy, sw, sh);

		if (anidata[fidx][1]~=curidx) then
			curidx = anidata[fidx][1];
			pngname = modelpathname.."_"..curidx..'.png';
			texture = CCTextureCache:getInstance():addImage(pngname);
		end			    
		local frame = CCSpriteFrame:createWithTexture(texture, rect, false, CCPoint(offx,offy), rect.size);
			    
		animframes:addObject(frame);
			    --print("frame-------", aniname, pngname, sx, sy, sw, sh, offx, offy);
 	end

 	local speed = self:get_ani_speed(aniname)
 	local animation = CCAnimation:createWithSpriteFrames(animframes, speed);
 	local animate = CCAnimate:create(animation);
 	self.m_animations[aniname] = animate;
 	animate:retain();	
end

function Model:play(aniname, play_once, cb_fun)
	if (self.m_is_destroy) then return end;
	if (self.m_animations[aniname]==nil) then
		self:initModelRes(aniname)
 		--self.m_animations[aniname];
 		--[[do 
 			--if (MODEL_ANIMATION_MAP[aniname]==nil) then return end;
 			
 			local animframes = CCArray:create()
 			local modelpathname = MODEL_PATH .. self.m_model_name;
 			local anidata = require(modelpathname);
 			model_action_map = anidata.action_map
 			if (model_action_map==nil or model_action_map[aniname]==nil) then return end;
 			local curidx = 0;
 			local pngname;
 			local texture;
 			--数据结构 [文件名, 横向地址, 纵向地址, 子图片宽度,  子图片高度,  x方向偏移, y方向偏移]
 			for idx,fidx in ipairs(model_action_map[aniname]) do
 				if (anidata[fidx]==nil) then break end;
			    local sx = anidata[fidx][2];
			    local sy = anidata[fidx][3];
			    local sw = anidata[fidx][4];
			    local sh = anidata[fidx][5];
			    local offx = anidata[fidx][6] ;
			    local offy = anidata[fidx][7] ;
			    local rect = CCRect(sx, sy, sw, sh);

 				if (anidata[fidx][1]~=curidx) then 
 					curidx = anidata[fidx][1];
 					pngname = modelpathname.."_"..curidx..'.png';
 					texture = CCTextureCache:getInstance():addImage(pngname);
 				end			    
			    local frame = CCSpriteFrame:createWithTexture(texture, rect, false, CCPoint(offx,offy), rect.size);
			    
			    animframes:addObject(frame);
			    --print("frame-------", aniname, pngname, sx, sy, sw, sh, offx, offy);
 			end

 			local speed = self:get_ani_speed(aniname)
 			local animation = CCAnimation:createWithSpriteFrames(animframes, speed);
 			local animate = CCAnimate:create(animation);
 			self.m_animations[aniname] = animate;
 			animate:retain()
 		end]]
 	end
 	--self.m_real_sprite:stopAllActions();
 	if(self.m_cur_action)then
 		self:get_main_model_slot():stopAction(self.m_cur_action);
 	end
 	--print("self.m_animations[aniname]", self.m_animations[aniname]);
 	--self.m_cur_action = CCRepeatForever:create(self.m_animations[aniname]);
 	if play_once == nil or play_once == false then
 		self.m_cur_action = CCRepeatForever:create(self.m_animations[aniname]);
 		self:get_main_model_slot():runAction(self.m_cur_action);
 	else
 		self.m_cur_action = self.m_animations[aniname]		
		local arr1 = CCArray:create()
		arr1:addObject(self.m_cur_action)
		arr1:addObject(CCCallFunc:create(cb_fun))
		local seq1 = CCSequence:create(arr1)	
    	self:get_main_model_slot():runAction(seq1);
    	--self:get_main_model_slot():runAction(self.m_cur_action);
 	end
 	--self:get_main_model_slot():runAction(self.m_cur_action);
 	--self:set_mrror(true)
end

function Model:get_ani_speed(name)
	local value = 0.1
	if string.sub(name, 1, 5) == "stand" then
		value = 0.2
	end	
	return value
end


function Model:callbacktest()

end

function Model:set_mrror(state)
	--local cam = self.m_real_sprite:getCamera();
	if (state)then
		self.m_real_sprite:setScaleX(-1);
	else
		self.m_real_sprite:setScaleX(1);
	end
end