--数据管理器 管理数据更新等
--require "scripts/core/GameWorld" 
require "scripts/core/AppEvent" 

super_class.DataManager()

function DataManager:__init( )
    self.messenger = GameWorld.gameBus() --全局传递者

    self.addEventLister()
end


function DataManager:addEventLister()
	--self.messenger:add_listener(DATA_UPDATE_EVENT, AVATAR_DATA_EVENT, self.updateData)
end

---更新数据 该数据为协议数据
function DataManager:updateData(mainevent, subevent, data)
    self.messenger:dispatchEvent(mainevent, subevent, data)
end

