
--游戏中的层次管理
LayerManager = {}

-------------------------------LayerManager定义-------------------------------------------------
local function fix_screen( root )
	-- 适应所有屏幕 我们所有的ui以960,640为标准
	require "scripts/debug/DebugOutput"
	LayerManager:get_layer_world():setAnchorPoint(CCPointMake(0,0));
	LayerManager:get_layer_ui():setAnchorPoint(CCPointMake(0,0));
	LayerManager:get_layer_user():setAnchorPoint(CCPointMake(0,0));
	LayerManager:get_layer_joystick():setAnchorPoint(CCPointMake(0,0));
	local winSize = CCDirector:sharedDirector():getWinSize();
	local frameSize = CCEGLView:getInstance():getFrameSize();

	GameScaleFactors.ui_x = winSize.width  / GameScreenFactors.standard_width
	GameScaleFactors.ui_y = winSize.height / GameScreenFactors.standard_height
	LayerManager:get_layer_ui():setScaleX(GameScaleFactors.ui_x);
	LayerManager:get_layer_ui():setScaleY(GameScaleFactors.ui_y);
	LayerManager:get_layer_user():setScaleX(GameScaleFactors.ui_x);
	LayerManager:get_layer_user():setScaleY(GameScaleFactors.ui_y);
	LayerManager:get_layer_joystick():setScale(GameScaleFactors.ui_x);
	--LayerManager:get_layer_world():setScale(GameScaleFactors.ui_x);
	local scaleXY = GameScaleFactors.ui_x .."___"..GameScaleFactors.ui_y
	debugOutput(scaleXY)
	debugOutput("winSize = " .. winSize.width.."x"..winSize.height)
end

-- 游戏自适应的屏幕像素值
GameScreenFactors = {
	-- 标准设计屏幕大小
	standard_width  = 960,
	standard_height = 640,		
}

-- 游戏自适应用到的缩放比
GameScaleFactors = {
	-- 实际场景与UI缩放比
	viewPort_ui_x = 0, 
	viewPort_ui_y = 0,
	-- UI缩放比
	ui_x = 1,
	ui_y = 1,
	-- 场景缩放比
	viewPort_x = 0,
	viewPort_y = 0,
}


local win_size = CCDirector:getInstance():getWinSize();


function LayerManager:init(root)
 	self.mainScene = root

	self.layer_world = CCLayer:create();
	self.layer_terrain = CCLayer:create();
	self.layer_model = CCLayer:create();
	self.layer_effect = CCLayer:create();
	self.layer_world:addChild(self.layer_terrain);
	self.layer_world:addChild(self.layer_model);
	self.layer_world:addChild(self.layer_effect);
	self.layer_user = CCLayer:create();
	self.layer_joystick = CCLayer:create();
	self.layer_ui = CCLayer:create();

	self.layer_debug = CCLayer:create();

	root:addChild(self.layer_world);
	root:addChild(self.layer_user);
	root:addChild(self.layer_joystick)
	root:addChild(self.layer_ui);
	root:addChild(self.layer_debug);
	fix_screen(root)
    --[[local function onTouch(eventType, x, y)
        if eventType == "began" then  
        	local target = win_xy_2_position(x, y); 
           	GameWorld.player():move(target.x,target.y);
        elseif eventType == "moved" then
            
        else
           
        end
    end

    --self.layer_world:registerScriptTouchHandler(onTouch)
    --self.layer_world:setTouchEnabled(true)]]
end
--[[
function LayerManager:scale()
	local realSize = CCEGLView:getInstance():getFrameSize()
	local designSize = CCDirector:getInstance():getWinSize()
	local scale = realSize.height / designSize.height
	self.layer_user:setScale(scale)
	self.layer_ui:setScale(scale)
	print("scale layer_user", scale)
end

local xy_2_position = {x=0,y=0}
function win_xy_2_position(x, y)	
	local campos = GameWorld.camera():get_view_position();
	local temp_x = (x - win_size.width / 2) / GameWorld.camera():get_scale();
	local temp_y = (y - win_size.height / 2) / GameWorld.camera():get_scale();
	xy_2_position.x = math.ceil(campos.x + temp_x);
	xy_2_position.y = math.ceil(campos.y + temp_y);
	return xy_2_position;
end]]

function LayerManager:SceneEffect()
	CCDirector:getInstance():replaceScene(CCTransitionSlideInR:create(1.2, self.mainScene))
end

function LayerManager:get_layer_joystick()
	return self.layer_joystick;
end

function LayerManager:get_layer_effect()
	return self.layer_effect;
end
function LayerManager:get_layer_terrain()
	return self.layer_terrain;
end

function LayerManager:get_layer_model()
	return self.layer_model;
end

function LayerManager:get_layer_ui()
	return self.layer_ui;
end

function LayerManager:get_layer_world()
	return self.layer_world;
end

function LayerManager:get_layer_user()
	return self.layer_user;
end

function LayerManager:update()
	local cam = GameWorld.camera();
	local x = -(cam:get_view_position().x - win_size.width/2);	
	local y = -(cam:get_view_position().y - win_size.height/2);

	self.layer_world:setPosition(CCPoint(math.ceil(x), math.ceil(y)));

end
