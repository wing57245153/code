---基础动态数据类
require "scripts/core/GameWorld" 

super_class.BasicMessage()

function BasicMessage:__init()
	self.mainevent = ""
	self.subevent = "" --数据标识，数据更新时，方便模块获知
end

function BasicMessage:read( byteArray )
    print("BasicMessage read")
end

function BasicMessage:write( byteArray )
    print("BasicMessage write")
end

function BasicMessage:updateData(data)
    GameWorld.dataManager():updateData(self.mainevent, self.subevent, self.data)
end

function BasicMessage:sendData( byteArray )
    local head = tonumber(string.sub(self.mainevent, 2 , -1))
    local subhead = tonumber(self.subevent)

    local sendBytes = ByteArray()
    sendBytes:writeByte(head)
    sendBytes:writeByte(subhead)
    sendBytes:writeBytes(byteArray)

    print("send data...")
    sendBytes:print()
    -------列表类型暂未支持--
	GameWorld.gameSocket():sendData( sendBytes )
end