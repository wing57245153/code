require "scripts/core/GameWorld" 

--只复制模块内部与外部的通讯
--可当成一个控制器
super_class.BasicModule()


function BasicModule:__init()
	self.messenger = GameWorld.gameBus() --全局传递者
	self.dataPool = GameWorld.dataPool() --数据池 获取动态数据
	self.name = "BasicModule"
end

--注册事件
function BasicModule:registerEvent()

end

function BasicModule:InitModule()
  
end


function BasicModule:create()
	print("create module...")
	if self.m_parent == nil then
	    self.m_parent = CCNode:create()
	end
end

function BasicModule:destroy()
	-- body
	self.messenger = nil
	self.name = nil
	self.dataPool = nil
	print("basicModule destroy")
end

function BasicModule:hideWindow()
    print("hideWindow...")
    self.messenger:dispatchEvent(MODULE_EVENT, MODULE_HIDE_WINDOW, self.name)
end

function BasicModule:destroyWindow()
    print("destroyWindow...")
    self.messenger:dispatchEvent(MODULE_EVENT, MODULE_DESTROY_WINDOW, self.name)
end