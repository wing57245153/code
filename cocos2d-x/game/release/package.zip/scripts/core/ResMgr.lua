

UI_PATH = "ui/"


ResMgr = {}


function ResMgr:init()    --单例初始化方法
	


end


function ResMgr.GetUIFrame(mainname, subname)
	local settingpath = UI_PATH .. mainname;
	local settingdata = require(settingpath);
	if settingdata == nil then return nil end;
	local framesetting = settingdata[subname];
	if framesetting == nil then return nil end;
	local curidx = framesetting[1];
	local pngname = UI_PATH..mainname.."_"..curidx..'.png';

 	local texture = CCTextureCache:getInstance():addImage(pngname);
 	print("::::::::::::::::::::::::::::::::", pngname, texture)	

 	local sx = framesetting[2];
    local sy = framesetting[3];
    local sw = framesetting[4];
    local sh = framesetting[5];
    local offx = framesetting[6] ;
    local offy = framesetting[7] ;
    local rect = CCRect(sx, sy, sw, sh);
	local frame = CCSpriteFrame:createWithTexture(texture, rect, false, CCPoint(offx,offy), rect.size);
	return frame;
end


ResMgr:init()