
--游戏摄像机基类
super_class.Camera()

--camera管理器，用于创建特定camera对象
CameraManager = {}


-------------------------------Camera定义-------------------------------------------------

function Camera:__init()
	--self.m_root = root;
	self.m_minx = 0;                    
	self.m_miny = 0;
	self.m_maxx = 0;
	self.m_maxy = 0;
	self.m_scale = 1;                     --缩放比例
	self.m_position = {x=0,y=0};        --当前基本位置
	self.m_offset = {x=0,y=0};        	--动态偏移
	self.m_offset_position = {x=0,y=0}; --偏移后实际地址，用于做数据缓存，提高运行效率
	self.m_target_offset = {x=0,y=0}; 	--中间矩形偏移
	self.m_target = nil;                --当前跟随的实体目标

	--屏幕震动相关属性
	self.m_shake_frequency = 0;         --频率   每frequency帧改变一次
	self.m_shake_attenuation = 0;       --衰减系数, 震动衰减百分比，就是每次衰减比例
	self.m_shake_duration = 0;          --持续时间，单位帧
	self.m_cur_frame = 0;               --当前帧率

	--镜头拖动相关       
	self.m_move_speed = 0               --虚拟目标移动速度
	self.m_move_target = {x=0,y=0};     --虚拟目标，用于剧情相关拖动镜头

	self.scale_counter = 0
	self.scale_current = 1
end

function Camera:set_min_max_xy(minx, miny, maxx, maxy)
	self.m_minx = minx;
	self.m_miny = miny;
	self.m_maxx = maxx;
	self.m_maxy = maxy;
end

function Camera:get_position()
	return m_position;
end

function Camera:set_position(x, y)
	if (self.m_position.x == x and self.m_position.y == y)then return end;
	self.m_position.x = x; 
	self.m_position.y = y;
end

function Camera:get_view_position()
	self.m_offset_position.x = (self.m_position.x + self.m_offset.x);
	self.m_offset_position.y = (self.m_position.y + self.m_offset.y);
	return self.m_offset_position;
end

function Camera:get_scale()
	return self.m_scale;
end

function Camera:get_target()	
	return self.m_target;  
end
		
function Camera:set_target(t)	
	if (self.m_target == t)then return end;
	self:stop_move();
	self.m_target = t;  --这里以后改成弱引用或者其他引用方式
end

function Camera:get_offset()
	return self.m_offset;
end

function Camera:set_offset(x, y)
	self.m_offset.x = x;
	self.m_offset.y = y;
end



--  * 屏幕震动
--  * @param	rangex        rangex为x方向振幅, 单位像素
--  * @param	rangey		  rangey为y方向振幅，单位像素
--  * @param	frequency     频率   每frequency帧改变一次
--  * @param	attenuation   衰减系数, 震动衰减百分比，就是每次衰减比例
--  * @param    duration      持续时间，单位帧
function Camera:shake(rangex, rangey, frequency, attenuation, duration)
	self.m_offset.x = rangex;
	self.m_offset.y = rangey;
	self.m_shake_frequency = frequency;
	self.m_shake_attenuation = attenuation;
	self.m_shake_duration = duration;
	self.m_cur_frame = 0;
	self:scale(9) --for test
end


function Camera:shaking()
	if (self.m_shake_frequency == 0 or self.m_shake_attenuation == 0)then return end;
	if (math.abs(self.m_offset.x) <= 1 and math.abs(self.m_offset.y) <= 1) then return end;
	if (self.m_shake_duration <= 0) then return end;
	self.m_shake_duration = self.m_shake_duration - 1;
	self.m_cur_frame = self.m_cur_frame + 1;
	if (((self.m_cur_frame - 1) % self.m_shake_frequency) ~= 0) then return end;
	self.m_offset.x = -self.m_offset.x * ( 1 - self.m_shake_attenuation );
	self.m_offset.y = -self.m_offset.y * ( 1 - self.m_shake_attenuation );
end

function Camera:stop_move()
	self.m_move_speed = 0;
	self.m_move_target.x = 0;
	self.m_move_target.y = 0;
end

function Camera:scale(duration)
	self.scale_counter = duration
end

function Camera:updatescale()
	if self.scale_counter <= 1 then return end
	local d = {1, 1.25, 1.5, 1.75, 2, 1.75, 1.5, 1.25}
	self.scale_counter = self.scale_counter - 1
	self.scale_current = d[self.scale_counter]
	LayerManager:get_layer_world():setScale(d[self.scale_counter])	
	--self:set_position(newx * self.scale_current, newy * self.scale_current);
end

function Camera:update()
	self:updatescale()
	self:shaking();
	local dis
	if (self.m_target ~= null) then
		local tp = self.m_target.m_position;

		local dx = tp.x - self.m_position.x;
		local dy = tp.y + self.m_target_offset.y - self.m_position.y;

		local newx = self.m_position.x;
		local newy = self.m_position.y;

		if (math.abs(dx)>30)then
			newx = tp.x - 30 * (dx/math.abs(dx));
		end

		if (math.abs(dy)>10)then
			newy = tp.y + self.m_target_offset.y - 10 * (dy/math.abs(dy));
		end

		newx = math.max(math.min(newx, self.m_maxx), self.m_minx);
		newy = math.max(math.min(newy, self.m_maxy), self.m_miny);

		dx = newx - self.m_position.x ;
		dy = newy - self.m_position.y ;
		dis = math.sqrt(dx * dx + dy * dy);

		local bufferdis = 20;
		if (dis > bufferdis) then
			if (dis < 200)then
				local movespeed = 3 * dis/bufferdis;
				newx = self.m_position.x + movespeed * dx / dis;
				newy = self.m_position.y + movespeed * dy / dis;
				newx = math.max(math.min(newx, self.m_maxx), self.m_minx);
				newy = math.max(math.min(newy, self.m_maxy), self.m_miny);
			end		
			--self:set_position(newx * self.scale_current, newy * self.scale_current);	
			--self:set_position(newx * GameScaleFactors.ui_x, newy * GameScaleFactors.ui_x);
		end
		self:set_position(newx * self.scale_current, newy * self.scale_current);	

	elseif(self.m_move_target.x > 0 and self.m_move_target.y > 0)then
		dx = self.m_move_target.x - self.m_position.x;
		dy = self.m_move_target.y - self.m_position.y;

		dis = math.sqrt(dx * dx + dy * dy);
		if(dis>self.m_move_speed) then
			newx = self.m_position.x + self.m_move_speed * dx / dis;
			newy = self.m_position.y + self.m_move_speed * dy / dis;
		else
			self:stop_move();
		end
		if (newx>0 and newy>0)then
			self:set_position(newx, newy);
		end
	end
end

-------------------------------CameraManager定义-------------------------------------------------

function CameraManager:init()
	self.cur_camera = nil
end

function CameraManager:create_camera()
	local newcamera = Camera();
	return newcamera;
end

function CameraManager:set_current_camera(camera)
	self.cur_camera = camera;
end

function CameraManager:get_current_camera()
	return self.cur_camera;
end

CameraManager:init()