
--实体定义抽象类，一般不直接创建，只用于继承
super_class.Entity()

--实体管理器，用于管理实体创建和删除等
EntityManager = {}

-------------------------------Entity定义-------------------------------------------------

function Entity:__init()
	self.m_id = 0;
	self.m_entity_type = ""
	self.m_position = {x=0,y=0};
	self.m_model = nil;
	self.m_in_world = false;
end

function Entity:on_enter_world()
	self.m_in_world = true;
end

function Entity:on_leave_world()
	self.m_in_world = false;
end

function Entity:set_position(x,y)
	self.m_position.x = x;
	self.m_position.y = y;
	if (self.m_model) then
		self.m_model:set_position(x,y);
	end
end

function Entity:get_real_sprite()
	if (self.m_model) then
		return self.m_model:get_real_sprite()
	end
	return nil;
end

function Entity:get_position()
	return self.m_position;
end

function Entity:destroy()
	if (self.m_model~=nil) then
		self.m_model:destroy();
	end	
end


function Entity:set_model(model)
	if (self.m_model~=nil) then
		self.m_model:destroy();
	end
	self.m_model = model;
	if (self.m_model) then
		self.m_model:set_parent(LayerManager:get_layer_model());
	end
end

--function Entity:set_state(state)
--end


function Entity:play_animation(aniname, play_once, cb_fun)
	--function reset_stand()
	--	self:set_state(action_config.STATE_STAND)
	--end

	if (self.m_model) then
		self.m_model:play(aniname, play_once, cb_fun);
	end
	--print("play_animation", self.m_entity_type, aniname)
end


-------------------------------EntityManager定义-------------------------------------------------

function EntityManager:init()    --单例初始化方法
	
	self.entities = {}           --静态属性：实体列表
	self.entity_id_begin = 0       --已使用实体ID最大值，用于递增生成实体ID

	self.player = nil            --当前主控角色
	self.last_update_tick = 0
end

function EntityManager:create_entity_by_id(entityid, entitytype, args)
	if (self.entities[entityid]) then return end
	require("scripts/entity/"..entitytype)
	local entity = _G[entitytype]();
	if (self.player == nil) then self.player = entity end;
	entity.m_id = entityid;
	entity.m_entity_type = entitytype;
	for attname, attvalue in pairs(args) do
		entity[attname] = attvalue;
	end
	self.entities[entityid] = entity;
	entity:on_enter_world();
	return entityid
end

function EntityManager:create_entity(entitytype, args)
	self.entity_id_begin = self.entity_id_begin + 1;
	return self:create_entity_by_id(self.entity_id_begin, entitytype, args);
end

function EntityManager:destroy_entity(entityid)
	if (self.entities[entityid]==nil) then return end
	newentity:on_leave_world();
	self.entities[entityid]=nil
end

function EntityManager:get_entity(entityid)
	return self.entities[entityid]
end

function EntityManager:destroy_all_entity()

end

function EntityManager:set_player(entity)
	self.player = entity;
end

function EntityManager:get_player(entity)
	return self.player;
end

function EntityManager:update()
	local now =  GameWorld.game_time()
	if now - self.last_update_tick < 1 then
		return
	end
	self.last_update_tick = now

	for k,v in pairs(self.entities) do
		if v ~= nil then
			if(v.m_entity_type == "Monster") and (v.m_hasai == true) then
				v:update()
			end
		end
	end

end

function  EntityManager:get_targetid_in_circle(x, y, radius)
	local ret = {}
	for k,v in pairs(self.entities) do
		if v ~= nil and k ~= self.player.m_id then
			local entX = v:get_position().x;
			local entY = v:get_position().y + 40;
			if(gameutils:is_point_in_circle(entX, entY, x, y, radius) == true) then
				table.insert(ret, k)
			end
		end
	end
	return ret
end


EntityManager:init()