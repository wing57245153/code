

--super_class.ClientSocket()
ClientWebSocket = {}

-------------------------------ClientSocket定义----------------------------------------

function ClientWebSocket:init()
	self.socket = WebSocket:create("ws://localhost:8001/")

	local function _on_socket_send(...)
		if (ClientWebSocket._pnum ==nil) then
			ClientWebSocket._pnum =0
		end
		ClientWebSocket._pnum = ClientWebSocket._pnum + 1
		idx = "["..tostring(ClientWebSocket._pnum).."]"
		--ClientWebSocket._print(idx)
		ClientWebSocket._print(idx, ...)
		strdata = idx
		for _, l in ipairs ({...}) do
			strdata = strdata.." "..tostring(l)
		end
		ClientWebSocket.socket:sendString(strdata)
		--ClientWebSocket.socket:sendString(strdata)
	end

	local function _on_socket_open(strdata)
		ClientWebSocket:on_open(strdata)
		ClientWebSocket._print = print
		print = _on_socket_send;
    end

    local function _on_socket_message(strdata)
		ClientWebSocket:on_message(strdata)
    end

    local function _on_socket_close(strdata)
		ClientWebSocket:on_close(strdata)
    end

    local function _on_socket_error(strdata)
		ClientWebSocket:on_error(strdata)
    end

	self.socket:registerScriptHandler(_on_socket_open,kWebSocketScriptHandlerOpen)
    self.socket:registerScriptHandler(_on_socket_message,kWebSocketScriptHandlerMessage)
    self.socket:registerScriptHandler(_on_socket_close,kWebSocketScriptHandlerClose)
    self.socket:registerScriptHandler(_on_socket_error,kWebSocketScriptHandlerError)
end

function ClientWebSocket:on_open(strdata)
	print("ClientWebSocket:on_open", strdata);
end

function ClientWebSocket:on_message(strdata)
	print("comd:", strdata);
	assert(loadstring(strdata))();
end

function ClientWebSocket:on_close(strdata)
	print("ClientWebSocket:on_close", strdata);
end

function ClientWebSocket:on_error(strdata)
	print("ClientWebSocket:on_error", strdata);
end

ClientWebSocket:init()