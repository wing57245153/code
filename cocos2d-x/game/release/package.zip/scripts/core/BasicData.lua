---基础动态数据类
require "scripts/core/GameWorld" 

super_class.BasicData()

function BasicData:__init()
	self.mainevent = ""
	self.subevent = "" --数据标识，数据更新时，方便模块获知
end

function BasicData:read( byteArray )
    
end

function BasicData:write( byteArray )
    
end

function BasicData:updateData()
    GameWorld.dataManager():updateData(self.mainevent, self.subevent, self)
end

function BasicData:sendData( byteArray )
	GameWorld.gameSocket():sendData( byteArray )
end