
local GameListener = {}


function GameListener:init()
	self.m_listener_list = {}
end

function GameListener:add_listener( mainevent, subevent, fun )
	print("GameListener", self)
	if (self.m_listener_list[mainevent] == nil) then
		self.m_listener_list[mainevent] = {}
	end
	if (self.m_listener_list[mainevent][subevent] == nil) then
		self.m_listener_list[mainevent][subevent] = {}
	end
	local t = self.m_listener_list[mainevent][subevent];
	for i,ofun in pairs(t) do
		if (ofun == fun) then
			return
		end
	end
	table.insert(t, fun);
	print("addListener", fun);
end

function GameListener:remove_listener( mainevent, subevent, fun )
	if (self.m_listener_list[mainevent] == nil) then
		return
	end
	if (self.m_listener_list[mainevent][subevent] == nil) then
		return
	end
	local t = self.m_listener_list[mainevent][subevent];
	for i,ofun in pairs(t) do
		if (ofun == fun) then
			table.remove(t, i);
			print("removeListener", fun);
			break;
		end
	end
end

function GameListener:dispatchEvent(mainevent, subevent, value)
	print("dispatchEvent", value)
	if (self.m_listener_list[mainevent] == nil) then
		return
	end
	if (self.m_listener_list[mainevent][subevent] == nil) then
		return
	end
	local t = self.m_listener_list[mainevent][subevent];
	for i,ofun in pairs(t) do
		ofun(value);
	end
end

GameListener:init()
return GameListener;
