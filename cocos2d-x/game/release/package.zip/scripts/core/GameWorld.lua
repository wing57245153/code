
-- 游戏启动时第一个应该require的模块
-- 游戏核心API模块，提供除cocos自身提供的API外所有核心API接口。
-- 每一个接口必须严格定义，并详细注释。
-- 所有core内部定义的类都不应该直接实例化，而应该通过此模块进行获取创建或者删除替换等。 

require "scripts/core/ResMgr"      -- 资源管理器资源统一获取的地方
require "scripts/core/LuaSetting"  -- 加载lua与引擎相关的设置定义
require "scripts/core/SuperClass"  -- 提供super_class类定义方式
require "scripts/core/State"       -- 提供游戏状态保存数据对象 States
require "scripts/core/Layer"       -- 提供游戏层次管理LayerManager
require "scripts/core/Entity"      -- 提供实体定义Entity 实体管理EntityManger
require "scripts/core/Camera"      -- 提供摄像机定义Camera 管理类CameraManager
require "scripts/core/Model"       -- 提供模型类定义
require "scripts/core/Effect"      -- 提供Effect
require "scripts/core/Space"       -- 提供模型类定义
--require "scripts/core/GameListener"-- 提供事件全局注册或触发
require "scripts/core/Audio"       -- 提供声音播放
require "scripts/core/DataManager" 
require "scripts/core/DataPool" 
require "scripts/core/Socket"

require "scripts/utils/Utils"

--[[require "scripts/spell/Spell"      -- spell
require "scripts/spell/FlyItem"      -- Flyitem
require "scripts/spell/Bullet"
require "scripts/spell/BulletBall"
require "scripts/spell/PopDamage"      -- Flyitem
require "scripts/spell/SpellMenu"      -- Flyitem
require "scripts/spell/FireBall"
require "scripts/utils/Utils"      -- Flyitem
]]


GameWorld = {}  --游戏全局主模块，大部分核心接口都通过此模块提供

GameWorld.Entity = Entity  --继承实体通过 super_class.NewEntity(GameWorld.Entity)继承

GameWorld.game_listener = nil --通过game_listener可获取全局唯一GameListener

GameWorld.game_data_manager = nil --数据管理器 用来通知数据更新等

GameWorld.game_data_pool = nil --数据池 用来存放各种动态数据

GameWorld.game_socket = nil --游戏socket，用来与服务器进行交互 websocket

-- function GameWorld.init() end

function GameWorld.game_time()
	return States.game_time;
end

--创建一个指定类型的实体，返回对应实体ID
function GameWorld.create_entity(entitytype, args) 
	return EntityManager:create_entity(entitytype, args);
end

--删除指定ID的实体
function GameWorld.destroy_entity(enitiyid)
	EntityManager:destroy_entity(entityid);
end

--获取当前实体列表
function GameWorld.entities()
	return EntityManager.entities;
end

--设置或获取当前player实体
function GameWorld.player(entity)
	if (entity~=nil) then EntityManager:set_player(entity) end;
	return EntityManager:get_player();
end

--创建一个新的逻辑摄像机
function GameWorld.create_camera()
	return CameraManager:create_camera()
end

--获取或者设置当前摄像机
function GameWorld.camera(camera)
	if (camera)then
		CameraManager:set_current_camera(camera);	
	end
	return CameraManager:get_current_camera();
end

--通过modelname创建一个模型
function GameWorld.model(modelname)
	return Model(modelname)
end

--通过modelname创建一个模型
function GameWorld.effect(effectname)
	return Effect(effectname)
end

function GameWorld.fireball(effectname)
	return FireBall(effectname)
end

function GameWorld.gameBus()
    ---[[
    if GameWorld.game_listener == nil then
    	GameWorld.game_listener = require "scripts/core/GameListener"
    end

    return GameWorld.game_listener
    --]]
    --return require "scripts/core/GameListener"
end

function GameWorld.dataManager()
    if GameWorld.game_data_manager == nil then
    	GameWorld.game_data_manager = DataManager()
    end

    return GameWorld.game_data_manager
end

function GameWorld.dataPool()
    if GameWorld.game_data_pool == nil then
    	GameWorld.game_data_pool = DataPool()
    end

    return GameWorld.game_data_pool
end

function GameWorld.gameSocket()
    if GameWorld.game_socket == nil then
        GameWorld.game_socket = Socket()
    end

    return GameWorld.game_socket
end
--GameWorld.init()