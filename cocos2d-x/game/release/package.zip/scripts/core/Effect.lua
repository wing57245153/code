

--模型逻辑主体，非显示对象，用于衔接引擎与脚本逻辑的管理对象
super_class.Effect()  

local EFFECT_PATH = "models/"

function Effect:__init(effectname)
	self.m_model_name = effectname;
	self.m_real_sprite = CCSprite:create();--真正的显示对象
	self.m_real_sprite:retain();
	self.m_real_sprite.isPaused = false
	self.m_animations = {};
	self.m_is_destroy = false;

end

function Effect:get_main_model_slot()
	return self.m_real_sprite;
end

function Effect:get_real_sprite()
	return self.m_real_sprite
end

function Effect:set_parent(parent)
	if (self.m_is_destroy) then return end;
	if (self.m_parent ~= nil) then
		self.m_parent:removeChild(self.m_real_sprite);
	end
	self.m_parent = parent;
	if (self.m_parent ~= nil) then
		self.m_parent:addChild(self.m_real_sprite);
	end
	--print("%%%%%%%%%%%%%%%set_parent", self.m_parent)
end

function Effect:destroy()
	--self:set_parent(nil);
	self.m_parent:removeChild(self.m_real_sprite, true);
	self.m_is_destroy = true;
	self.m_real_sprite:release();

end

function Effect:set_position(x, y)
	if (self.m_is_destroy) then return end;
	self.m_real_sprite:setPosition(CCPoint(x, y));
end

function Effect:set_scale(value)
	if (self.m_is_destroy) then return end;
	self.m_real_sprite:setScale(value);

end;

function Effect:play(aniname, play_once, angle, not_self_del)
	function hideself()
		if not_self_del == true then
			self.m_real_sprite:setVisible(false)
		else
			self:destroy()	
		end
	end
	self.m_real_sprite:setVisible(true)
	if (self.m_is_destroy) then return end;
	if (self.m_animations[aniname]==nil) then
 		do 
 			local animframes = CCArray:create()
 			local modelpathname = EFFECT_PATH .. self.m_model_name;
 			local anidata = require(modelpathname);
 			model_action_map = anidata.action_map
 			if (model_action_map==nil or model_action_map[aniname]==nil) then return end;
 			local curidx = 0;
 			local pngname;
 			local texture;
 			--数据结构 [文件名, 横向地址, 纵向地址, 子图片宽度,  子图片高度,  x方向偏移, y方向偏移]
 			for idx,fidx in ipairs(model_action_map[aniname]) do
 				if (anidata[fidx]==nil) then break end;
 				if (anidata[fidx][1]~=curidx) then 
 					curidx = anidata[fidx][1];
 					pngname = modelpathname.."_"..curidx..'.png';
 					texture = CCTextureCache:getInstance():addImage(pngname);
 				end
			    local sx = anidata[fidx][2];
			    local sy = anidata[fidx][3];
			    local sw = anidata[fidx][4];
			    local sh = anidata[fidx][5];
			    local offx = anidata[fidx][6] ;
			    local offy = anidata[fidx][7] ;
			    local rect = CCRect(sx, sy, sw, sh);
			    local frame = CCSpriteFrame:createWithTexture(texture, rect, false, CCPoint(offx,offy), rect.size);
			    animframes:addObject(frame);
			    --print("frame-------", aniname, pngname, sx, sy, sw, sh, offx, offy);
 			end
 			local animation = CCAnimation:createWithSpriteFrames(animframes, 0.1);
 			local animate = CCAnimate:create(animation);
 			self.m_animations[aniname] = animate;
 			animate:retain();

 		end
 	end
 	--self.m_real_sprite:stopAllActions();
 	if(self.m_cur_action)then
 		self:get_main_model_slot():stopAction(self.m_cur_action);
 	end
 	--print("self.m_animations[aniname]", self.m_animations[aniname]);
 	--self.m_cur_action = CCRepeatForever:create(self.m_animations[aniname]);
 	if play_once == nil or play_once == false then --循环播放
 		self.m_cur_action = CCRepeatForever:create(self.m_animations[aniname]);
 		self:get_main_model_slot():runAction(self.m_cur_action);
 	else
		local arr1 = CCArray:create()
		self.m_cur_action = self.m_animations[aniname]
		if angle ~= nil then
			arr1:addObject(CCRotateTo:create(0, angle))
		end
		arr1:addObject(self.m_cur_action)
		arr1:addObject(CCCallFunc:create(hideself))
		 local seq1 = CCSequence:create(arr1)	
    	self:get_main_model_slot():runAction(seq1);
 		--self.m_cur_action = self.m_animations[aniname]	
    	--self:get_main_model_slot():runAction(self.m_cur_action);
 	end
 	--self:get_main_model_slot():runAction(self.m_cur_action);
 	--self:set_mrror(true)
end

