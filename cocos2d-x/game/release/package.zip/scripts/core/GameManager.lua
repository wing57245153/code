---------游戏管理器---从这里初始化游戏 启动游戏

-- 这里初始化资源管理器
require "scripts/core/ModuleManager" 
require "scripts/core/AppEvent"

GameManager = {}

function GameManager:init()
	ModuleManager() --
    GameWorld.gameSocket()

    self:initEvent()
end

function GameManager:initEvent()
    local function ReceiveEnterGameResult(data)
    	print("enter game result....")
    	self:ReceiveEnterGameResult(data)
    end

    print("wer",NET_EVENT_M01, NET_EVENT_M0103)
    GameWorld.gameBus():add_listener(NET_EVENT_M01, NET_EVENT_M0103, ReceiveEnterGameResult)
end

function GameManager:ReceiveEnterGameResult( data )	
    if data.Result == 1301 then --登陆成功 进入游戏
        --GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_DESTROY_WINDOW, "RoleListModule")
        ----进入游戏
        --GameWorld.gameBus():dispatchEvent(GAME_EVENT, GAME_ENTER_EVENT, "enter_game")
        GameWorld.dataPool():setPlayerAttrList(data.AttrList) ---将玩家属性列表放入数据池
        GameStateManager:set_state("scene") ----进入场景
    else
        print("Enter fail..", data.Result)
    end
end
