require "scripts/core/GameWorld" 
require "scripts/core/AppEvent" 
require "scripts/core/Layer" 
require "scripts/config/module_config" 

super_class.ModuleManager()

function ModuleManager:__init( )
    self.messenger = GameWorld.gameBus() --全局传递者
    self:addEventLister()
end

local m_module_dic = nil;
function ModuleManager:addEventLister()
	m_module_dic = {}
    self.messenger:add_listener(MODULE_EVENT, MODULE_SHOW_WINDOW, self.showWindow)
    self.messenger:add_listener(MODULE_EVENT, MODULE_HIDE_WINDOW, self.hideWindow)
    self.messenger:add_listener(MODULE_EVENT, MODULE_DESTROY_WINDOW, self.destroyWindow)
end

--打开窗口
function ModuleManager.showWindow( name )
    print("showWindow", name)
    if m_module_dic[name] ~= nil then
        print("showWindow2", m_module_dic[name].m_parent)
    	LayerManager.layer_ui:addChild(m_module_dic[name].m_parent);
        ModuleManager.bring_window_center(m.m_parent)
    	return;
    end
    local config = module_config[name];
    if config ~= nil then
    	local f = config["fun"];
    	if f ~= nil then
    		local m = f();
    		m:create()
    		m:InitModule()
    		--print("m..." , m.m_parent)
    		LayerManager.layer_ui:addChild(m.m_parent);--添加到UI层
    		m_module_dic[name] = m;

    		ModuleManager.bring_window_center(m.m_parent)
    	end
    end
end

--隐藏窗口
function ModuleManager.hideWindow( name)
    print("hideWindow", m_module_dic[name].name)
    if m_module_dic[name] ~= nil then
    	if m_module_dic[name].m_parent:getParent() ~= nil then
    	    LayerManager.layer_ui:removeChild(m_module_dic[name].m_parent,false);
    	end
    	return;
    end
end

--销毁窗口
function ModuleManager.destroyWindow(name)
	print("destroyWindow", name)
	if m_module_dic[name] ~= nil then
		m_module_dic[name]:destroy(); -- 执行模块中的销毁方法，释放资源
    	if m_module_dic[name].m_parent:getParent() ~= nil then
    	    LayerManager.layer_ui:removeChild(m_module_dic[name].m_parent, true);
    	end

    	m_module_dic[name] = nil
    	return
    end
end


-- 将窗口置中
function ModuleManager.bring_window_center( window )
	local winSize = CCDirector:getInstance():getWinSize();
	local posx	= (winSize.width  - 100 ) / 2.0
	local posy 	= (winSize.height - 100) / 2.0
	window:setPosition(posx, posy)
end