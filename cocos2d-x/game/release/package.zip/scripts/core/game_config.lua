------保存游戏一个关键数据----
game_config = {}

game_config.AccId = 0 ---登陆账号
game_config.AccName = "" ---登陆账号名