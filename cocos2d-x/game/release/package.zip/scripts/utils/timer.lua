--回调！
--local CSS = CCScheduler:sharedScheduler()
--local scheduleScriptFunc = scheduler:scheduleScriptFunc
--local unscheduleScriptEntry = CSS.unscheduleScriptEntry
local Scheduler = CCDirector:getInstance():getScheduler()
--timer是很有可能会被派生的
super_class.timer()

timer.running = {}

--打印所有存活的timer
function timer.print_running()
	print('running timers:')
	for k,v in pairs(timer.running) do
		print(' ',k)
		print(' ',v)
		print(' ','----------------------')
	end
end

--构造函数，构造就立刻开始
function timer:__init()
	self.scheduler_id = nil			--计划id
end

function timer:start(_time, _function)
--@debug_begin
	assert(self.scheduler_id == nil)
	assert(_function)

	local t = debug.getinfo(2,'Sl')
	timer.running[self] = t
--@debug_end
	self.scheduler_id = Scheduler:scheduleScriptFunc(_function,_time,false)
end

--取消
function timer:stop()
	if self.scheduler_id then
		Scheduler:unscheduleScriptEntry(self.scheduler_id)
		self.scheduler_id = nil
--@debug_begin
		timer.running[self] = nil
--@debug_end
	end
end

--是否空闲，如果空闲可以被start
function timer:isIdle()
	return self.scheduler_id == nil
end




function testtimer()
	require 'base'
	require 'utils/callback'
	--两个timer
	local function fd(dt) print('timer:' .. dt) end
	local t0 = timer()
		  t0:start(1,fd)

	local function fd2(dt) print('timer:' .. dt) end
	local t1 = timer()
		  t1:start(2,fd)

	--存活的timer
	local function runningcb(dt) print('cb1:' .. dt); timer.print_running()  end
	local cb1 = callback:new()
		  cb1:start(2,runningcb)

	--取消timer
	local function byebyetimer0(dt) t0:stop(); print('bye bye timer0');timer.print_running() end
	local cb2 = callback:new()
		  cb2:start(10,byebyetimer0)
end
