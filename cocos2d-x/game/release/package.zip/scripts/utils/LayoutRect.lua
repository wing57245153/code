------------------------------------------------
------- 布局区域
------- 和锚点相关
------------------------------------------------

super_class.LayoutRect()

function LayoutRect:__init(anchorPoint)
	require "scripts/core/Layer"
	anchorPoint = anchorPoint or CCPoint(0, 0)
	local width = GameScreenFactors.standard_width
	local height = GameScreenFactors.standard_height
	local leftX = (-anchorPoint.x) * width
	local rightX = (1 - anchorPoint.x) * width
	local offsetX = (0.5 - anchorPoint.x) * width
	local topY = (1 - anchorPoint.y) * height
	local bottomY = (-anchorPoint.y) * height
	local offsetY = (0.5 - anchorPoint.y) * height

	self._leftBottom = CCPoint(leftX, bottomY)
	self._left = CCPoint(leftX, offsetY)
	self._leftTop = CCPoint(leftX, topY)
	self._bottom = CCPoint(offsetX, bottomY)
	self._center = CCPoint(offsetX, offsetY)
	self._top = CCPoint(offsetX, topY)
	self._rightBottom = CCPoint(rightX, bottomY)
	self._right = CCPoint(rightX, offsetY)
	self._rightTop = CCPoint(rightX, topY)
end

function LayoutRect:left()
	return self._left
end

function LayoutRect:leftBottom()
	return self._leftBottom
end

function LayoutRect:leftTop()
	return self._leftTop
end

function LayoutRect:bottom()
	return self._bottom
end

function LayoutRect:center()
	return self._center
end

function LayoutRect:top()
	return self._top
end

function LayoutRect:rightBottom()
	return self._rightBottom
end

function LayoutRect:right()
	return self._right
end

function LayoutRect:rightTop()
	return self._rightTop
end