-- Utils.lua
-- created by aXing on 2012-12-4
-- 公共函数

Utils = {}


MINI_DATE_TIME_BASE = 1262275200;

-- 取一个32位整数的低16位 
function Utils:low_word( input )
	return input
end

-- 取一个32位整数的高16位
function Utils:high_word( input )
	return input
end

-- 取一个16位整数的低8位
function Utils:low_byte( input )
	return input
end

-- 取一个16位整数的高8位
function Utils:high_byte( input )
	return input
end

-- 取一个整数的 第 n 个8位  lyl
function Utils:get_byte_by_position( input, n )
	local output = input
	for i = 1, (n - 1) do
        output = output / (2 ^ 8) - output / (2 ^ 8) % 1
	end
	output = output % (2 ^ 8)
	return output
end

-- 获取某个数的二进制表示的 第n位  lyl
function Utils:get_bit_by_position( input, n )
    local output = input
    output = output / ( 2 ^ ( n -1 ) ) -- 先去掉该位置后面的数
    output = math.floor( output )      -- 取整
    output = output % 2                -- 取最后一位
    return output
end

--取整数 -by fjh
function Utils:getIntPart(x)
	if x <= 0 then
	   return math.ceil(x);
	end

	x = math.floor(x);
	return x;
end



--格式化时间，-by fjh
function Utils:formatTime( second )
	
	local m = Utils:getIntPart(second/60);
	if m > 0 then
		local s = second%60;
		local h = Utils:getIntPart(m/60);
		if h>0 then
			local _m = m%60;
			local d = Utils:getIntPart(h/24);
			if d>0 then
				local _h = h%24;
				return string.format("%d天%d小时%d分%d秒",d,_h,_m,s);
			end
			return string.format("%d小时%d分%d秒",h,_m,s);
		end
		return string.format("%d分%d秒",m,s); 
	end
	return string.format("%d秒",second);

end

-----HJH
-----2012-12-27
-----用于指定字符分拆
function Utils:Split(szFullString, szSeparator)  
	local nFindStartIndex = 1  
	local nSplitIndex = 1  
	local nSplitArray = {}  
	while true do  
	   local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)  
	   if not nFindLastIndex then  
	    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))  
	    break  
	   end  
	   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)  
	   nFindStartIndex = nFindLastIndex + string.len(szSeparator)  
	   nSplitIndex = nSplitIndex + 1  
	end  
	return nSplitArray  
end  

-- 十进制数字转成十六进制,并且转成字符串(颜色的数值转换用，所以会补0),注意只返回两位
function Utils:hex_to_dec( num )
	local ret = ""
	if type(num) ~= "number" then
        return "00"
    end
    local hex_num_t = {"1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"}
    local count = 0   -- 位数计数，补0用
    local single_digit = 0
    while num ~= 0 do
    	single_digit = hex_num_t[ num % 16 ] or 0
        ret = tostring( single_digit )..ret
        num = num / 16 - num / 16 % 1
        count = count + 1
    end
    -- 不足两位补0
    for i = 1, (2 - count) do
        ret = "0"..ret
    end
    -- 超过两位，就只取后面的两位
    if string.len (ret) > 2 then
        ret = string.sub(ret,-2, -1)
    end

    return ret
end

function Utils:c3_dec_to_hex( num )
	local ret = ""
	if type(num) ~= "number" then
        return "00"
    end
    local hex_num_t = {"1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"}
    local count = 0   -- 位数计数，补0用
    local single_digit = 0
    while num ~= 0 do
    	single_digit = hex_num_t[ num % 16 ] or 0
        ret = tostring( single_digit )..ret
        num = num / 16 - num / 16 % 1
        count = count + 1
    end
    -- 不足两位补0
    for i = 1, (6 - count) do
        ret = "0"..ret
    end
    -- 超过两位，就只取后面的两位
    if string.len (ret) > 6 then
        ret = string.sub(ret,-2, -1)
    end

    return ret
end

-- 克隆一个table. 复制传入的table返回(注：目前只支持复制包含简单数据的table，支持table嵌套).
function Utils:table_clone( table_obj )
	local table_clone = {}
	for key, element in pairs(table_obj) do
        if type(element) == "table" then
            table_clone[ key ] = Utils:table_clone( element )
        else
        	table_clone[ key ] = element
        end
	end
	return table_clone
end

-- 打印一个table所有 key 和数据 （提供测试用, 注意不是按顺序打印的） 第二个参数传nil
function Utils:print_table_key_value( table_obj, count )
	-- 打印分割符号
    local  print_str = ""
    local count_temp = count or 0
    for i = 1, count_temp do
        print_str = print_str .. "."
    end
    print( print_str, "====================================")


	for key, value in pairs( table_obj ) do
        if type( value ) == "table" then
            Utils:print_table_key_value( value, count_temp + 6 )
        else
        	print( tostring( key ), tostring( value ) )
        end
	end
end

-- 四舍五入取整
function Utils:math_round( num )
    if type(num) == "number" then
        local num_temp = num % 1
        if num_temp >= 0.5 then
            return math.ceil(num)
        else
            return math.floor(num)
        end
    end
    return num
end

-- 把 秒为单位的时间，变成24小时制式的字符串
function Utils:second_to_24time_str( second_time )
    if second_time == nil or second_time < 0 then
        return "0:0:0"
    end
    local time_temp = second_time % ( 24 * 60 * 60 )
    local hours = math.floor( time_temp / ( 60 * 60 ) )      -- 小时

    time_temp = time_temp % ( 60 * 60 )
    local minites = math.floor( time_temp / 60 )             -- 分

    time_temp = time_temp % 60
    local second = math.floor( time_temp )                   -- 秒

    return hours..":"..minites..":"..second
end

-- 把 秒为单位的时间，变成自定义制式的字符串
-- %Y年%m月%d日 %H时%M分 格式符号
function Utils:get_custom_format_time(format_str ,custom_time )
    require "scripts/utils/Utils"
    local time;
    if custom_time > 0x80000000 then
        time = custom_time-2147483648;
    else
        time = custom_time;
    end
    local str = os.date(format_str,(time+MINI_DATE_TIME_BASE));
    return str;
end


-- 实现table的深拷贝
function Utils:table_deepcopy(ori_table)
    
    local function th_table_dup( ori_tab )
        if (type(ori_tab) ~= "table") then
            return nil;
        end
        local new_tab = {};
        for i,v in pairs(ori_tab) do
            local vtyp = type(v);
            if (vtyp == "table") then
                new_tab[i] = th_table_dup(v);
            elseif (vtyp == "thread") then
                -- TODO: dup or just point to?
                new_tab[i] = v;
            elseif (vtyp == "userdata") then
                -- TODO: dup or just point to?
                new_tab[i] = v;
            else
                new_tab[i] = v;
            end
        end
        return new_tab;
    end
    
    return th_table_dup( ori_table );

end

-- 8bit 负数补码形式，转成 其表示的数字
function Utils:complement_to_num( complement )
    -- 还原负数补码： 减1  取反（255 - ）  在确定符号位（ 0 - ）
    local num = 0 - ( 255 - ( complement - 1) )
    return num
end

function Utils:get_table_len( t )
    local len = 0
    for k,v in pairs(t) do
        len = len + 1
    end
    return len
end

