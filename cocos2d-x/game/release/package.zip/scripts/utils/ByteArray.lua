require "scripts/utils/Utils"
super_class.ByteArray()

BYTE_TYPE = 1
SHORT_TYPE = 2
INT_TYPE = 3
INT64_TYPE = 151
STRING8_TYPE = 61
STRING_TYPE = 62
LIST8_TYPE = 51
LIST16_TYPE = 52
LIST32_TYPE = 53

BIN8_TYPE = 101
BIN16_TYPE = 102
BIN32_TYPE = 103

function ByteArray:__init()
    self.bytesAvailable = 0  --可从字节数组的当前位置到数组末尾读取的数据的字节数。
    self.length = 0 --ByteArray 对象的长度（以字节为单位）。
    self.position = 1 --当前位置 从1开始索引
    self.data = {}
    self.atrNum = 0;

    self.readType = {}
    self.readType[BYTE_TYPE] = "readByte"
    self.readType[SHORT_TYPE] = "readShort"
    self.readType[INT_TYPE] = "readInt"
    self.readType[INT64_TYPE] = "readInt64"
    self.readType[STRING_TYPE] = "readUTF"
    self.readType[STRING8_TYPE] = "readUTF8"
    self.readType[LIST8_TYPE] = "readList"
    self.readType[LIST16_TYPE] = "readList"
    self.readType[LIST32_TYPE] = "readList"
    self.readType[BIN16_TYPE] = "readUTF"
    self.readType[BIN8_TYPE] = "readUTF8"
    self.readType[BIN32_TYPE] = "readUTF32"

    self.writeType = {}
    self.writeType[BYTE_TYPE] = "writeByte"
    self.writeType[SHORT_TYPE] = "writeShort"
    self.writeType[INT_TYPE] = "writeInt"
    self.writeType[INT64_TYPE] = "writeInt64"
    self.writeType[STRING_TYPE] = "writeUTF"
    self.writeType[LIST8_TYPE] = "writeList"
    self.writeType[LIST16_TYPE] = "writeList"
    self.writeType[LIST32_TYPE] = "writeList"
    self.writeType[BIN16_TYPE] = "writeUTF"
end

function ByteArray:setData(data)
	self.data = data
	if type(data) == "table" then
	    self.length = table.getn(data)
	end
	self.bytesAvailable = self.length
end

--从字节流中读取带符号的字节。
function ByteArray:readByte()
    local byte = self.data[self.position]
    self.bytesAvailable = self.bytesAvailable - 1
	self.position = self.length - self.bytesAvailable + 1
    return byte
end

function ByteArray:readShort()
    local byte1 = self:readByte()
    local byte2 = self:readByte()
    local short = byte1 * 256 + byte2
    return short
end

function ByteArray:readInt()
    local short1 = self:readShort()
    local short2 = self:readShort()
    local int = short1 * 65536 + short2
    return int
end

---实际是一个字符串
function ByteArray:readInt64()
    local int64 = ""
    local len = 64
    local i = 1
    local byte = 0
    for i = 1,len do
    	byte = self:readByte()
        int64 = int64 .. string.char(byte)
    end
    return int64
end

function ByteArray:readBytes(len)
    local bytes = ByteArray()
    local i = 1
    for i = 1,len do
        bytes:writeByte(bytes:readByte())
    end

    return bytes
end

--从字节流中读取一个 UTF-8 字符串。假定字符串的前缀是无符号的短整型（以字节表示长度）。
function ByteArray:readUTF()
	local str = ""
	local len = self:readShort() --短整型（以字节表示长度）
	local i = 1
	local byte = 0;
	for i = 1, len do
		byte = self:readByte()
        str = str .. string.char(byte)
	end

    return str
end

function ByteArray:readUTF8()
    local str = ""
    local len = self:readByte() --短整型（以字节表示长度）
    local i = 1
    local byte = 0;
    for i = 1, len do
        byte = self:readByte()
        str = str .. string.char(byte)
    end

    return str
end

function ByteArray:readUTF32()
    local str = ""
    local len = self:readInt() --短整型（以字节表示长度）
    local i = 1
    local byte = 0;
    for i = 1, len do
        byte = self:readByte()
        str = str .. string.char(byte)
    end

    return str
end

function ByteArray:readList( listAtr , typeRead , parent)
    local len = 0

    if typeRead == LIST8_TYPE then
    	len = self:readByte()
    elseif typeRead == LIST16_TYPE then
    	len = self:readShort()
    else
        len = self:readInt()
    end

    local writeCount = len

    --print(typeRead,"typeRead", writeCount)

    local root = nil
    if listAtr.name == nil then
        root = parent
    else
        if parent[listAtr.name] == nil then
            parent[listAtr.name] = {}
        end
        root = parent[listAtr.name]
    end
    
    local list = nil

    while writeCount > 0 do
    table.foreachi(listAtr, function(i, v)
    	   if type(v) == "table" then
    	   	if v.name == nil then
    	   		list = {}
    	   	    table.insert(root, list)
    	   	    self:readByType(v, list)
    	   	else
    	   		if root[v.name] == nil then
                   root[v.name] = {}
                end
                self:readByType(v, root)
    	   	end

    	   else
    	   	root[v] = self:readByType(v)
    	   end
           writeCount = writeCount - 1
           end
    	)
    end

    --return list;
end 

---通过类型来读取数据
function ByteArray:readByType( listAtr , parent)
	local typeRead = self:readByte()
	local result = nil
	result = self[self.readType[typeRead]](self, listAtr, typeRead , parent)

	return result
end

-------------------------------------------------------

function ByteArray:writeByte(byte)
    self.data[self.length + 1] = byte
    self.length = table.getn(self.data)
    self.bytesAvailable = self.bytesAvailable + 1
end

function ByteArray:writeShort( short )
    local byte2 = short % 256
    local byte1 = ( short - byte2 ) / 256
    self:writeByte(byte1)
    self:writeByte(byte2)
end

function ByteArray:writeInt( int )
    local short2 = int % 65536
    local short1 = (int - short2) / 65536
    self:writeShort(short1)
    self:writeShort(short2)
end

--32位字符串
function ByteArray:writeInt32( int32 )
    local len = string.len(int32)
    local i = 1
    local byte = nil
    for i = 1, len do
        byte = string.byte(int32, i)
        self:writeByte(byte)
    end
end

--写二进制串
function ByteArray:writeBytes( bytes )
    for k, v in pairs(bytes.data) do
    	self:writeByte(v)
    end
end

function ByteArray:writeUTF( str )
	local i = 1
	local len = 0
	local byte = string.byte(str, i)
	while byte ~= nil do
		len = len + 1
		i = i + 1
		byte = string.byte(str, i)
	end
	
	self:writeShort(len)
	for i=1,len do
		byte = string.byte(str, i)
		self:writeByte(byte)
	end
end

function ByteArray:writeList( data, listAtr)
    local len = table.getn(listAtr)
    self:writeByte(52)
    self:writeShort(len)--再做判断

    local attrName = nil
    local attrType = nil
    local i = 1
    table.foreachi(listAtr, function(k, v)
        --attrName, attrType = self:getAttrInfo(v)
        attrName = v
    	if attrType == 52 then
    		len = table.getn(data[attrName])
    		self:writeByte(52)
            self:writeShort(len)
    		for i = 1, len do
    			self:writeByType(data[attrName][i], listAtr[attrName])
    		end 
    	else
            attrType = self:getAttrType(data,attrName)
    		self:writeByType(data[attrName], attrType)
    	end
    end
    )
end

function ByteArray:writeByType(data, attrType)
	if type(attrType) == "table" then
		self:writeList(data, attrType)
	else
        self:writeByte(attrType)
        self[self.writeType[attrType]](self, data)
	end
end
---------------------

function ByteArray:toString()
    local str = ""
    for k, v in pairs(self.data) do
    	str = str .. string.char(v)
    end
    return str
end

function ByteArray:print()
    local str = "["
    for k, v in pairs(self.data) do
    	str = str .. tostring(v) .. ","
    end
    str = str .. "]"
    print(str)
end

function ByteArray:getAttrInfo(str)
    local index = string.find(str, '#')
    local attrName = string.sub(str,1, index - 1)
    local attrType = tonumber(string.sub(str, index + 1, -1))
    return attrName, attrType
end

function ByteArray:getAttrType(data, attrName)
    local value = data[attrName]
    local attrType = STRING_TYPE
    local typestr = type(value)
    local strhead = nil
    local strtail = nil ---用来判断字符串是否为二进制数据
    if typestr == "string" then
        strhead = string.sub(value, 2)
        strtail = string.sub(value, -2)
        if strhead == "<<" and strtail == ">>" then
            attrType = BIN16_TYPE
            data[attrName] = string.sub(value, 3, -3)
        else
            attrType = STRING_TYPE
        end
    elseif typestr == "number" then
        if value < 256 then
            attrType = BYTE_TYPE
        elseif value < 65536 then
            attrType = SHORT_TYPE
        else
            attrType = INT_TYPE
        end
    end

    return attrType
end