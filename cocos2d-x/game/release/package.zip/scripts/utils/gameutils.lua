
gameutils = {}

gameutils.TILE_WIDTH_PIXEL = 50;
gameutils.TILE_HEIGHT_PIXEL = 30

function gameutils.x_pos_2_tile(xpos)
	return math.floor(xpos / gameutils.TILE_WIDTH_PIXEL);
end

function gameutils.y_pos_2_tile(ypos)
	return math.floor( ypos / gameutils.TILE_HEIGHT_PIXEL);
end

function gameutils.position_distance(x1, y1, x2, y2)
	local dx = x2 - x1;
	local dy = y2 - y1;
	return math.sqrt(dx * dx + dy * dy);
end

--获得sx, sy为开始点，dx, dy为终点的线段上，距离为dist的新点
function gameutils:get_point_by_dist(x1, y1, x2, y2, dist)
    local ro = math.atan2(y2 - y1, x2 - x1)
    local x3 = dist * math.cos(ro) + x1;
    local y3 = dist * math.sin(ro) + y1;
    return {x=x3, y=y3}
end

        --[[//点在圆形范围内
        public static function IsPointInCircle(x:int, y:int, ox:int, oy:int,
            radius:int) : Boolean
        {
            var r2:int = (x - ox) * (x - ox) + (y - oy) * (y - oy);
            return r2 < radius * radius ? true : false;
        }]]
function gameutils:is_point_in_circle(x, y, ox, oy, radius)
	local r2 = (x - ox) * (x - ox) + (y - oy) * (y - oy);
	if(r2 < radius * radius) then
		return true
	end
	return false
end

--PI->180;弧度转角度
function gameutils:radian_to_angle(radian)
 	return radian * (180 / math.pi)
    --return math.deg(radian)
end

--180->PI,角度转弧度
function gameutils:angle_to_radian(angle)
 	return angle * (math.pi / 180)
    --return math.rad(angle)
end

        --[[//获得两点弧度
        public static function GetRadian(x:int, y:int, x1:int, y1:int) : Number
        {
            return Math.atan2(y1 - y, x1 - x);
        }]]
--获得两点弧度
function gameutils:get_radian(x, y, x1, y1)
	return math.atan2(y1 - y, x1 - x)
end

        --[[//点在扇形范围内
        public static function IsPointInFan(x:int, y:int, ox:int, oy:int, radius:int,
            face_angle:Number, angle_range:Number) : Boolean
        {
            var EPSILON:Number = 5.0;
            var r:Number;
            var mydot:Number;
            //face_angle = angleToRadian(face_angle);
            //angle_range = angleToRadian(angle_range);
            if(!IsPointInCircle(x, y, ox, oy, radius))
                return false;

            r = Math.sqrt((x - ox) * (x - ox) + (y - oy) * (y - oy));
            if(r < EPSILON)
                return true;

            mydot =
                ((x - ox) / r) * Math.cos(face_angle) -
                ((y - oy) / r) * Math.sin(face_angle);
            return mydot > Math.cos(angle_range * 0.5) ? true : false;
        }]]
 --判断点x,y, 是否在ox,oy为圆点，半径radius, 朝向角度face_angle，扇形角度
function gameutils:is_point_infan(x, y, ox, oy, radius, face_angle，angle_range)
	local EPSILON = 5.0
	local r
	local mydot
	if self:is_point_in_circle(x, y, ox, oy, radius) == false then
		return false
	end

	r = math.sqrt((x - ox) * (x - ox) + (y - oy) * (y - oy));
	if r < EPSILON then
		return true
	end
	mydot = ((x - ox) / r) * Math.cos(face_angle) - ((y - oy) / r) * Math.sin(face_angle);
	local ret = false

	if mydot > math.cos(angle_range * 0.5) then
		ret = true
	end
	return ret
end
--[[
        public static function GetFanCenterPos(ox:int, oy:int, radius:int,
            face_angle:Number) : Point
        {
            var x1:int = int(radius * Math.cos(face_angle));
            var y1:int = int(radius * Math.sin(face_angle));
            return new Point(x1 + ox, y1 + oy);
        }]]

function gameutils:get_fan_center_pos(ox, oy, radius, face_angle)
	local x1 = radius * math.cos(face_angle)
	local y1 = radius * math.cos(face_angle)
	return {x = x1 + ox, y = y1 + oy}
end

        --[[//angle为角度,根据x1,y1,x2,y2偏移angle角度获得新坐标
        public static function GetAnglePoint(x1:int, y1:int, x2:int, y2:int, angle:Number) : Point
        {
            //y2  = y1 -//修正成笛卡尔坐标
            //var a:Number = Math.tan((y2 - y1) / (x2 - x1));
            angle = AngleToRadian(angle); //转成弧度
            var ro:Number = Math.atan2(y2 - y1, x2 - x1);
            var newro:Number = ro - angle;
            var dist:Number = Point.distance(new Point(x1, y1), new Point(x2, y2));
            var x3:int = dist * Math.cos(newro) + x1;
            var y3:int = dist * Math.sin(newro) + y1;
            return new Point(x3, y3);
        }]]

function gameutils:get_angle_pos(x1, y1, x2, y2, angle)
    local radian = self:angle_to_radian(angle)
    local ro = math.atan2(y2 - y1, x2 - x1)
    local newro = ro - radian
    local dist = gameutils.position_distance(x1, y1, x2, y2)
    local x3 = dist * math.cos(newro) + x1
    local y3 = dist * math.sin(newro) + y1
    return {x = x3, y = y3}
end

       --[[//根据三点算出abc,返回[a, b, c]
        public static function CalcHitFlyABC(startPoint:Point, endPoint:Point, High:int = 100):Array
        {
            var x1:int = startPoint.x;
            var y1:int = startPoint.y;
            var x3:int = endPoint.x;
            var y3:int = endPoint.y;
            var minY:int = Math.min(y1, y3);
            var x2:int = (x3 + x1) / 2;
            var y2:int = minY - High;
            var b:Number = ((y1 - y3) * (x1 * x1 - x2 * x2) - (y1 - y2) * (x1 * x1 - x3 * x3)) / ((x1 - x3) * (x1 * x1 - x2 * x2) - (x1 - x2) * (x1 * x1 - x3 * x3)); 
            var a:Number = ((y1 - y2) - b * (x1 - x2)) / (x1 * x1 - x2 * x2);
            var c:Number = y1 - a * x1 * x1 - b * x1;
            return [a, b, c]
        }]]
function gameutils:calc_hit_fly_abc(startPoint, endPoint, High)
    local x1 = startPoint.x
    local y1 = startPoint.y
    local x3 = endPoint.x
    local y3 = endPoint.y
    local minY = math.min(y1, y3)
    local x2 = (x3 + x1) / 2
    local y2 = minY + High
    local bb = ((y1 - y3) * (x1 * x1 - x2 * x2) - (y1 - y2) * (x1 * x1 - x3 * x3)) / ((x1 - x3) * (x1 * x1 - x2 * x2) - (x1 - x2) * (x1 * x1 - x3 * x3))
    local aa = ((y1 - y2) - bb * (x1 - x2)) / (x1 * x1 - x2 * x2)
    local cc = y1 - aa * x1 * x1 - bb * x1;
    return {a = aa, b = bb, c = cc}
end

        --[[//套用a*x^2 + b*x + c算出y
        public static function GetHitFlyY(params:Array, x:Number):Number
        {
            var a:Number = params[0];
            var b:Number = params[1];
            var c:Number = params[2];
            var y:Number = a * x * x + b * x + c;
            return y;
        }]]
function gameutils:get_hit_flyY(params, x)
    local a = params.a
    local b = params.b
    local c = params.c
    return  a * x * x + b * x + c;
end

--判断和目标距离
function gameutils:is_close_target(src_creature, dst_creature, dist)
    local value = false
    local mydist = gameutils.position_distance(src_creature:get_position().x, src_creature:get_position().y, 
                dst_creature:get_position().x, dst_creature:get_position().y)

    if (mydist < dist)then
        value = true
    end
    return value
end

