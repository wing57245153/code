--回调！
local CSS = CCScheduler:sharedScheduler()
local scheduleScriptFunc = CSS.scheduleScriptFunc
local unscheduleScriptEntry = CSS.unscheduleScriptEntry

--类
callback = { running = {} }

function callback.print_running()
	print('running callbacks:')
	for k,v in pairs(callback.running) do
		print(' ',k)
		print(' ',v)
		print(' ','-------------------------')
	end
end
--new函数
function callback:new( ... )
    local i = {}
    setmetatable(i, self)
    self.__index = self
	i:__init( ... )
    return i
end

--构造函数，构造就立刻开始
function callback:__init()
	self.scheduler_id = nil			--计划id
end

function callback:start(_time, _function)
--@debug_begin
	assert(self.scheduler_id == nil)
	assert(_function)

	local t = debug.getinfo(2,'Sl')
	callback.running[self] = t
--@debug_end
	local function cb(dt) 
		unscheduleScriptEntry(CSS,self.scheduler_id)
		self.scheduler_id = nil
		_function(dt) 
--@debug_begin
		callback.running[self] = nil
--@debug_end

	end
	self.scheduler_id = scheduleScriptFunc(CSS,cb,_time,false)
end

--取消
function callback:cancel()
	if self.scheduler_id then
		unscheduleScriptEntry(CSS,self.scheduler_id)
		self.scheduler_id = nil
--@debug_begin
		callback.running[self] = nil
--@debug_end
	end
end

--是否空闲，如果空闲可以被start
function callback:isIdle()
	return self.scheduler_id == nil
end



function testcallback()
	require 'base'
	local function fd(dt) print('time:' .. dt) end
	local function runningcb(dt) print('time:' .. dt); callback.print_running()  end

	local cb0 = callback:new()
	local cb1 = callback:new()
	local cb2 = callback:new()
	--在第三秒取消第四秒的
	local function cancel(dt) print('time:' .. dt); cb2:cancel();callback.print_running() end
	local cb3 = callback:new()

	cb0:start(1,fd)
	cb1:start(2,runningcb)
	cb2:start(4,fd)
	cb3:start(3,cancel)



	print(cb0.scheduler_id)
	print(cb1.scheduler_id)
	print(cb2.scheduler_id)
	print(cb3.scheduler_id)
end