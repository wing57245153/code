PopDamageManager = {}


function PopDamageManager:init()    --单例初始化方法
	self.popdamage_pool = {}
	self.has_inited = false
	self.m_parent = nil
end

function PopDamageManager:init_pool()
	if self.has_inited == true then
		return;
	end;

	self.m_parent = LayerManager:get_layer_effect()
		
	for i=1,10 do
	    local label1 = CCLabelBMFont:create("-150", "fonts/helvetica-32.fnt", -1, 0, CCPoint(0,0));
	    self.popdamage_pool[i] = label1;
	    self.m_parent:addChild(label1);
	    label1:setPosition(0,0);

	end	
	self.has_inited = true
	-- body
end


function PopDamageManager:get_useable_item()
	self:init_pool()
	local ret = nil
	--print("len=", #self.flyitem_pool)
	for i,v in pairs(self.popdamage_pool) do
		--print("bbbbbb=", i, v, #self.flyitem_pool)
		if v ~= nil and v ~= 1 then
			ret = v
			self.popdamage_pool[i] = 1;
			break;
		end
	end	
	--ret = self.flyitem_pool[1]
	return ret
end

function PopDamageManager:play_damage(x, y, value)
	local flyitem = self:get_useable_item()
	if flyitem == nil then
		return
	end
	local  s = string.format("HP-%d", value)
	flyitem:setString(s)
	flyitem:setPosition(CCPoint(x, y))
	local move = CCMoveTo:create(0.4, CCPoint(x, y + 60));
	function release()
		flyitem:setVisible(false)
		--self.m_parent:removeChild(flyitem)
		for i,v in pairs(self.popdamage_pool) do
			if v == 1 then
				self.popdamage_pool[i] = flyitem;
				flyitem = nil
				break;
			end
		end			
	end

	function setVisible()
		flyitem:setVisible(true)
		--self.m_parent:addChild(flyitem)
	end

	local arr = CCArray:create()
	arr:addObject(CCCallFunc:create(setVisible))
	arr:addObject(move)
	arr:addObject(CCCallFunc:create(release))
	local seq = CCSequence:create(arr)	
	flyitem:runAction(seq)	
end

PopDamageManager:init()
