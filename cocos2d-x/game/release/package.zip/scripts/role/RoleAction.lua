--super_class.RoleAction()

hitback_type = {};
hitback_type.HIT_NONE = 0
hitback_type.HIT_BACK = 1
hitback_type.HIT_FLY = 2


RoleAction = {}
function RoleAction:__init()
	self.m_id = 0;
end

--function RoleAction:showDot()
--	self.red = CCSprite:create("images/ball.png");
--	LayerManager:get_layer_model():addChild(self.red);
--end

function RoleAction:get_step_attack(caster)
	if caster.common_atk_counter > 3 then
		caster.common_atk_counter = 1
	end

	local d = {
				[1] = action_config.STATE_ATTACK,
				[2] = action_config.STATE_ATTACK1,
				[3] = action_config.STATE_ATTACK2
			  } 
	local state = d[caster.common_atk_counter]
	if caster.common_atk_counter == 3 then
		GameWorld.camera():shake(0, 7, 3, 0.05, 10)
				
	end
	--self:play_skill_music(caster.attack_step)
	caster.common_atk_counter = caster.common_atk_counter + 1	
	caster:set_state(state)
	AudioManager:playEffect("sounds/gongji.mp3")
end

function RoleAction:doFanAttack(caster)
	if caster:isAttacking() == true then
		return
	end

	local detected_point = GameWorld.player():get_face_point(100)
	
	caster:set_state(action_config.STATE_ATTACK1)	
	
	local casterX = caster:get_position().x
	local casterY = caster:get_position().y
	local targetX = casterX + detected_point.x
	local targetY = casterY + detected_point.y
	local targetlist = EntityManager:get_targetid_in_circle(targetX, targetY, 150)
	local attack_angle = gameutils:get_radian(casterX, casterY, targetX, targetY)
	for k,v in pairs(targetlist) do
		local ent = EntityManager:get_entity(v)
		if ent then
			ent:play_beattack_effect()
			--ent:hit_fly(casterX, casterY, 250, attack_angle)
			ent:hit_backex(casterX, casterY, 200)	
			PopDamageManager:play_damage(ent:get_position().x, ent:get_position().y + 120, 200)	
		end
	end	

	--播放特效
	local face_angle = gameutils:get_radian(casterX, casterY, targetX, targetY)
	face_angle = 90 - gameutils:radian_to_angle(face_angle)
    local effect = GameWorld.effect("effect1")
    effect:set_parent(LayerManager:get_layer_effect());
    effect:set_position(casterX, casterY + 50)
    effect:play("playeffect", true, face_angle)	

    AudioManager:playEffect("sounds/gongji.mp3")		

end

function  RoleAction:doCrashAttack(caster)

	if caster:isAttacking() == true then
		return
	end

	local detected_point = GameWorld.player():get_face_point(100)
	local casterX = caster:get_position().x
	local casterY = caster:get_position().y
	local targetX = casterX + detected_point.x
	local targetY = casterY + detected_point.y
	local tmp_pos = gameutils:get_point_by_dist(casterX, casterY, targetX, targetY, 350)
	--caster:set_state(action_config.STATE_ATTACK1)
	caster:force_move(tmp_pos.x, tmp_pos.y, 1000)	
	local targetlist = EntityManager:get_targetid_in_circle(targetX, targetY, 150)
	local attack_angle = gameutils:get_radian(casterX, casterY, targetX, targetY)
	for k,v in pairs(targetlist) do
		local ent = EntityManager:get_entity(v)
		if ent then
			ent:play_beattack_effect()
			PopDamageManager:play_damage(ent:get_position().x, ent:get_position().y + 120, 250)	
		end
	end	

    AudioManager:playEffect("sounds/gongji.mp3")	
end

function RoleAction:doCommonAttack(caster)
	if caster:isAttacking() == true then
		return
	end

	local now = GameWorld.game_time();
	--print("delay=", now - caster.last_common_atk_tick)
	if now - caster.last_common_atk_tick > 1.5 then
		caster.common_atk_counter = 1	
	end

	caster.last_common_atk_tick = now
	self:get_step_attack(caster)

	local detected_point = GameWorld.player():get_face_point(100)
	local casterX = caster:get_position().x
	local casterY = caster:get_position().y
	local targetX = casterX + detected_point.x
	local targetY = casterY + detected_point.y
	local targetlist = EntityManager:get_targetid_in_circle(targetX, targetY, 110)


	local tmp_pos = gameutils:get_point_by_dist(casterX, casterY, targetX, targetY, 25)
	caster:set_position(tmp_pos.x, tmp_pos.y)
	--caster:force_move(tmp_pos.x, tmp_pos.y)
	--caster:move(tmp_pos.x, tmp_pos.y) --向前移动一小步

    local attack_angle = gameutils:get_radian(casterX, casterY, targetX, targetY)

	for k,v in pairs(targetlist) do
		local ent = EntityManager:get_entity(v)
		if ent then
			print("ent.m_id", ent.m_id)
			ent:play_beattack_effect()
			ent:on_hit(1, 100)
			ent:hit_back(casterX, casterY, 25, attack_angle)
			PopDamageManager:play_damage(ent:get_position().x, ent:get_position().y + 120, 100)		
		end
	end	
end

function RoleAction:doRoll(caster)
	if caster:isAttacking() == true then
		return
	end	

	local detected_point = GameWorld.player():get_face_point(100)
	local casterX = caster:get_position().x
	local casterY = caster:get_position().y
	local targetX = casterX + detected_point.x
	local targetY = casterY + detected_point.y

	local tmp_pos = gameutils:get_point_by_dist(casterX, casterY, targetX, targetY, 350)
	caster:roll(tmp_pos.x, tmp_pos.y)	
end


--RoleAction:showDot()
