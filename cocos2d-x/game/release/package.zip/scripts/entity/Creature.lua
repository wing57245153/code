
--require "scripts/entity/Entity"
super_class.Creature(GameWorld.Entity)

function Creature:__init()
	
end



