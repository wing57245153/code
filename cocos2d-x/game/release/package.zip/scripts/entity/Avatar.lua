
require "scripts/entity/MobileCreature"
super_class.Avatar(MobileCreature)

function Avatar:__init()
	self.common_atk_counter = 1
	self.last_common_atk_tick = 0
	self.is_rolling = false	
end

function Avatar:roll(x, y)
	--self:set_state(action_config.STATE_ROLL)
	--self.m_speed = 500
	self.is_rolling = true
	self:force_move(x, y, 600)
end

function Avatar:isAttacking()
	return (self.m_isattacking == true) or (self.is_rolling == true)
end
