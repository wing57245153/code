
require "scripts/entity/MobileCreature"
super_class.Monster(MobileCreature)

AISTATE_PATROL = 0
AISTATE_CHASE = 1
AISTATE_ATTACKING = 2

function Monster:__init()
	self.m_last_update_tick = 0
	self.m_hitback_sleep = 0
	self.m_hasai = true --纯客户端怪物AI
	self.spawnpoint = {x = 0, y = 0}
end

--一些纯客户端ai的数据在这里初始化
function Monster:init_client_ai_data()
	if self.m_hasai == true then
		self.wait_counter = 0
		self.patrol_counter = 0
		self.chasing_counter = 0

		self.patrol_radius = 300
		self.chasing_radius = 1500 --追逐半径
		self.current_aistate = ai_state.AISTATE_PATROLING
		self.aiobj = AIFactory:get_ai_obj(self.ai)
		self:change_state(self.current_aistate)
	end
end

function Monster:change_state(newstate)
	if self.m_hasai == true then
		if self.aiobj ~= nil then
			self.aiobj:change_state(self, newstate)
		end
	end
end	

--技能模块受到击出发AI转换,由于客户端版只有一个玩家，所以不采用仇恨列表
function Monster:on_hit(id, hurt_value)
	if self.m_hasai == true then
		self:change_state(ai_state.AISTATE_CHASING)
	end
end



--客户端ai方面的

function Monster:on_enter_world()
	--random position for test only
	local x = math.random(800, 1000)
	local y = math.random(800, 1000)

	Monster.super.on_enter_world(self);
	self:set_model(GameWorld.model(self.model))
	self:update_animation()
	self:set_map_id(self.map_id)
	self:spawn(x, y)
	self:init_client_ai_data()
end

function Monster:on_leave_world()
	Monster.super.on_leave_world(self)
end

function Monster:spawn(x, y)
	self:set_position(x, y)
	self.spawnpoint.x = x
	self.spawnpoint.y = y
	self:set_state(action_config.STATE_STAND)
end



--采用某技能攻击
function MobileCreature:castSpell(spellid, target)
	self:stop()
	local test_cd = 3 --测试cd时间为3秒
	local now = GameWorld.game_time()
	local last_cast_time = self.cdtime[spellid]
	if last_cast_time == nil then
		self.cdtime[spellid] = 0
		last_cast_time = 0
	end
	if now - last_cast_time < test_cd then
		return
	end
	self.cdtime[spellid] = now

	self:face_target(target:get_position().x, target:get_position().y)	
	self:set_state(action_config.STATE_ATTACK)	
	
	--for test
	target:play_beattack_effect()
	PopDamageManager:play_damage(target:get_position().x, target:get_position().y + 120, 50)		
end

function Monster:is_close_player(dist)
	local value = false
	local mydist = gameutils.position_distance(self:get_position().x, self:get_position().y, 
				GameWorld.player():get_position().x, GameWorld.player():get_position().y)

	if (mydist < dist)then
		value = true
	end
	return value
end


function Monster:hit_back(fromx, fromy, dist, angle, ishitfly)
	if ishitfly == true then
		self:hit_fly(fromx, fromy, dist, angle)
	else
		Monster.super.hit_back(self, fromx, fromy, dist, angle);
	end
	--self:hit_fly(fromx, fromy, dist, angle)
	self.m_hitback_sleep = 80
end



function Monster:update()
	if self.aiobj ~= nil then
		self.aiobj:think(self)
	end
	--if true then return end;
	--if self.is_hitbacking ~= hitback_type.HIT_NONE then
	--	return
	--end

	--做击退僵直ai用
	--[[self.m_hitback_sleep = self.m_hitback_sleep  - 1
	if self.m_hitback_sleep > 0 then
		return
	end
	if self.m_hitback_sleep < -100000 then
		self.m_hitback_sleep = 0
	end]]

	--[[
	if self.ai == "simple" then
		self:doPatrol()
		return;
	end

	if self:is_close_player(500) == true then
		if self.m_ai_state == AISTATE_PATROL then
			self.m_driver:stop()
		end
		self:doChase()	
	else
		self.m_ai_state = AISTATE_PATROL
		self:doPatrol()
	end]]

end 

function Monster:set_map_id(oldvalue)

	--SpaceManager:on_player_change_map(oldvalue)
	
	-- mts = Model("testxx");

end