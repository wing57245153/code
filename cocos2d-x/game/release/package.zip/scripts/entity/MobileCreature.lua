

require "scripts/entity/Creature"
require "scripts/config/action_config"

super_class.MobileCreature(Creature)

DEFAULT_SPEED = 300

function MobileCreature:__init()
	--self.m_timer = timer();  --更新函数回调句柄
	self.m_speed = DEFAULT_SPEED
	self.m_state = action_config.STATE_STAND
	self.m_hp = 1000
	self.m_maxhp = 1000
	self.m_direction = 1
	self.m_fly_params = {}
	self.m_isattacking = false --正在播放攻击动作,不能被打断

    self.is_forcemove = false
	self.is_hitbacking = hitback_type.HIT_NONE;--击退中
	self.cdtime = {}--上一次释放技能的时间，用作cd控制
end

function MobileCreature:on_enter_world()
	MobileCreature.super.on_enter_world(self);
	--self.m_schedule_handler = scheduler:scheduleScriptFunc(self:update, 1, false); --可能存在效率问题，先记录
	-- local update = function( ... )
	-- 	self:update();
	-- end
	-- self.m_timer:start(1, update);
	self.m_driver = Driver(self);
end

function MobileCreature:on_leave_world()
	MobileCreature.super.on_leave_world(self);
	--if (self.m_schedule_handler!=nil) then
		--scheduler:unscheduleScriptEntry(self.m_schedule_handler);
	--self.m_timer:stop();
	--end
	self.m_driver:destroy();
end

function MobileCreature:stop()
	if self.m_driver ~= nil then
		self.m_driver:stop()
	end
end

function MobileCreature:get_speed()
	return self.m_speed
end

function MobileCreature:isAttacking()
	return (self.m_isattacking == true)
end


function MobileCreature:update()
	print("MobileCreature", "update", self);
end 

function MobileCreature:is_moving()
	return self.m_driver.m_moving
end

function MobileCreature:face_target(x, y)
	local dir = action_config.cal_direction(self:get_position().x, self:get_position().y, x, y);
	self:set_direction(dir)
end

function MobileCreature:set_position(x, y)
	MobileCreature.super.set_position(self, x, y);
end

function MobileCreature:attack_cb_fun()
	-- body
	if self.m_driver.m_moving == true then		
		self:set_state(action_config.STATE_WALK)
	else
		self:set_state(action_config.STATE_STAND)
	end
end

function MobileCreature:update_animation()
	if self.m_isattacking == true then
		return
	end

	function reset_stand()
		self.m_isattacking = false
		self:attack_cb_fun()
	end	
	local ani = action_config:get_action_by_state(self.m_state, self.m_direction);
	local play_once = false
	--if self.m_state == action_config.STATE_ATTACK then
	--attack动作只播放一次
	if string.sub(self.m_state, 1, 6) == "attack" then
		self.m_isattacking = true
		play_once = true
	end
	self:play_animation(ani, play_once, reset_stand);
end

function MobileCreature:get_direction()
	return self.m_direction
end

function MobileCreature:set_direction(dir)
	if (dir <=0 or dir==nil)then dir = 1 end;
	if (self.m_direction == dir) then
		return
	end
	self.m_direction = dir;
	self:update_animation();
	if (self.m_model)then
		local d = action_config.REVERSES[dir];
		self.m_model:set_mrror(d<0);
	end;
	--print("MobileCreature set_direction", dir);
end



function MobileCreature:set_state(state)
	if self.m_state == state then
		return
	end

	self.m_state = state
	self:update_animation()

end
--正在向x, y移动的回调
function MobileCreature:on_move_to(x, y)

end

--停止回调
function MobileCreature:on_stop()
end

--目前只针对playeravatar
function MobileCreature:force_move(x, y, speed)
	if speed ~= nil then
		self.m_speed = speed
	end
	self.is_forcemove = true
	self:move(x, y)
end

function MobileCreature:teleport(x, y)
	self:set_position(x, y)
	self:stop()	
end

function MobileCreature:move(x, y)
	self.m_driver:move_by_piexl_path({x,y});
	--local move = CCMoveTo:create(3, CCPoint(x, y));
	--self:get_real_sprite():runAction(move)
end



--播放受击特效
function MobileCreature:play_beattack_effect()
	if self.m_model then
		self.m_model:get_up_effect_slot():play("playeffect", true, math.random(1, 360), true)
	end
end

--发散方式击退
function MobileCreature:hit_backex(fromx, fromy, back_dist)
	self.m_speed = 1200
	self:face_target(fromx, fromy)
	self.is_hitbacking = hitback_type.HIT_BACK
	local dist  = gameutils.position_distance(fromx, fromy, self:get_position().x, self:get_position().y) --和攻击者距离
	local tmp_pos = gameutils:get_point_by_dist(fromx, fromy, self:get_position().x, self:get_position().y, dist + back_dist)
	self:move(tmp_pos.x, tmp_pos.y)	
end

--平行方式击退
function MobileCreature:hit_back(fromx, fromy, dist, angle)
	self:face_target(fromx, fromy)
	self.is_hitbacking = hitback_type.HIT_BACK
    local hit_backx = math.cos(angle) * dist + self:get_position().x
    local hit_backy = math.sin(angle) * dist + self:get_position().y
	self:move(hit_backx, hit_backy)
end

function MobileCreature:hit_fly(fromx, fromy, dist, angle)
	self:face_target(fromx, fromy)
	self.m_speed = 1000
	self.is_hitbacking = hitback_type.HIT_FLY
    local hit_backx = math.cos(angle) * dist + self:get_position().x
    local hit_backy = math.sin(angle) * dist + self:get_position().y	
    self.m_fly_params =  gameutils:calc_hit_fly_abc(self:get_position(), {x = hit_backx, y = hit_backy}, 180);
    self:move(hit_backx, hit_backy)
end

function MobileCreature:change_hp(value)
	self.m_hp = self.m_hp + value
	if self.m_hp >= self.m_maxhp then
		self.m_hp = self.m_maxhp
	end
end


super_class.Driver()

function Driver:__init(owner)
	self.m_owner = owner;
	self.m_path = nil;       --路径
	self.m_moving = false;
	self.sc_mindis = 5;

	self.m_last_time_check = 0;

	self.m_timer = timer();  --更新函数回调句柄
	local update = function( ... )
	 	self:update();
 	end
	self.m_timer:start(0, update);
end

function Driver:handle_playeravatar_update()
	if GameWorld.player():isAttacking() then
		return
	end

	local tp = JoyStick:getDirection()

	local dis = math.sqrt(tp.x * tp.x + tp.y * tp.y)
	if dis == 0 then
		self.m_owner:set_state(action_config.STATE_STAND)
		return
	end
	local tempv = (self.m_owner:get_speed()) / 60 / dis   --60帧
	local ndx = tempv * tp.x;
	local ndy = tempv * tp.y;

	local ndis = math.sqrt(ndx * ndx + ndy * ndy)

	local sx = self.m_owner:get_position().x
	local sy = self.m_owner:get_position().y

	local nextx = sx  + ndx
	local nexty = sy  + ndy

	local dir = action_config.cal_direction(0, 0, tp.x, tp.y)
	self.m_owner:set_direction(dir)
	self.m_owner:set_state(action_config.STATE_WALK)	
	self.m_owner:set_position(nextx, nexty)	
end

function Driver:update()
	--if JoyStick:isMoving() then
	if self.m_owner.m_entity_type == "PlayerAvatar" then
		if self.m_owner.is_forcemove == false then
			return self:handle_playeravatar_update()
		end
	end

	if (self.m_path == nil or #(self.m_path) < 2  or self.m_owner == nil)then
		return;
	end

	local sx = self.m_owner:get_position().x;
	local sy = self.m_owner:get_position().y;

	local nextx = self.m_path[1];
	local nexty = self.m_path[2];

	local dx = nextx - sx;
	local dy = nexty - sy;

	local dis = math.sqrt(dx*dx + dy*dy);

	if (dis < self.sc_mindis)then
		--table.remove(self.m_path,1);
		--table.remove(self.m_path,1);
		self.m_path = {}
		if (#(self.m_path) == 0) then
			self.m_owner:set_position(nextx, nexty);
			self:stop();
			return;
		end

		nextx = self.m_path[1];
		nexty = self.m_path[2];

		dx = nextx - sx;
		dy = nexty - sy;
		dis = math.sqrt(dx * dx + dy * dy);
		local dir = action_config.cal_direction(sx, sy, nextx, nexty);
		self.m_owner:set_direction(dir);
		--print("Driver set_direction");
	end

	local gt = GameWorld.game_time();
	local dtime = gt - self.m_last_time_check;
	if (dis == 0 or dtime < 0)then return end;
	self.m_last_time_check = gt;

	local tempv;
	-- if (dtime > 100) then
	-- 	tempv = (self.m_owner.m_speed) * dtime / dis * 0.001; --为了解决最小化的时候停帧的问题
	-- else 
		tempv = (self.m_owner:get_speed()) / 60 / dis;   --60帧
	--end
	
	local ndx = tempv * dx;
	local ndy = tempv * dy;
	
	--ndx = math.ceil(ndx);
	--ndy = math.ceil(ndy);
	
	local ndis = math.sqrt(ndx * ndx + ndy * ndy)
	
	if (ndis > dis)then	
		ndx = dx;
		ndy = dy;
	end

	--抛物线 begin
	if self.m_owner.is_hitbacking == hitback_type.HIT_FLY then
		local y = gameutils:get_hit_flyY(self.m_owner.m_fly_params, self.m_owner:get_position().x);
		self.m_owner:set_position(sx + ndx, y);
		return
	end	
	--抛物线 end
	
	self.m_owner:set_position(sx  + ndx, sy  + ndy);
	self.m_owner:on_move_to(sx  + ndx, sy  + ndy)
	--print("Driver set_position", sx, ndx, sy, ndy);
end 

function Driver:stop()
	self.m_path = nil;
	--if (self.m_owner) then
	--	self.m_owner:set_state(action_config.STATE_STAND);
	--end
	self.m_owner.m_speed = DEFAULT_SPEED
	if (self.m_owner) then
		self.m_owner.is_hitbacking = hitback_type.HIT_NONE --回复

		if self.m_owner.m_entity_type == "PlayerAvatar" then
			self.m_owner.is_rolling = false	--回复
		end		

		if self.m_owner.is_forcemove == true then --处理玩家冲撞类归位，不知道为什么设置两次set_state(STATE_STAND)有问题
			self.m_owner.is_forcemove = false
		else
			self.m_owner:set_state(action_config.STATE_STAND);
		end
		self.m_owner:on_stop()
	end	
	self.m_moving = false;
end

function Driver:move_by_piexl_path(path)
	if ((path==nil) or (#path == 0))then 
		print("Driver move_by_piexl_path1", #path );
		return 
	end;
	
	if (self.m_path and #(self.m_path)>0)then
		local x = self.m_path[1];
		local y = self.m_path[2];
		for i=0, (#path)/2 do 
			if ((x == path[i * 2]) or (y == path[i * 2 + 1]))then
				--path = path.slice(i * 2);
				for j=0, i do
					table.remove(path, j * 2);
					table.remove(path, j * 2 + 1);
				end
				break;
			end
			if ( i >= 5)then break end;
		end
	end
	
	if (#path > 2)then
		if (gameutils.position_distance(self.m_owner:get_position().x, 
				self.m_owner:get_position().y, path[1], path[2]) < 25)then
			table.remove(path, 1);
			table.remove(path, 2);
		end
	end
	
	if (#path >= 2) then
		local dir = action_config.cal_direction(self.m_owner:get_position().x, 
				self.m_owner:get_position().y, path[1], path[2]);
		--self.m_owner:set_state(action_config.STATE_WALK);
		--self.m_owner:set_direction(dir);
		if self.m_owner.is_forcemove == true then
			local f_state = action_config.STATE_ATTACK1
			if self.m_owner.is_rolling == true then
				f_state = action_config.STATE_ROLL
			end
			self.m_owner:set_state(f_state);
		else
			if self.m_owner.is_hitbacking == hitback_type.HIT_BACK then
				self.m_owner:set_state(action_config.STATE_BEATTACKED);
			else
				if self.m_owner.is_hitbacking == hitback_type.HIT_FLY then
					self.m_owner:set_state(action_config.STATE_DIE);	
				else
					self.m_owner:set_state(action_config.STATE_WALK);
				end
			end
		end
		--self.m_owner:set_state(action_config.STATE_WALK);
		if self.m_owner.is_hitbacking == hitback_type.HIT_NONE then --击退过程中不改朝向
			self.m_owner:set_direction(dir);
		end		
		self.m_moving = true;
	end
	self.m_last_time_check = GameWorld.game_time();
	self.m_path = path;
end

function destroy()
	self.m_owner = nil;
	self.m_timer:stop();
end