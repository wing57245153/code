
require "scripts/entity/Avatar"


super_class.PlayerAvatar(Avatar)

local function testmonster()
	local att = {}
	att.map_id = 2
	att.model = "testyy"
	att.ai = ai_config.AITYPE_ADVANCE
	--local ent = GameWorld.create_entity("Monster", att)
	for i = 1, 1 do
		att.model = "testxy"
		att.ai = ai_config.AITYPE_ADVANCE
		GameWorld.create_entity("Monster", att)	
	end
	AudioManager:playBackgroundMusic("sounds/background.mp3", true)
end

local function getZOrder(posY)  
	local visibleSize = CCDirector:getInstance():getVisibleSize()  
	local y = visibleSize.height - posY;  
	return y;  
end 

function PlayerAvatar:__init()
	--PlayerAvatar.super.__init(self);
	self.attack_step = 1
	self.m_timer = timer();
	local update = function( ... )--只做排序？
	 	self:think();
 	end
	self.m_timer:start(0, update);	
	self.m_nextx = 0
	self.m_nexty = 0
	self.career = 1	--1战士，2法师，3弓手

end


function PlayerAvatar:on_enter_world()
	PlayerAvatar.super.on_enter_world(self);
	self:set_model(GameWorld.model("effect4"))
	--self:play_animation("walk_rightdown");
	self:update_animation()
	self:set_map_id(self.map_id)

	
	testmonster()
end

function PlayerAvatar:on_leave_world()
	PlayerAvatar.super.on_leave_world(self);
end



function PlayerAvatar:attack_cb_fun()
	PlayerAvatar.super.attack_cb_fun(self)
end


function PlayerAvatar:think()
	local sprite = self.m_model.m_real_sprite
	local x, y = sprite:getPosition();  
	LayerManager:get_layer_model():reorderChild(sprite, getZOrder(y) );  

end

function PlayerAvatar:on_move_to(x, y)

end

function PlayerAvatar:on_stop()
	PlayerAvatar.super.on_stop(self)
end

--获得朝向距离
function  PlayerAvatar:get_face_point(dist)
	if dist == nil then
		dist = 100
	end
	local tp = JoyStick:getDirection()
	local dirX = tp.x
	local dirY = tp.y
	--if self:is_moving() == false then --非移动状态，取面向的点
	if JoyStick:isMoving() == false then
		dirX, dirY = action_config.get_xy_by_direction(self:get_direction())
	end

	local detected_point = gameutils:get_point_by_dist(0, 0, dirX, dirY, dist)
	return detected_point
end




function PlayerAvatar:set_map_id(oldvalue)

	SpaceManager:on_player_change_map(oldvalue)
	
	-- mts = Model("testxx");

end