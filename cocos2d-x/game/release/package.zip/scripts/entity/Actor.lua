
-- require "scripts/entity/Entity"
-- super_class.Actor(Entity)

-- function Actor:__init()
-- 	self.m_model = nil;
-- end

-- function Actor:on_enter_World()
-- 	self.super.on_enter_World(self);
-- end

-- function Actor:on_leave_world()
-- 	self.super.on_leave_world(self);
-- end

-- function Actor:set_model(model)
-- 	if (self.m_model~=nil) then
-- 		self.m_model:destroy();
-- 	end
-- 	self.m_model = model;
-- 	self.m_model:set_parent(nil);
-- end

-- function Actor:set_position(x,y)
-- 	self.super.set_position(self,x,y);
-- 	if (self.m_model) then
-- 		self.set_position(x,y);
-- 	end
-- end