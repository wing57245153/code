-- 场景管理器，用于切换玩家场景
PlayerActionManager = {};

-- 记录当前动作
local _current_action = nil
-- 记录下一个动作
local _next_action = ZX_ACTION_IDLE
-- 等待动作队列
local _waiting_queue = {}
-- 后续的动作队列
local _continue_queue = {}

-- 获取动作序列的最高优先级别
local function get_action_queue_priority( queue )
	local max = ActionConfig.PRIORITY_NONE
	for k,action in pairs(queue) do
		max = math.max(max, action.priority)
	end
	return max
end

function PlayerActionManager:init()    --单例初始化方法
	local update = function( ... )
		PlayerActionManager:update()
	end

	self.timer = timer();
	self.timer:start(0,update);
end


function PlayerActionManager:update()
	
	if (GameWorld.player() == nil) then return end;
	
	if _current_action == nil then
		_current_action = self:get_next_action()
	end

	if _current_action ~= nil then
		
		local result = _current_action:do_action()
		if result == ActionConfig.ACTION_DOING then
			return
		elseif result == ActionConfig.ACTION_FAIL then
			self:clean_waiting_queue()
            _current_action = nil
        elseif result == ActionConfig.ACTION_END then
        	_current_action = nil
        else
        	print("不应该到这里", result, _current_action)
        end
    else
    	
	end
end

-- 添加动作队列
function PlayerActionManager:add_action_queue( queue )

	-- 跟当前动作相比，如果新的动作队列优先级较高，则顶掉当前队列
	if _current_action ~= nil then
		local new_queue_priority = get_action_queue_priority(queue)
		local current_priority 	= _current_action.priority
		if current_priority < new_queue_priority then
			_current_action:stop_action()
			_current_action = nil
		-- 如果优先级别相同，而当前动作可以被打断，则打断
		elseif current_priority == new_queue_priority and _current_action.can_break then
			--print("打断当前动作..........")
			_current_action:stop_action()
			_current_action = nil
		end
	end

	-- 添加进入等待队列
	self:set_waiting_queue(queue)
end


-- 设置等待队列
function PlayerActionManager:set_waiting_queue( queue )
	_waiting_queue = queue
end

-- 清除队列
function PlayerActionManager:clean_waiting_queue(  )
	_waiting_queue = {}
end

-- 获取下一个动作
function PlayerActionManager:get_next_action(  )
	if _waiting_queue ~= nil then
		local ret = table.remove(_waiting_queue, 1)
		return ret;
	end
	return nil
end

-- 停止全部动作
function PlayerActionManager:stop_all_action(  )
	self:stop_curr_action()
	_waiting_queue  = {}
end

-- 停止当前动作
function PlayerActionManager:stop_curr_action()
	if _current_action ~= nil then
		_current_action:stop_action()
	end
	_current_action = nil;
end

PlayerActionManager:init() 
