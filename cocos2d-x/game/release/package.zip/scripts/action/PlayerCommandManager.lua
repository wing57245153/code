-- 主角指令集管理器

super_class.PlayerCommandManager()

-- 普通移动
function PlayerCommandManager:move(tx, ty, after_moved_action_cb)

	local queue = {}
	local action = ActionMove{tx = tx, ty = ty, player = GameWorld.player()}
	table.insert(queue, action)
	if after_moved_action_cb ~= nil then
		table.insert(queue, ActionCallBack(after_moved_action_cb));
	end
	PlayerActionManager:add_action_queue(queue)
	
end
