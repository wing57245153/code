-- 用于主角做完action后的callback

super_class.ActionCallBack(ActionBase)

function ActionCallBack:__init( cb )
	self.cb = cb
end


function ActionCallBack:do_action(  )
	self:end_action()
	return self.state;
end

function ActionCallBack:_on_end(  )
	self.cb();
end

function ActionCallBack:_on_fail(  )

end
