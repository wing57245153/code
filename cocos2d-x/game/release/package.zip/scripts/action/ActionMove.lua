
-- 主角移动行为类
-- 这个移动类包含的A*算法和直线修正算法
-- 它将派生出ActionAppoarch和ActionAppoarchStatic类

-- require "action/ActionBase"
-- require "action/ActionConfig"

-- 普通移动
super_class.ActionMove(ActionBase)


----------------------------------------------

-- 普通移动将会存在2个参数
-- @tx 要到达的世界坐标的横坐标
-- @ty 要到达的世界坐标的纵坐标
function ActionMove:__init( args )
	self.priority 	= ActionConfig.PRIORITY_ONE
	self.can_break	= true
	self.tx = args.tx
	self.ty = args.ty
	self.player = args.player;
end

-- 执行这个行为
function ActionMove:do_action(  )

	local ppos = self.player:get_position()
	if (gameutils.position_distance(self.tx, self.ty, ppos.x, ppos.y)<=5)then
		self:end_action();
	end
	
	return  ActionMove.super.do_action(self)
end

-- 以下函数由子类实现，不应手动调用
-- 判断条件
function ActionMove:can_do(  )
	return true
end


-- 在行为将要开始前被调用
function ActionMove:_on_start(  )
	self.player:move(self.tx, self.ty);
end

-- 在行为失败时被调用
function ActionMove:_on_fail(  )
	
end

-- 在行为正常结束时被调用
function ActionMove:_on_end(  )
	
end