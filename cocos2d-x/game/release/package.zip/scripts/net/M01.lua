require "scripts/core/BasicMessage"


super_class.M01()


function M01:__init()
	super_class.M0100(BasicMessage)
	self.M0100 = M0100()
	self.M0100.mainevent = "M01"
	self.M0100.subevent = "00"
	function M0100:read( byteArray )
		local data = {"Result", "AccId" }
		data["name"] = "data"
		byteArray:readByType(data,self)
		self:updateData()
	end
	function M0100:write( data )
		local attrTable = {"AccName", "ID" }
		local bytes = ByteArray()
		bytes:writeByType(data, attrTable)
		self:sendData(bytes)
	end


	super_class.M0101(BasicMessage)
	self.M0101 = M0101()
	self.M0101.mainevent = "M01"
	self.M0101.subevent = "01"
	function M0101:read( byteArray )
		local RoleList = {{"RoleId", "RoleName", "RoleCareer", "RoleSex", "RoleLv" }}
		RoleList["name"] = "RoleList"
		local data = {RoleList }
		data["name"] = "data"
		byteArray:readByType(data,self)
		self:updateData()
	end
	function M0101:write( data )
		local attrTable = {}
		local bytes = ByteArray()
		bytes:writeByType(data, attrTable)
		self:sendData(bytes)
	end


	super_class.M0102(BasicMessage)
	self.M0102 = M0102()
	self.M0102.mainevent = "M01"
	self.M0102.subevent = "02"
	function M0102:read( byteArray )
		local data = {"Result", "RoleId", "RoleName", "RoleCareer", "RoleSex" }
		data["name"] = "data"
		byteArray:readByType(data,self)
		self:updateData()
	end
	function M0102:write( data )
		local attrTable = {"RoleId", "RoleName", "RoleCareer", "RoleSex" }
		local bytes = ByteArray()
		bytes:writeByType(data, attrTable)
		self:sendData(bytes)
	end


	super_class.M0103(BasicMessage)
	self.M0103 = M0103()
	self.M0103.mainevent = "M01"
	self.M0103.subevent = "03"
	function M0103:read( byteArray )
		local AttrList = {{"key", "val" }}
		AttrList["name"] = "AttrList"
		local data = {"Result", AttrList }
		data["name"] = "data"
		byteArray:readByType(data,self)
		self:updateData()
	end
	function M0103:write( data )
		local attrTable = {"RoleId" }
		local bytes = ByteArray()
		bytes:writeByType(data, attrTable)
		self:sendData(bytes)
	end


end
