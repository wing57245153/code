----------net 
require "scripts/core/BasicMessage"
require "scripts/utils/Utils"

super_class.M10()

function M10:__init()

    super_class.M1000(BasicMessage)
	self.M1000 = M1000()
	self.M1000.mainevent = "M10"
	self.M1000.subevent = "00"

    function M1000:read( byteArray )
        local nameList = {{"x","y"}}
        nameList["name"] = "nameList"
        local pointList = {{"x", "y", "z", nameList}}
        pointList["name"] = "pointList"
        local data = {"x","y","count",pointList}
        data["name"] = "data"
        byteArray:readByType(data,self)
        --self.numList = byteArray:readByType({"x","y","z", ["pList"]={"x","y","z"}})
        self:updateData()

        print(self.data.pointList[1].nameList[1].x, table.getn(self.data.pointList))

        --print("numList", self.numList[1].x, self.numList["pList"][1].x)
    end

    function M1000:write( data )
        local testData = {}
        testData["x"] = 2
        testData["y"] = 3
        testData["z"] = 4
        testData["pointList"] = {{["x"] = 1, ["y"] = 2, ["z"] = 3, ["nameList"] = {{["x"] = 1, ["y"] = 2},{["x"] = 1, ["y"] = 2}}}
                           ,{["x"] = 2,["y"] = 3,["z"] = 4, ["nameList"] = {{["x"] = 1, ["y"] = 2},{["x"] = 1, ["y"] = 2}}}}
        local artTable = {"x#2","y#1","z#1", "pointList#52"}
        local pointList = {"x#1", "y#1", "z#1", "nameList#52"}
        artTable["pointList"] = pointList
        local nameList = {"x#1", "y#1"}
        pointList["nameList"] = nameList

        local bytes = ByteArray()
        bytes:writeByType(testData, artTable)

        --[[
        bytes:writeByte(52)
        bytes:writeShort(2)
        bytes:writeByte(52)
        bytes:writeShort(2)
        bytes:writeByte(1)
        bytes:writeByte(1)
        bytes:writeByte(1)
        bytes:writeByte(2)
        bytes:writeByte(1)
        bytes:writeByte(3)
        bytes:writeByte(52)
        bytes:writeShort(2)
        bytes:writeByte(1)
        bytes:writeByte(3)
        bytes:writeByte(1)
        bytes:writeByte(4)
        bytes:writeByte(1)
        bytes:writeByte(5)
        --]]

        self:sendData(bytes)
    end
end
