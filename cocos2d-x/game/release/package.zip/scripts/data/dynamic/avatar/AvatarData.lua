require "scripts/core/BasicData"
require "scripts/core/AppEvent" 

super_class.AvatarData(BasicData)

function AvatarData:__init()
    self.mainevent = DATA_UPDATE_EVENT
    self.subevent = DATA_AVATAR__EVENT
end

-----s -> c
function AvatarData:read( byteArray )
    self.name = "woko"
    self.sex = 1
    self.count = byteArray:readInt()

    self:updateData()
end


------c ---> s
function AvatarData:write( data )
    local bytes = ByteArray()
    bytes:writeInt(data.count)

    self:sendData(bytes)
end