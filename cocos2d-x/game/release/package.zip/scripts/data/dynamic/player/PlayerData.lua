-----玩家的游戏相关数据----
---玩家属性列表等数据
----- 将数据池里面的数据进行组装
---提供相应的接口
--require "scripts/core/GameWorld" 

PlayerData = {}

function PlayerData:getPlayerAttrList()

    self.playerAttrList = GameWorld.dataPool():getPlayerAttrList()

    return self.playerAttrList
end

-----通过Key；来获取玩家具体是属性值
function PlayerData:getPlayerAttrByKey( key )
	self.playerAttrList = self:getPlayerAttrList()
	local result = nil
	if self.playerAttrList ~= nil then
        result = self.playerAttrList[key]
	end
	return result
end