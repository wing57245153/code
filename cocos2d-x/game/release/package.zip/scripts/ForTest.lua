----------------------------------------------------------------
----------------- 测试程序 -------------------------------------
----------------------------------------------------------------

require "scripts/core/Layer"
require "scripts/UI/ComponentUtil"


ForTest = { }

local menu = CCMenu:create()
local scale9 = nil
local bag = nil
local function clickCallback(sender)
	print("Click SimpleButton", sender)
	GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "BagModule")
	scale9:setContentSize(CCSize(400,300))
end

local function clickCallback1(sender)
	print("Click SimpleButton1", sender)
	--bag:close()
	--scale9:setPosition(210, 210)
	--scale9:setContentSize(CCSize(400, 550))
end

local function testSimpleButton()
    local buttonCon = ComponentUtil:CreateSimpleButton("simpleButton2")
    buttonCon:setTouchClickFun(clickCallback)
    buttonCon:setPosition(300,200)
    --LayerManager:get_layer_ui():addChild(buttonCon.view)
    menu:addChild(buttonCon.view)
end

local function testSimpleButton1()
    local buttonCon = ComponentUtil:CreateSimpleButton("simpleButton1")
    buttonCon:setTouchClickFun(clickCallback1)
    buttonCon:setPosition(420,200)
    menu:addChild(buttonCon.view)
	--LayerManager:get_layer_ui():addChild(buttonCon.view)
end

local function testScale9Sprite()
	scale9 = ComponentUtil:CreateScale9Sprite("background1", CCSize(150, 200), CCRect(50,30,238,398))
	scale9:setPosition(300,200)
	scale9:setContentSize(CCSize(500,200))
	LayerManager:get_layer_ui():addChild(scale9.view)
end

local function testLabelTTF()
	local labelTTF = ComponentUtil:CreateLabelTTF("一二三四五六七fuck", "Consolas", 32, Color3B(255, 255, 255), CCSize(150, 30))
	labelTTF:setPosition(250, 150)
	LayerManager:get_layer_ui():addChild(labelTTF.view)
end

local function testButton()
	local function onShowBagWindow()
		--GameWorld.gameSocket():send()
		--GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "BagModule")
		GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "AvatarModule")
	end

	local button = ComponentUtil:CreateButton("背包", "simpleButton1")
	require "scripts/utils/LayoutRect"
	
	local rect = LayoutRect()
	button:setAnchorPoint(CCPoint(1, 0.5));
	button:setPosition(rect:right())
	
	--local anchorPoint = button:getAnchorPoint()
	--print("anchorPoint.x =", anchorPoint.x, "anchorPoint.y =", anchorPoint.y)

	--button:setPreferredSize(CCSize(100, 80))
	--anchorPoint = button:getAnchorPoint()
	--print("anchorPoint.x =", anchorPoint.x, "anchorPoint.y =", anchorPoint.y)

	button:registerControlEventHandler(onShowBagWindow, CCControlEventTouchDown)
	LayerManager:get_layer_ui():addChild(button)
end

local function testProgressBar()
    local progressBar = ComponentUtil:CreateProgressBar("progressbar1")
    progressBar:setPosition(300,200)
    progressBar:setMinimumValue(0)
    progressBar:setMaximumValue(2000)
    progressBar:setValue(1520)
    LayerManager:get_layer_ui():addChild(progressBar.view)
end

local function testVisibleRect()
	require "scripts/utils/VisibleRect"
	local rect = VisibleRect:getVisibleRect()
	print("VisibleRect :: ", "x =", rect.x, "y =", rect.y, "w =", rect.width, "h =", rect.height)

	local left = VisibleRect:left()
	print("VisibleRect Left:: ", "x =", left.x, "y =", left.y)

	local leftBottom = VisibleRect:leftBottom()
	print("VisibleRect leftBottom:: ", "x =", leftBottom.x, "y =", leftBottom.y)

	local leftTop = VisibleRect:leftTop()
	print("VisibleRect leftTop:: ", "x =", leftTop.x, "y =", leftTop.y)

	local right = VisibleRect:right()
	print("VisibleRect right:: ", "x =", right.x, "y =", right.y)

	local rightBottom = VisibleRect:rightBottom()
	print("VisibleRect rightBottom:: ", "x =", rightBottom.x, "y =", rightBottom.y)

	local rightTop = VisibleRect:rightTop()
	print("VisibleRect rightTop:: ", "x =", rightTop.x, "y =", rightTop.y)
end

local function testVisibleSize()
	--local winSize = CCDirector:getInstance():getWinSize()
	--local frameSize = 
	-- local pEGLView = CCEGLView:getInstance();
    --    self.s_visibleRect.origin = pEGLView:getVisibleOrigin();
    --    self.s_visibleRect.size = pEGLView:getVisibleSize();
    require "scripts/utils/LayoutRect"
    local rect = LayoutRect(CCPoint(0, 0))
    rect:left()
    rect:leftBottom()
    rect:leftTop()
    rect:bottom()
    rect:center()
    rect:top()
    rect:rightBottom()
    rect:right()
    rect:rightTop()
end

local function testPageTurning()
	local currentPage = CCLayer:create()
	currentPage:addChild(CCSprite:create("images/userminimap/user_minimap_bg.png"))
	local preparativePage = CCSprite:create("images/userminimap/user_minimap_map.png")
	local pageTurning = ComponentUtil:CreatePageTurning(currentPage, preparativePage, totalPageNum)
	LayerManager:get_layer_ui():addChild(pageTurning.view)
	pageTurning.view:setPosition(600, 300)
	print ("Loading Success: TableView", currentPage, pageTurning.view)
end

function ForTest:test()
	LayerManager:get_layer_ui():addChild(menu)
	testScale9Sprite()
	--testSimpleButton()
	--testSimpleButton1()
	--testLabelTTF()
	testButton()
	--testProgressBar()
	--testVisibleSize()
	--testPageTurning()
end