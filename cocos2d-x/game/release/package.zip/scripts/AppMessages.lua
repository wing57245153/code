AppMessages = {}

--程序退出，需要做回收操作
--通知脚本退出，需要对retain的CCObject做回收操作
function AppMessages:OnQuit(...)
	--析构Login窗口
	RoleModel:destroy_login_win()
	--删除UI管理器
	UIManager:OnQuit()
	--检查释放
	CheckWindowRelease();
end

--[[
function AppMessages:OnStart(...)

end	
]]--

--开始更新
function AppMessages:OnUpdateBegin(...)

end

--更新中
function AppMessages:OnUpdateProgress(...)

end

--结束更新
function AppMessages:OnUpdateEnd(...)

end

--进入后端
function AppMessages:OnEnterBackground(...)

end

--进入前端
function AppMessages:OnEnterForeground(...)

end


function AppMessages.OnRemoteDebugger( sz )
    print('>',sz)
 	local isGM = string.match(sz,'^@')
 	if isGM and ChatCC then
    	ChatCC:send_chat(6, 0, sz)
	else
		loadstring(sz)()
	end
end

-- 第一次加载一个模块，开始加载前
function AppMessages:before_require( name )
	-- body
end

-- 第一次加载一个模块，完成加载后
function AppMessages:after_require( name )
	-- print("requrie", name)
end

-- 重新加载一个模块
function AppMessages:reload_module( name )
	-- body
end

-- 断开连接
function AppMessages:close_connect_message(  )
	CCMessageBox('connect fail!', 'connect fail!')
end