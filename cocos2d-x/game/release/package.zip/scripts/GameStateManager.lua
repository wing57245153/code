-- GameStateManager.lua
-- created by aXing on 2012-11-14
-- 这是一个管理游戏状态的类
-- 用于定义以及处理各种游戏状态间的转换过程，包括构造以及析构
GameStateManager = {}


-- 玩家心跳计数，判断是否已经断开连接。每次收到服务器心跳包，把该值设置为0，当超过一定值，就判断为断开连接
local _connect_check_count = 0
local _connect_check_max   = 70   -- 用来判断的是秒心跳

---- 私有函数
-- 游戏更新状态
local function update_enter(  )
	
end

local function update_leave(  )
	
end

-- 登陆状态
local function login_enter()
	-- UIManager:show_window("login")
	GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "LoginModule")
end

local function login_leave()
	-- UIManager:destroy_window("login")
	GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_DESTROY_WINDOW, "LoginModule")
end

-- 游戏初始化模块
local function loading_enter(  )
	-- 先打开主游戏初始化模块界面
	ResourceManager:init_game()
end

local function loading_leave(  )
	SceneLoadingWin:destroy_instance()
end

-- 选择角色
local function choose_enter()
	-- -- 打开角色列表
	GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_SHOW_WINDOW, "RoleListModule")
end

local function choose_leave()
    GameWorld.gameBus():dispatchEvent(MODULE_EVENT, MODULE_DESTROY_WINDOW, "RoleListModule")
end

-- 游戏场景
local function scene_enter()
    GameWorld.gameBus():dispatchEvent(GAME_EVENT, GAME_ENTER_EVENT, "enter_game")
	-- 以下的初始化顺序是根据节点生成次序定义的，不能修改
	-- 先渲染场景，然后渲染实体，最后渲染UI
	--local root = GameStateManager:get_game_root()

	-- 初始化UI节点模块
	--UIManager:init(root)				-- 初始化UI
	-- 初始化场景节点模块
	--require "scripts/scene/SceneManager"
	--SceneManager:init(root)				-- 初始化场景系统
	-- 初始化场景实体节点模块
	--require "scripts/entity/EntityManager"
	--EntityManager:init(root)			-- 初始化游戏实体
	
	-- 进入游戏场景才初始化AI
	--require "scripts/AI/AIManager"
	--AIManager:init()

	-- 开始游戏心跳
	--GameStateManager:start_game_tick()

end 

local function scene_leave()

end 

-- 战斗场景
local function combat_enter(  )
	
end

local function combat_leave(  )

end

---- 私有成员
local _current_state = nil		-- 当前的游戏状态

local GAME_STATE = {
	update  = {enter = update_enter, 	leave = udpate_leave	},		-- 在线更新状态
	loading = {enter = loading_enter, 	leave = loading_leave	},		-- 初始化游戏模块
	login 	= {enter = login_enter,  	leave = login_leave		},		-- 登陆状态
	choose 	= {enter = choose_enter,	leave = choose_leave	},		-- 选择角色
	scene 	= {enter = scene_enter,  	leave = scene_leave		},		-- 游戏场景
	combat	= {enter = combat_enter,	leave = combat_leave	},		-- 战斗场景
}

-- 整个游戏的根节点
local _game_root = nil			
-- 客户端生存周期，运行了多少秒
local _game_total_seconds = 0;
-- 客户端生存周期，运行了多少毫秒
local _game_total_millisecond = 0;


---- 公有函数
-- 游戏初始化
function GameStateManager:init(root)
	_game_root = root
end

-- 获取整个游戏的根节点
function GameStateManager:get_game_root(  )
	return _game_root
end

-- 切换不同的游戏状态
-- state 只能是 "login", "choose", "scene", ...
function GameStateManager:set_state(state)
--	print("run game state manager ",state)
	if GAME_STATE[state] == nil then
		print("GameStateManager has not this state:", state)
		return false
	end

	-- 如果存在上个状态，则需要调用上个状态的析构
	if _current_state ~= nil then
		GAME_STATE[_current_state].leave()
		_current_state = nil
	end
--	print("run state enter")
	_current_state = state
	GAME_STATE[state].enter()
	return true
end

-- 获取当前游戏状态
function GameStateManager:get_state()
	return _current_state
end

-- 开始游戏心跳
function GameStateManager:start_game_tick(  )

	if self.gameticktimer ~= nil then
		return
	end

	-- 注册游戏每帧的心跳
	-- 游戏每帧心跳
	local function tick( dt )
		_game_total_millisecond = _game_total_millisecond + dt
		-- 检查是否需要gc
		ResourceManager:garbage_collection()
		if _game_total_millisecond - _game_total_seconds >= 1 then
			GameStateManager:second_tick()
		end
	end
	self.gameticktimer = timer()
	self.gameticktimer:start(t_gsm_,tick)
end

-- 停止游戏心跳
function GameStateManager:stop_game_tick(  )
	if self.gameticktimer ~= nil then
		self.gameticktimer:stop()
	end
end

-- 获取客户端一开始到现在已经过去了多少秒
function GameStateManager:get_total_seconds(  )
	return _game_total_seconds
end

-- 获取客户端一开始到现在已经过去了多少毫秒
function GameStateManager:get_total_milliseconds(  )
	return _game_total_millisecond * 1000
end

-- 游戏每秒心跳
function GameStateManager:second_tick(  )
	
	_game_total_seconds = _game_total_seconds + 1;

	GameStateManager:connect_check(  )

	-- 这里以后只会用于逻辑计数上面的心跳
	-- 每个界面上面的特效应有每个界面负责tick，并处理界面关闭时把tick关掉

end

-- 连接检查
function GameStateManager:connect_check(  )
	-- 连接检查计数
	_connect_check_count = _connect_check_count + 1
	
    if _connect_check_count > _connect_check_max then
    	print("连接已经断开！！！！")
        AppMessages:close_connect_message(  )
        GameStateManager:stop_game_tick(  )
    end
end

-- 重置 连接检查计数
function GameStateManager:reset_connect_check_count(  )
	_connect_check_count = 0
end
