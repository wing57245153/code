super_class.AIBase()
ai_config = {}

ai_config.AITYPE_SIMPLE = 1		--普通版
ai_config.AITYPE_ADVANCE = 2	--高级版

ai_state = {}

ai_state.AISTATE_WATING = 1			--站立
ai_state.AISTATE_PATROLING = 2		--巡逻
ai_state.AISTATE_FLEEING = 3		--逃跑
ai_state.AISTATE_CHASING = 4		--战斗
ai_state.AISTATE_DEAD = 5			--死亡


function AIBase:__init()
	self.m_aitype = 0
	self.m_fsmlist = {}
end

function AIBase:regist_aifsm(aistate, fsm)
	self.m_fsmlist[aistate] = fsm
end

function AIBase:change_state(monster, newstate)
	if newstate == monster.current_aistate then
		return
	end
	local fsm = self.m_fsmlist[newstate]
	if fsm ~= nil then
		fsm:exit(monster)
		monster.current_aistate = newstate
		fsm:enter(monster)
		fsm:think(monster)
	end
end

function AIBase:think(monster)
	local fsm = self.m_fsmlist[monster.current_aistate]
	if fsm ~= nil then
		fsm:think(monster)
	end
end

function AIBase:on_start_seeing(monster, target)
end

function AIBase:on_stop_seeing(monster, target)
end
