
--普通怪物ai这里扩展

super_class.AIFsmChasingMonsterSimple(AIFsmBase)

function AIFsmChasingMonsterSimple:__init()

end

function AIFsmChasingMonsterSimple:enter(monster)
end

function AIFsmChasingMonsterSimple:exit(monster)
end

function AIFsmChasingMonsterSimple:think(monster)
	print("now is chasing")
end