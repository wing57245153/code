require "scripts/AI/AIBase"
require "scripts/AI/AIMonsterSimple"
require "scripts/AI/AIMonsterAdvanced"
require "scripts/AI/AIFsmBase"
require "scripts/AI/AIFsmMonsterSimple"
require "scripts/AI/AIFsmMonsterAdvanced"

AIFactory = {}
--这里是AI工厂

function AIFactory:init()
	--初始化用到的状态机对象
	self.aifsm_waiting = AIFsmWaiting()	--通用waiting
	self.aifsm_dead = AIFsmDead()		--通用死亡，特殊死亡处理请继承覆盖
	self.aifsm_patrol = AIFsmPatrol()	--通用随机巡逻
	self.aifsm_chasing_monster_simple = AIFsmChasingMonsterSimple()   --普通怪物战斗追逐
	self.aifsm_chasing_monster_advanced = AIFsmChasingMonsterAdvanced()  --高级怪物战斗追逐

	--初始化各种AI
	self.ai_monster_simple = AIMonsterSimple()
	self.ai_monster_advanced = AIMonsterAdvanced()
end

function AIFactory:get_ai_obj(type)
	local d = 	{
					[ai_config.AITYPE_SIMPLE] = self.ai_monster_simple,
					[ai_config.AITYPE_ADVANCE] = self.ai_monster_advanced
				}
	return d[type]

end

AIFactory:init()