
--高级怪物ai扩展这里
super_class.AIFsmChasingMonsterAdvanced(AIFsmBase)

function AIFsmChasingMonsterAdvanced:__init()

end

function AIFsmChasingMonsterAdvanced:enter(monster)
	monster.chasing_counter = 0
end

function AIFsmChasingMonsterAdvanced:exit(monster)
	monster.chasing_counter = 0
end

function AIFsmChasingMonsterAdvanced:think(monster)
	monster.chasing_counter = monster.chasing_counter + 1
	--gameutils.position_distance
	local test_spell = 1000			--测试用技能
	local test_spell_dist = 200		--测试用技能的施法距离
	local target = self:get_target()
	if target == nil then	--没有目标，返回巡逻状态，由于单机目标就是主角，所以一般不会发生
		monster:change_state(ai_state.AISTATE_PATROLING)
		return
	end
    
    local monsterX = monster:get_position().x
    local monsterY = monster:get_position().y
    local targetX = target:get_position().x
    local targetY = target:get_position().y
	--自己坐标点，离出生点超过追逐半径，则回归巡逻状态
	if gameutils.position_distance(monsterX, monsterY, monster.spawnpoint.x, monster.spawnpoint.y) >= monster.chasing_radius then
		monster:teleport(monster.spawnpoint.x, monster.spawnpoint.y)
		monster:change_state(ai_state.AISTATE_PATROLING)
		return		
	end 

	--离攻击目标到达技能距离
	if gameutils:is_close_target(monster, target, test_spell_dist) == true then
		monster:castSpell(test_spell, target)		
	else
		local dist_to_target = gameutils.position_distance(monsterX, monsterY, targetX, targetY) --和玩家的距离
		local dist_real = dist_to_target - test_spell_dist + 50 --要站位的距离
		local target_pos = gameutils:get_point_by_dist(monsterX, monsterY, targetX, targetY, dist_real)
		--monster:move(target:get_position().x, target:get_position().y)
		monster:move(target_pos.x, target_pos.y)
	end

	

end