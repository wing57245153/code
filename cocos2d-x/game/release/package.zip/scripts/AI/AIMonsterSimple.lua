super_class.AIMonsterSimple(AIBase)

function AIMonsterSimple:__init()
	self.m_aitype = ai_config.AITYPE_SIMPLE
	self:regist_aifsm(ai_state.AISTATE_WATING, AIFactory.aifsm_waiting)
	self:regist_aifsm(ai_state.AISTATE_PATROLING, AIFactory.aifsm_patrol)
	self:regist_aifsm(ai_state.AISTATE_CHASING, AIFactory.aifsm_chasing_monster_simple)
end