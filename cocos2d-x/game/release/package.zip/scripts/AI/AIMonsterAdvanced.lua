super_class.AIMonsterAdvanced(AIBase)

function AIMonsterAdvanced:__init()
	self.m_aitype = ai_config.AITYPE_ADVANCE
	self:regist_aifsm(ai_state.AISTATE_WATING, AIFactory.aifsm_waiting)
	self:regist_aifsm(ai_state.AISTATE_PATROLING, AIFactory.aifsm_patrol)
	self:regist_aifsm(ai_state.AISTATE_CHASING, AIFactory.aifsm_chasing_monster_advanced)
end