super_class.AIFsmBase()

function AIFsmBase:__init()

end

function AIFsmBase:enter(monster)
end

function AIFsmBase:exit(monster)
end

function AIFsmBase:think(monster)
end

function AIFsmBase:get_target()
	return GameWorld.player()
end


-----------

super_class.AIFsmWaiting(AIFsmBase)

function AIFsmWaiting:__init()

end

function AIFsmWaiting:enter(monster)
end

function AIFsmWaiting:exit(monster)
end

function AIFsmWaiting:think(monster)
	print("now is waiting")
end

----------------
super_class.AIFsmDead(AIFsmBase)

function AIFsmDead:__init()

end

function AIFsmDead:enter(monster)
end

function AIFsmDead:exit(monster)
end

function AIFsmDead:think(monster)
	print("now is dead")
end

----------------
super_class.AIFsmPatrol(AIFsmBase)

function AIFsmPatrol:__init()

end

function AIFsmPatrol:enter(monster)
	monster.patrol_counter = 4
end

function AIFsmPatrol:exit(monster)
	monster.patrol_counter = 0
end

function AIFsmPatrol:think(monster)
	monster.patrol_counter = monster.patrol_counter + 1
	if monster.patrol_counter > 6 then
		monster.patrol_counter = 0
		local x = monster.spawnpoint.x + math.random(-monster.patrol_radius, monster.patrol_radius)
		local y = monster.spawnpoint.y + math.random(-monster.patrol_radius, monster.patrol_radius)
		monster:move(x, y)			
	end
end