-- ResourceManager.lua
-- created by aXing on 2012-12-7
-- 资源管理器
-- 管理游戏内所有的资源

-- local __resmgr =  ZXResMgr:sharedManager()
ResourceManager = {}

-- 析构资源管理器
function ResourceManager:purge(  )
	_loaded_scene_cfg = {}
end

-- 下一帧是否回收资源标签
local _resource_dirty = false

-- 设置资源引用有需要回收的，在下一帧会通知引擎回收贴图资源
function ResourceManager:set_resource_dirty(  )
	_resource_dirty = true
end

-- 通知引擎检查资源回收
function ResourceManager:garbage_collection(  )
	if _resource_dirty then
		collectgarbage("collect")
		print("引擎检查资源回收");
		CCTextureCache:getInstance():removeUnusedTextures()
		_resource_dirty = false
	end
end

-- 加载全部的ui
local function init_ui(  )
	require "scripts/UI/__init"
end

-- 加载工具类
local function init_others()
	require "scripts/action/__init"
end

-- 初始化主游戏
function ResourceManager:init_game(  )
	init_ui()
	init_others()
end
