
-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    debugOutput(tostring(msg))
    print("----------------------------------------")
end

require "scripts/core/GameWorld"

require "scripts/utils/timer"
require "scripts/utils/gameutils"

local function main()
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

	
	--require "Game"

    -- run
    --[[]]
    

    --print("__sceneGame::", sceneGame);

    local root = sceneGame

    
	-- 这里引入测试模块
	--[[if CCUserDefault:sharedUserDefault():getBoolForKey("test") then
		require "scripts/Test"
		Test:test(root)
	else
		-- 初始化游戏状态管理器
		GameStateManager:init(root)
		-- 注册游戏每秒的心跳
		-- local entryID = CCScheduler:sharedScheduler():scheduleScriptFunc(GameStateManager.tick, 1, false)
		-- 进入登陆状态
		-- GameStateManager:set_state("login")
		-- 测试先进入战斗
		-- GameStateManager:set_state("combat")
		-- 测试先进入普通	
		-- GameStateManager:set_state("scene_enter")
	end]]



	--local mts = require "scripts/model/testxx"
	--print("mts-------", mts)	
	

	--require "scripts/Test"
	require "Game"
	CCDirector:getInstance():setProjection(kCCDirectorProjection2D)

	------------------------------------ 测试程序 ---------------------------------
	--require "scripts/ForTest"
	--ForTest:test()
end

--设置socket！
--CCUserDefault:sharedUserDefault():setStringForKey('rs_addr','127.0.0.1')
--CCUserDefault:sharedUserDefault():setIntegerForKey('rs_port',8314)

xpcall(main, __G__TRACKBACK__)